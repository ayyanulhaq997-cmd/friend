// MovieFragment.kt - UPDATED VERSION with List and Favorite functionality
package com.example.hhhh

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.app.ActivityOptionsCompat
import androidx.leanback.app.BackgroundManager
import androidx.leanback.app.BrowseSupportFragment
import androidx.leanback.widget.*
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.example.hhhh.api.ApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.*

class TVShowsFragment : BrowseSupportFragment() {

    private val TAG = "TVShowFragment"
    private val mHandler = Handler(Looper.getMainLooper())
    private lateinit var mBackgroundManager: BackgroundManager
    private var mDefaultBackground: Drawable? = null
    private lateinit var mMetrics: DisplayMetrics
    private var mBackgroundTimer: Timer? = null
    private var mBackgroundUri: String? = null
    private var searchRunnable: Runnable? = null
    private var loadingBar: ProgressBar? = null
    private var job: Job? = null
    private var isFragmentActive = true

    // Sort state
    private var currentSortBy = "Year"
    private var currentSortOrder = "Ascending"

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        isFragmentActive = true
        prepareBackgroundManager()
        setupUIElements()
        loadRows()
        setupEventListeners()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        try {
            loadingBar = requireActivity().findViewById(R.id.loadingBar)
        } catch (e: Exception) {
            Log.e(TAG, "Loading bar not found: ${e.message}")
        }
    }

    private fun prepareBackgroundManager() {
        try {
            mBackgroundManager = BackgroundManager.getInstance(activity)
            mBackgroundManager.attach(requireActivity().window)
            mDefaultBackground = ContextCompat.getDrawable(requireActivity(), R.drawable.default_background)
            mMetrics = DisplayMetrics()
            requireActivity().windowManager.defaultDisplay.getMetrics(mMetrics)
            mBackgroundManager.drawable = mDefaultBackground

        } catch (e: Exception) {
            Log.e(TAG, "Error preparing background manager: ${e.message}")
        }
    }

    private fun setupUIElements() {
        title = ""  // hide default text
        headersState = HEADERS_ENABLED
        isHeadersTransitionOnBackEnabled = true

        brandColor = ContextCompat.getColor(requireActivity(), R.color.fastlane_background)
        searchAffordanceColor = ContextCompat.getColor(requireActivity(), R.color.search_opaque)
    }




    private fun loadRows() {
        job?.cancel()

        job = CoroutineScope(Dispatchers.Main).launch {
            try {
                loadingBar?.bringToFront()
                loadingBar?.visibility = View.VISIBLE

                //val ok = TVShowList.loadFromApi()
                val  ok = true
                var aa = ApiClient.api.getTVShowBySort("Title", "DESC")
                var  dd = aa
                loadingBar?.visibility = View.GONE

                if (isFragmentActive && isAdded) {
                    if (aa.status) {
                        if (aa.data.isNotEmpty()) {
                            buildRows(aa.data)
                        } else {
                            Toast.makeText(requireContext(), "No TV Shows available", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(requireContext(), "Failed to load categories", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading rows: ${e.message}", e)
                if (isAdded) {
                    loadingBar?.visibility = View.GONE
                    Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun buildRows(categories: List<TVShowCategory>) {
        try {
            val rowsAdapter = ArrayObjectAdapter(ListRowPresenter())
            val cardPresenter = TVShowCardPresenter()
            val iconPresenter = IconPresenter()
            val iconRowAdapter = ArrayObjectAdapter(iconPresenter)

            iconRowAdapter.add( IconItem(1, "List", R.drawable.ic_list_bg) )
            iconRowAdapter.add( IconItem(2, "Favorite", R.drawable.ic_star_bg) )

            val iconHeader = HeaderItem(0, "Preference")
            rowsAdapter.add( ListRow(iconHeader, iconRowAdapter) )
            categories.forEachIndexed { index, category ->
                if (category.shows.isNotEmpty()) {

                    val listRowAdapter = ArrayObjectAdapter(cardPresenter)
                    category.shows.forEach { show ->
                        try {
                            listRowAdapter.add(show)
                        } catch (e: Exception) {
                            Log.e(TAG, "Error adding show: ${e.message}")
                        }
                    }
                    val header = HeaderItem(index.toLong(), category.name)
                    rowsAdapter.add(ListRow(header, listRowAdapter))
                }
            }

            if (isAdded && rowsAdapter.size() > 0) {
                adapter = rowsAdapter
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error building rows: ${e.message}", e)
        }
    }

    private fun setupEventListeners() {
        try {
            setOnSearchClickedListener {
                try {
                    val intent = Intent(activity, SearchActivity::class.java)
                    startActivity(intent)
                } catch (e: Exception) {
                    Log.e(TAG, "Error opening search: ${e.message}")
                }
            }

            onItemViewClickedListener = ItemViewClickedListener()
            onItemViewSelectedListener = ItemViewSelectedListener()

            // Setup list and favorite buttons
            setupHeaderButtons()
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up event listeners: ${e.message}")
        }
    }

    private fun setupHeaderButtons() {
        try {
            // Get buttons from activity's root view
            val activity = requireActivity()
            val rootView = activity.window.decorView.findViewById<View>(android.R.id.content)

            val listButton = rootView.findViewById<View>(R.id.btnList)
            val favoriteButton = rootView.findViewById<View>(R.id.btnFavorite)

            Log.d(TAG, "List button: $listButton, Favorite button: $favoriteButton")

            listButton?.setOnClickListener {
                Log.d(TAG, "List button clicked")
                showOrderDialog()
            }

            favoriteButton?.setOnClickListener {
                Log.d(TAG, "Favorite button clicked")
                showFavorites()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up header buttons: ${e.message}")
            e.printStackTrace()
        }
    }

    private inner class ItemViewClickedListener : OnItemViewClickedListener {
        override fun onItemClicked(
            itemViewHolder: Presenter.ViewHolder,
            item: Any,
            rowViewHolder: RowPresenter.ViewHolder,
            row: Row
        ) {

            if (item is IconItem) {
                when (item.id) {
                    1 -> showOrderDialog()      // List sorting popup
                    2 -> showFavorites()        // Favorite screen
                }
                return
            }

            try {
                if (item is TVShow && isFragmentActive) {
                    val intent = Intent(activity, TVShowDetailsActivity::class.java)
                    intent.putExtra(TVShowDetailsActivity.TVSHOW, item)

                    val mainImageView = (itemViewHolder.view as? ImageCardView)?.mainImageView
                    val bundle = if (mainImageView != null) {
                        ActivityOptionsCompat.makeSceneTransitionAnimation(
                            requireActivity(),
                            mainImageView,
                            DetailsActivity.SHARED_ELEMENT_NAME
                        ).toBundle()
                    } else {
                        null
                    }

                    startActivity(intent, bundle)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error on item click: ${e.message}", e)
            }
        }
    }

    private inner class ItemViewSelectedListener : OnItemViewSelectedListener {
        override fun onItemSelected(
            itemViewHolder: Presenter.ViewHolder?,
            item: Any?,
            rowViewHolder: RowPresenter.ViewHolder,
            row: Row
        ) {
            try {
                if (item is TVShow && isFragmentActive) {
                    mBackgroundUri = item.bg_url
                    startBackgroundTimer()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error on item selected: ${e.message}")
            }
        }
    }

    private fun updateBackground(uri: String?) {
        try {
            if (!isFragmentActive || !isAdded || activity == null) {
                Log.d(TAG, "Fragment not active, skipping background update")
                return
            }

            val width = mMetrics.widthPixels
            val height = mMetrics.heightPixels

            Glide.with(requireActivity())
                .load(uri)
                .centerCrop()
                .error(mDefaultBackground)
                .into(object : SimpleTarget<Drawable>(width, height) {
                    override fun onResourceReady(
                        resource: Drawable,
                        transition: Transition<in Drawable>?
                    ) {
                        try {
                            if (isFragmentActive && isAdded && ::mBackgroundManager.isInitialized) {
                                mBackgroundManager.drawable = resource
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error setting background: ${e.message}")
                        }
                    }
                })
            cancelBackgroundTimer()
        } catch (e: Exception) {
            Log.e(TAG, "Error updating background: ${e.message}")
        }
    }

    private fun startBackgroundTimer() {
        try {
            cancelBackgroundTimer()
            mBackgroundTimer = Timer()
            mBackgroundTimer?.schedule(UpdateBackgroundTask(), 300)
        } catch (e: Exception) {
            Log.e(TAG, "Error starting background timer: ${e.message}")
        }
    }

    private fun cancelBackgroundTimer() {
        try {
            mBackgroundTimer?.cancel()
            mBackgroundTimer = null
        } catch (e: Exception) {
            Log.e(TAG, "Error canceling timer: ${e.message}")
        }
    }

    private inner class UpdateBackgroundTask : TimerTask() {
        override fun run() {
            try {
                if (isFragmentActive) {
                    mHandler.post { updateBackground(mBackgroundUri) }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in background task: ${e.message}")
            }
        }
    }

    // Show sort/order dialog
    private fun showOrderDialog() {
        try {
            if (!isAdded || isFragmentActive) {
                val dialog = OrderDialogFragment { sortBy, sortOrder ->
                    try {
                        currentSortBy = sortBy
                        currentSortOrder = sortOrder
                        Log.d(TAG, "Sort settings: $sortBy, $sortOrder")
                        reloadTVShowsWithSort(sortBy, sortOrder)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error in sort callback: ${e.message}", e)
                        Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
                dialog.show(childFragmentManager, "OrderDialog")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error showing dialog: ${e.message}", e)
            e.printStackTrace()
            Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // Show favorites
    private fun showFavorites() {
        try {
            val intent = Intent(activity, MovieFavoriteActivity::class.java)
            startActivity(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Error opening favorites: ${e.message}")
        }
    }

    // Reload TV Shows with sort parameters
    private fun reloadTVShowsWithSort(sortBy: String, sortOrder: String) {
        job?.cancel()

        job = CoroutineScope(Dispatchers.Main).launch {
            try {
                loadingBar?.bringToFront()
                loadingBar?.visibility = View.VISIBLE

                val ok = TVShowList.loadFromApiWithSort(sortBy, sortOrder)

                loadingBar?.visibility = View.GONE

                if (isFragmentActive && isAdded) {
                    if (ok) {
                        if (TVShowList.categories.isNotEmpty()) {
                            buildRows(TVShowList.categories)
                            Toast.makeText(requireContext(), "TV Shows refreshed", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(requireContext(), "TV Shows available", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(requireContext(), "Failed to load categories", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error reloading TV Shows: ${e.message}", e)
                if (isAdded) {
                    loadingBar?.visibility = View.GONE
                    Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "Fragment paused - cleaning up resources")
        isFragmentActive = false
        cleanupResources()
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "Fragment resumed")
        isFragmentActive = true
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Fragment destroyed - cleaning up all resources")
        isFragmentActive = false
        cleanupResources()
    }

    private fun cleanupResources() {
        try {
            cancelBackgroundTimer()
            searchRunnable?.let { mHandler.removeCallbacks(it) }
            mHandler.removeCallbacksAndMessages(null)
            job?.cancel()
            Log.d(TAG, "Resources cleaned up successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error during cleanup: ${e.message}")
        }
    }
}