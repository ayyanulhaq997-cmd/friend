package com.example.hhhh.models

import java.io.Serializable

data class Channel(
    val live_tv_id: Int? = 0,
    val tv_name: String?="",
    val thumbnail: String?="",
    val url: String?="",
    val categories: String?="",
    val publication: Boolean = true
) : Serializable

data class ChannelsResponse(
    val status: Boolean?=false,
    val message: String?="",
    val data: List<Channel>?
)