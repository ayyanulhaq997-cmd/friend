package com.example.hhhh

data class VideoItem(val title: String)