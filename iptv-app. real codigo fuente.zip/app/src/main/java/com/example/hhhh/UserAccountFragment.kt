// UserAccountFragment.kt - Complete with API Integration
package com.example.hhhh

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.leanback.app.GuidedStepSupportFragment
import androidx.leanback.widget.GuidanceStylist
import androidx.leanback.widget.GuidedAction
import com.example.hhhh.api.ApiClient
import com.example.hhhh.api.SessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class UserAccountFragment : GuidedStepSupportFragment() {

    companion object {
        private const val TAG = "UserAccountFragment"
        private const val ACTION_USERNAME = 1L
        private const val ACTION_EXPIRATION = 2L
        private const val ACTION_CREDITS = 3L
        private const val ACTION_CHANGE_PASSWORD = 4L
        private const val ACTION_UNLINK = 5L
        private const val ACTION_BACK = 6L
    }

    private var username: String = ""
    private var expirationDate: String = ""
    private var creditsAvailable: String = ""

    private var loadDataJob: Job? = null
    private var unlinkJob: Job? = null
    private var isDataLoaded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Load user data when fragment is created
        loadUserSettingData()
    }

    override fun onCreateGuidance(savedInstanceState: Bundle?): GuidanceStylist.Guidance {
        val title = getString(R.string.user_account_title)
        val description = if (username.isNotEmpty()) username else getString(R.string.loading)
        val icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_user)

        return GuidanceStylist.Guidance(title, description, "", icon)
    }

    override fun onCreateActions(actions: MutableList<GuidedAction>, savedInstanceState: Bundle?) {
        // Username
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_USERNAME)
                .title(if (username.isNotEmpty()) username else getString(R.string.loading))
                .description(if (username.isNotEmpty()) username else "...")
                .icon(R.drawable.ic_user)
                .enabled(false)
                .build()
        )

        // Expiration Date
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_EXPIRATION)
                .title(getString(R.string.expiration_date))
                .description(if (expirationDate.isNotEmpty()) expirationDate else getString(R.string.loading))
                .icon(R.drawable.ic_calendar)
                .enabled(false)
                .build()
        )

        // Credits Available
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_CREDITS)
                .title(getString(R.string.credits_available))
                .description(if (creditsAvailable.isNotEmpty()) creditsAvailable else getString(R.string.loading))
                .icon(R.drawable.ic_credits)
                .enabled(false)
                .build()
        )

        // Change Password
//        actions.add(
//            GuidedAction.Builder(requireContext())
//                .id(ACTION_CHANGE_PASSWORD)
//                .title(getString(R.string.change_password))
//                .description(getString(R.string.click_to_change_password))
//                .icon(R.drawable.ic_key)
//                .build()
//        )

        // Unlink
//        actions.add(
//            GuidedAction.Builder(requireContext())
//                .id(ACTION_UNLINK)
//                .title(getString(R.string.unlink))
//                .description(getString(R.string.click_to_unlink))
//                .icon(R.drawable.ic_unlink)
//                .build()
//        )

        // Back
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_BACK)
                .title(getString(R.string.back))
                .description("")
                .icon(R.drawable.ic_back)
                .build()
        )
    }

    override fun onGuidedActionClicked(action: GuidedAction) {
        when (action.id) {
            ACTION_CHANGE_PASSWORD -> {
                add(fragmentManager, ChangePasswordFragment())
            }
            ACTION_UNLINK -> {
                showUnlinkConfirmation()
            }
            ACTION_BACK -> {
                fragmentManager?.popBackStack()
            }
        }
    }

    // Load user setting data from API
    private fun loadUserSettingData() {
        if (isDataLoaded) return

        loadDataJob?.cancel()
        loadDataJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                // Show loading state
                showLoading(true)

                // Call API
                val response = withContext(Dispatchers.IO) {
                    ApiClient.api.userSettingData()
                }

                // Check if fragment is still active
                if (!isAdded) return@launch

                // Hide loading
                showLoading(false)

                // Handle response
                if (response.status == true) {
                    username = response.username ?: ""
                    expirationDate = response.expired_date ?: ""
                    creditsAvailable = response.credits ?: "0"

                    isDataLoaded = true

                    // Update UI with new data
                    updateActionsWithData()

                    Log.d(TAG, "User data loaded successfully: $username")
                } else {
                    showError(response.message ?: getString(R.string.error))
                    Log.e(TAG, "Failed to load user data: ${response.message}")
                }

            } catch (e: Exception) {
                if (!isAdded) return@launch

                showLoading(false)

                Log.e(TAG, "Error loading user data", e)
                showError(getString(R.string.get_user_error, e.message ?: "Unknown error"))
            }
        }
    }

    // Update actions with loaded data
    private fun updateActionsWithData() {
        if (!isAdded) return

        // Find and update username action
        findActionById(ACTION_USERNAME)?.let { action ->
            action.title = username
            action.description = username
            notifyActionChanged(findActionPositionById(ACTION_USERNAME))
        }

        // Find and update expiration action
        findActionById(ACTION_EXPIRATION)?.let { action ->
            action.description = expirationDate
            notifyActionChanged(findActionPositionById(ACTION_EXPIRATION))
        }

        // Find and update credits action
        findActionById(ACTION_CREDITS)?.let { action ->
            action.description = creditsAvailable
            notifyActionChanged(findActionPositionById(ACTION_CREDITS))
        }

        // Update guidance description with username
        if (username.isNotEmpty()) {
            guidanceStylist.titleView?.text = getString(R.string.user_account_title)
            guidanceStylist.descriptionView?.text = username
        }
    }

    // Show unlink confirmation dialog
    private fun showUnlinkConfirmation() {
        // Create confirmation dialog
        val dialog = UnlinkConfirmationFragment { confirmed ->
            if (confirmed) {
                performUnlink()
            }
        }
        //dialog.show(childFragmentManager, "UnlinkConfirmation")
    }

    // Perform unlink operation
    private fun performUnlink() {
        unlinkJob?.cancel()
        unlinkJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                showLoading(true)

                // Call unlink API (you might need to add this endpoint)
                // val response = withContext(Dispatchers.IO) {
                //     ApiClient.api.unlinkAccount()
                // }

                // For now, just clear session and redirect to login
                withContext(Dispatchers.IO) {
                    // Simulate API call
                    kotlinx.coroutines.delay(1000)
                }

                if (!isAdded) return@launch

                showLoading(false)

                // Clear session
                val prefs = requireContext().getSharedPreferences("user_prefs", android.content.Context.MODE_PRIVATE)
                prefs.edit().clear().apply()
                SessionManager.clear(requireContext())

                // Show success message
                Toast.makeText(
                    requireContext(),
                    getString(R.string.unlink_account_confirm),
                    Toast.LENGTH_SHORT
                ).show()

                // Redirect to login
                val intent = Intent(requireActivity(), LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                activity?.finish()

            } catch (e: Exception) {
                if (!isAdded) return@launch

                showLoading(false)
                Log.e(TAG, "Error unlinking account", e)
                showError(getString(R.string.error))
            }
        }
    }

    // Show/hide loading indicator
    private fun showLoading(show: Boolean) {
        // You can implement a loading overlay here if needed
        activity?.findViewById<ProgressBar>(R.id.loadingBar)?.visibility =
            if (show) View.VISIBLE else View.GONE
    }

    // Show error message
    private fun showError(message: String) {
        if (isAdded) {
            Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        loadDataJob?.cancel()
        unlinkJob?.cancel()
    }
}

// Unlink Confirmation Dialog Fragment
class UnlinkConfirmationFragment(
    private val onResult: (Boolean) -> Unit
) : GuidedStepSupportFragment() {

    companion object {
        private const val ACTION_YES = 1L
        private const val ACTION_NO = 2L
    }

    override fun onCreateGuidance(savedInstanceState: Bundle?): GuidanceStylist.Guidance {
        val title = getString(R.string.confirm)
        val description = "Are you sure you want to unlink your account? This action cannot be undone."
        val icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_unlink)

        return GuidanceStylist.Guidance(title, description, "", icon)
    }

    override fun onCreateActions(actions: MutableList<GuidedAction>, savedInstanceState: Bundle?) {
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_YES)
                .title(getString(R.string.yes))
                .build()
        )

        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_NO)
                .title(getString(R.string.no))
                .build()
        )
    }

    override fun onGuidedActionClicked(action: GuidedAction) {
        when (action.id) {
            ACTION_YES -> {
                onResult(true)
                dismiss()
            }
            ACTION_NO -> {
                onResult(false)
                dismiss()
            }
        }
    }

    private fun dismiss() {
        fragmentManager?.popBackStack()
    }
}