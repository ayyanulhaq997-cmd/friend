package com.example.hhhh

import android.app.Dialog
import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.fragment.app.DialogFragment

class OrderDialogFragment(
    private val onOrderSelected: (sortBy: String, sortOrder: String) -> Unit
) : DialogFragment() {

    private val TAG = "OrderDialogFragment"
    private var rgSortBy: RadioGroup? = null
    private var rgSortOrder: RadioGroup? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return try {
            val context = requireActivity()

            val dialogView = createDialogView()

            AlertDialog.Builder(context)  // <-- system AlertDialog (safe!)
                .setTitle("Order")
                .setView(dialogView)
                .setPositiveButton("OK") { _, _ ->
                    try {
                        val sortBy = when (rgSortBy?.checkedRadioButtonId) {
                            R.id.rbYear -> "Year"
                            R.id.rbTitle -> "Title"
                            R.id.rbJustAdded -> "Just Added"
                            else -> "Year"
                        }

                        val sortOrder = when (rgSortOrder?.checkedRadioButtonId) {
                            R.id.rbAscending -> "Ascending"
                            R.id.rbDescending -> "Descending"
                            else -> "Ascending"
                        }

                        Log.d(TAG, "Selected: $sortBy, $sortOrder")
                        onOrderSelected(sortBy, sortOrder)
                        dismiss()
                    } catch (e: Exception) {
                        Log.e(TAG, "Error in OK button: ${e.message}", e)
                    }
                }
                .setNegativeButton("BACK") { dialog, _ ->
                    dialog.dismiss()
                }
                .create()
        } catch (e: Exception) {
            Log.e(TAG, "Dialog error: ${e.message}", e)
            super.onCreateDialog(savedInstanceState)
        }
    }

    private fun createDialogView(): View {
        val container = android.widget.LinearLayout(requireContext()).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(50, 50, 50, 50)
        }

        val sortByLabel = TextView(requireContext()).apply {
            text = "Sort by:"
            textSize = 18f
            setTextColor(android.graphics.Color.WHITE)
        }
        container.addView(sortByLabel)

        rgSortBy = RadioGroup(requireContext()).apply {
            orientation = RadioGroup.VERTICAL
        }

        rgSortBy!!.addView(radio("Year", R.id.rbYear, true))
        rgSortBy!!.addView(radio("Title", R.id.rbTitle))
        rgSortBy!!.addView(radio("Just Added", R.id.rbJustAdded))

        container.addView(rgSortBy)

        val divider = View(requireContext()).apply {
            layoutParams = android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                2
            )
            setBackgroundColor(android.graphics.Color.CYAN)
        }
        container.addView(divider)

        val showLabel = TextView(requireContext()).apply {
            text = "Show:"
            textSize = 18f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, 20, 0, 10)
        }
        container.addView(showLabel)

        rgSortOrder = RadioGroup(requireContext()).apply {
            orientation = RadioGroup.VERTICAL
        }

        rgSortOrder!!.addView(radio("Ascending", R.id.rbAscending, true))
        rgSortOrder!!.addView(radio("Descending", R.id.rbDescending))

        container.addView(rgSortOrder)

        return container
    }

    private fun radio(text: String, id: Int, checked: Boolean = false): RadioButton {
        return RadioButton(requireContext()).apply {
            this.id = id
            this.text = text
            setTextColor(android.graphics.Color.WHITE)
            isChecked = checked
        }
    }
}
