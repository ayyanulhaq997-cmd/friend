package com.example.hhhh

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import java.util.Locale

class MyApp : Application() {

    companion object {
        lateinit var context: Context
            private set
    }

    override fun onCreate() {
        super.onCreate()
        context = applicationContext
        applyLanguage()
    }

    fun applyLanguage() {
        val prefs = getSharedPreferences("app_settings", MODE_PRIVATE)
        val lang = prefs.getString("app_language", "en") ?: "en"
        val locale = Locale(lang)
        Locale.setDefault(locale)

        val config = Configuration(resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)

        // Update app resources
        resources.updateConfiguration(config, resources.displayMetrics)
    }

    // Optional helper to wrap a context with the current language
    fun getLocalizedContext(base: Context): Context {
        val prefs = base.getSharedPreferences("app_settings", MODE_PRIVATE)
        val lang = prefs.getString("app_language", "en") ?: "en"
        val locale = Locale(lang)
        Locale.setDefault(locale)

        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        return base.createConfigurationContext(config)
    }
}
