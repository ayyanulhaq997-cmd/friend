package com.example.hhhh

data class FavoriteTVShowResponse(
    val status: Boolean,
    val favorite: Int // 1 = added, 0 = removed
)