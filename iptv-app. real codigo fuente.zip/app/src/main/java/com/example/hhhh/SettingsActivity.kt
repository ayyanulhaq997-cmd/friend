// SettingsActivity.kt - Updated with Language Support
package com.example.hhhh

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.FragmentActivity

class SettingsActivity : FragmentActivity() {

    override fun attachBaseContext(newBase: Context) {
        // Apply language before creating activity
        val localizedContext = (newBase.applicationContext as MyApp).getLocalizedContext(newBase)
        super.attachBaseContext(localizedContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (savedInstanceState == null) {
            val fragment = SettingsFragment()
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, fragment)
                .commit()
        }
    }
}