package com.example.hhhh

import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.leanback.app.BrowseSupportFragment
import androidx.leanback.widget.*
import androidx.core.content.ContextCompat
import com.example.hhhh.api.ApiClient
import com.example.hhhh.api.SessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeFragment : BrowseSupportFragment() {   // 👈 Extend BrowseSupportFragment
    private lateinit var rowsAdapter: ArrayObjectAdapter

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        setupUI()
        loadRows()
    }

    private fun setupUI() {
        title = "Home" // Appears on top-left
        headersState = HEADERS_ENABLED
        isHeadersTransitionOnBackEnabled = true

        brandColor = ContextCompat.getColor(requireContext(), android.R.color.holo_blue_dark)
    }

    private fun loadRows() {
        rowsAdapter = ArrayObjectAdapter(ListRowPresenter())

        // Categories
        val categories = listOf(
            getString(R.string.movies),
            getString(R.string.series),
            getString(R.string.live_channels),
            getString(R.string.settings)
        )


        for (category in categories) {
            val header = HeaderItem(category)
            val itemPresenter = ItemPresenter()
            val listRowAdapter = ArrayObjectAdapter(itemPresenter)
            rowsAdapter.add(ListRow(header, listRowAdapter))
        }

        adapter = rowsAdapter
    }



}
