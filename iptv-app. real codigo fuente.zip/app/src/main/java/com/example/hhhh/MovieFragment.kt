// MovieFragment.kt - FINAL CRASH-FREE VERSION
package com.example.hhhh

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.app.ActivityOptionsCompat
import androidx.leanback.app.BackgroundManager
import androidx.leanback.app.BrowseSupportFragment
import androidx.leanback.widget.*
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.example.hhhh.models.MovieCategory
import kotlinx.coroutines.*
import java.util.*

class MovieFragment : BrowseSupportFragment() {

    private val TAG = "MovieFragment"

    private lateinit var mBackgroundManager: BackgroundManager
    private var mDefaultBackground: Drawable? = null
    private lateinit var mMetrics: DisplayMetrics

    private var mBackgroundTimer: Timer? = null
    private val mHandler = Handler(Looper.getMainLooper())

    private var loadingBar: ProgressBar? = null
    private var job: Job? = null

    private var isFragmentActive = true
    private var mBackgroundUri: String? = null

    // Sorting state
    private var currentSortBy = "Year"
    private var currentSortOrder = "Ascending"

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        isFragmentActive = true

        prepareBackgroundManager()
        setupUIElements()
        loadRows()
        setupEventListeners()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadingBar = activity?.findViewById(R.id.loadingBar)
    }

    // ---------------------------
    // BACKGROUND MANAGER
    // ---------------------------
    private fun prepareBackgroundManager() {
        val act = activity ?: return
        mBackgroundManager = BackgroundManager.getInstance(act)
        mBackgroundManager.attach(act.window)

        mDefaultBackground = ContextCompat.getDrawable(act, R.drawable.default_background)
        mMetrics = DisplayMetrics()
        act.windowManager.defaultDisplay.getMetrics(mMetrics)
        mBackgroundManager.drawable = mDefaultBackground
    }

    private fun setupUIElements() {
        title = ""
        headersState = HEADERS_ENABLED
        isHeadersTransitionOnBackEnabled = true

        brandColor = ContextCompat.getColor(requireContext(), R.color.fastlane_background)
        searchAffordanceColor = ContextCompat.getColor(requireContext(), R.color.search_opaque)
    }

    // ---------------------------
    // LOAD MOVIE ROWS
    // ---------------------------
    private fun loadRows() {
        job?.cancel()

        job = CoroutineScope(Dispatchers.Main).launch {
            try {
                loadingBar?.visibility = View.VISIBLE

                val ok = MovieList.loadFromApi()

                loadingBar?.visibility = View.GONE

                if (!isFragmentActive || !isAdded) return@launch

                if (ok) {
                    if (MovieList.categories.isNotEmpty()) {
                        buildRows(MovieList.categories)
                    } else {
                        Toast.makeText(requireContext(), "No movies available", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(requireContext(), "Failed to load categories", Toast.LENGTH_LONG).show()
                }

            } catch (e: Exception) {
                Log.e(TAG, "Error loading rows: ${e.message}", e)
                loadingBar?.visibility = View.GONE
            }
        }
    }

    private fun buildRows(categories: List<MovieCategory>) {
        val rowsAdapter = ArrayObjectAdapter(ListRowPresenter())
        val cardPresenter = CardPresenter()

        // Preference row: List + Favorite
        val iconPresenter = IconPresenter()
        val iconRowAdapter = ArrayObjectAdapter(iconPresenter)
        iconRowAdapter.add(IconItem(1, "List", R.drawable.ic_list_bg))
        iconRowAdapter.add(IconItem(2, "Favorite", R.drawable.ic_star_bg))
        rowsAdapter.add(ListRow(HeaderItem(0, "Preference"), iconRowAdapter))

        // Movie rows
        categories.forEachIndexed { idx, category ->
            if (category.movies.isNotEmpty()) {
                val listRowAdapter = ArrayObjectAdapter(cardPresenter)
                category.movies.forEach { listRowAdapter.add(it) }

                rowsAdapter.add(
                    ListRow(
                        HeaderItem(idx.toLong(), category.name),
                        listRowAdapter
                    )
                )
            }
        }

        adapter = rowsAdapter
    }

    // ---------------------------
    // EVENT LISTENERS
    // ---------------------------
    private fun setupEventListeners() {
        setOnSearchClickedListener {
            startActivity(Intent(activity, SearchActivity::class.java))
        }

        onItemViewClickedListener = ItemClicked()
        onItemViewSelectedListener = ItemSelected()

        setupHeaderButtons()
    }

    private fun setupHeaderButtons() {
        val root = activity?.window?.decorView?.findViewById<View>(android.R.id.content) ?: return

        root.findViewById<View>(R.id.btnList)?.setOnClickListener { showOrderDialog() }
        root.findViewById<View>(R.id.btnFavorite)?.setOnClickListener { showFavorites() }
    }

    inner class ItemClicked : OnItemViewClickedListener {
        override fun onItemClicked(viewHolder: Presenter.ViewHolder, item: Any, rowVH: RowPresenter.ViewHolder, row: Row) {

            if (item is IconItem) {
                when (item.id) {
                    1 -> showOrderDialog()
                    2 -> showFavorites()
                }
                return
            }

            if (item is Movie && isFragmentActive) {
                val intent = Intent(activity, DetailsActivity::class.java)
                intent.putExtra(DetailsActivity.MOVIE, item)

                val mainImg = (viewHolder.view as? ImageCardView)?.mainImageView
                val bundle = mainImg?.let {
                    ActivityOptionsCompat.makeSceneTransitionAnimation(
                        requireActivity(),
                        it,
                        DetailsActivity.SHARED_ELEMENT_NAME
                    ).toBundle()
                }

                startActivity(intent, bundle)
            }
        }
    }

    inner class ItemSelected : OnItemViewSelectedListener {
        override fun onItemSelected(vh: Presenter.ViewHolder?, item: Any?, rowVH: RowPresenter.ViewHolder, row: Row) {
            if (item is Movie && isFragmentActive) {
                mBackgroundUri = item.bg_url ?: item.card_url
                startBackgroundTimer()
            }
        }
    }

    // ---------------------------
    // BACKGROUND IMAGE HANDLING
    // ---------------------------
    private fun startBackgroundTimer() {
        cancelBackgroundTimer()
        mBackgroundTimer = Timer()
        mBackgroundTimer?.schedule(object : TimerTask() {
            override fun run() {
                if (isFragmentActive) {
                    mHandler.post { updateBackground(mBackgroundUri) }
                }
            }
        }, 300)
    }

    private fun cancelBackgroundTimer() {
        mBackgroundTimer?.cancel()
        mBackgroundTimer = null
    }

    private fun updateBackground(uri: String?) {
        if (!isAdded || !isFragmentActive) return

        val width = mMetrics.widthPixels
        val height = mMetrics.heightPixels

        // ✔ FIXED — SAFE GLIDE CALL
        Glide.with(this)
            .load(uri)
            .centerCrop()
            .error(mDefaultBackground)
            .into(object : CustomTarget<Drawable>(width, height) {

                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable>?) {
                    if (isAdded && isFragmentActive) {
                        mBackgroundManager.drawable = resource
                    }
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })

        cancelBackgroundTimer()
    }

    // ---------------------------
    // SORT + FAVORITES
    // ---------------------------
    private fun showOrderDialog() {
        if (!isAdded) return

        val dialog = OrderDialogFragment { sortBy, sortOrder ->
            currentSortBy = sortBy
            currentSortOrder = sortOrder
            reloadMoviesWithSort(sortBy, sortOrder)
        }

        dialog.show(childFragmentManager, "OrderDialog")
    }

    private fun showFavorites() {
        startActivity(Intent(activity, MovieFavoriteActivity::class.java))
    }

    private fun reloadMoviesWithSort(sortBy: String, sortOrder: String) {
        job?.cancel()

        job = CoroutineScope(Dispatchers.Main).launch {
            loadingBar?.visibility = View.VISIBLE

            val ok = MovieList.loadFromApiWithSort(sortBy, sortOrder)

            loadingBar?.visibility = View.GONE

            if (!isFragmentActive || !isAdded) return@launch

            if (ok) {
                buildRows(MovieList.categories)
                Toast.makeText(requireContext(), "Movies refreshed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------------------
    // CLEANUP
    // ---------------------------
    override fun onPause() {
        super.onPause()
        isFragmentActive = false
        cleanup()
    }

    override fun onDestroy() {
        super.onDestroy()
        isFragmentActive = false
        cleanup()
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "Fragment resumed")
        isFragmentActive = true
    }

    override fun onAttach(context: Context) {
        (activity?.application as MyApp).applyLanguage()
        super.onAttach(context)
    }


    private fun cleanup() {
        cancelBackgroundTimer()
        mHandler.removeCallbacksAndMessages(null)
        job?.cancel()
    }
}