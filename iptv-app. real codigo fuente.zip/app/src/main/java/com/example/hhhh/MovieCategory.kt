// MovieCategory.kt
package com.example.hhhh.models

import com.example.hhhh.Movie

data class MovieCategory(
    val id: Int,
    val name: String,
    val movies: List<Movie>
)
