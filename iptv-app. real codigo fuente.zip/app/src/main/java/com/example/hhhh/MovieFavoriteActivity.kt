package com.example.hhhh

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.example.hhhh.api.MovieApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MovieFavoriteActivity : AppCompatActivity() {

    private val TAG = "MovieFavoriteActivity"
    private var job: Job? = null

    private lateinit var loadingBar: ProgressBar
    private lateinit var recyclerView: RecyclerView
    private lateinit var rootLayout: View

    private val allFavoriteMovies = mutableListOf<Movie>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_favorite)

        rootLayout = findViewById(R.id.rootLayoutFavorite)
        loadingBar = findViewById(R.id.loadingBar)
        recyclerView = findViewById(R.id.recyclerViewFavorites)

        loadFavoriteMovies()
    }

    private fun loadFavoriteMovies() {
        job?.cancel()

        job = CoroutineScope(Dispatchers.Main).launch {
            try {
                loadingBar.visibility = View.VISIBLE

                val response = MovieApi.getFavoriteMovies()

                loadingBar.visibility = View.GONE

                if (response?.data != null) {
                    allFavoriteMovies.clear()

                    response.data.forEach { category ->
                        category.movies?.let { allFavoriteMovies.addAll(it) }
                    }

                    if (allFavoriteMovies.isNotEmpty()) {
                        displayFavorites(allFavoriteMovies)
                    } else {
                        Toast.makeText(this@MovieFavoriteActivity, "No favorites found", Toast.LENGTH_LONG).show()
                    }

                } else {
                    Toast.makeText(this@MovieFavoriteActivity, "Failed to load favorites", Toast.LENGTH_LONG).show()
                }

            } catch (e: Exception) {
                Log.e(TAG, "Error loading favorites", e)
                loadingBar.visibility = View.GONE
            }
        }
    }

    private fun displayFavorites(favorites: List<Movie>) {
        val adapter = FavoriteMovieAdapter(
            favorites,
            onItemClick = { movie -> navigateToMovieDetails(movie) },
            onItemFocused = { movie -> updateBackground(movie) }
        )

        recyclerView.layoutManager = GridLayoutManager(this, 5)
        recyclerView.adapter = adapter
    }

    private fun updateBackground(movie: Movie) {
        Glide.with(this)
            .load(movie.bg_url)
            .transform(jp.wasabeef.glide.transformations.BlurTransformation(25, 4))
            .centerCrop()
            .into(object : CustomTarget<Drawable>() {
                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable>?) {
                    rootLayout.background = resource
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
    }


    private fun navigateToMovieDetails(movie: Movie) {
        val intent = android.content.Intent(this, DetailsActivity::class.java)
        intent.putExtra(DetailsActivity.MOVIE, movie)
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        job?.cancel()
    }
}
