// MovieApi.kt - Updated to use your existing ApiClient
package com.example.hhhh.api

import android.util.Log
import com.example.hhhh.models.MovieCategoriesResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MovieApi {

    private const val TAG = "MovieApi"

    // Get all movie categories
    suspend fun getMovieCategories(): MovieCategoriesResponse? = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.api.getMovieCategories()
            Log.d(TAG, "Successfully loaded movie categories")
            response
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching movie categories: ${e.message}")
            null
        }
    }

    // Get favorite movies
    suspend fun getFavoriteMovies(): MovieCategoriesResponse? = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.api.getFavoriteMovies() // Adjust endpoint if needed
            Log.d(TAG, "Successfully loaded favorite movies")
            response
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching favorites: ${e.message}")
            null
        }
    }

    // Get movies with sort parameters
    suspend fun getMoviesBySort(sortBy: String, sortOrder: String): MovieCategoriesResponse? = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.api.getMoviesBySort(sortBy, sortOrder)
            Log.d(TAG, "Successfully loaded movies with sort: $sortBy - $sortOrder")
            response
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching movies with sort: ${e.message}")
            null
        }
    }

    // Add movie to favorites
    suspend fun addMovieFavorite(videoId: Long): Boolean = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.api.addMovieFavorite(videoId)
            Log.d(TAG, "Successfully added movie to favorites")
            response.status
        } catch (e: Exception) {
            Log.e(TAG, "Error adding favorite: ${e.message}")
            false
        }
    }
}