package com.example.hhhh

import java.io.Serializable

/**
 * Movie class represents video entity with title, description, image thumbs and video url.
 */
data class MovieDetail(
    var id: Long = 0,
    var title: String? = null,
    var description: String? = null,
    var video_quality: String? = null,
    var trailler_youtube_source: String? = null,
    var rating: String? = null,
    var runtime: String? = null,
    var favorite: Boolean? = false,
    var viewed: Boolean? = false,
    var type: String? = null,
    var released_year: String? = null,
    var genre_names: String? = null,
    var last_position: Long = 0L,
    var bg_url: String? = null,
    var card_url: String? = null,
    var video_url: String? = null,
    var studio: String? = null
) : Serializable {

    override fun toString(): String {
        return "MovieDetail{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", videoUrl='" + video_url + '\'' +
                ", bg_url='" + bg_url + '\'' +
                ", card_url='" + card_url + '\'' +
                '}'
    }

    companion object {
        internal const val serialVersionUID = 727566175075960653L
    }
}