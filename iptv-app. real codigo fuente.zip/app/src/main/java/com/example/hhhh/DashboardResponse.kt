data class DashboardResponse(
    val movie_categories: List<Category>,
    val series_categories: List<Category>,
    val live_categories: List<Category>
)

data class Category(
    val category_id: String,
    val category_name: String
)
