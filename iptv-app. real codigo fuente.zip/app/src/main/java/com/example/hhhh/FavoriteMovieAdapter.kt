package com.example.hhhh

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class FavoriteMovieAdapter(
    private val movies: List<Movie>,
    private val onItemClick: (Movie) -> Unit,
    private val onItemFocused: (Movie) -> Unit
) : RecyclerView.Adapter<FavoriteMovieAdapter.FavoriteMovieViewHolder>() {

    inner class FavoriteMovieViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val poster: ImageView = view.findViewById(R.id.ivMoviePoster)
        val title: TextView = view.findViewById(R.id.tvMovieTitle)
        val info: TextView = view.findViewById(R.id.tvMovieInfo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteMovieViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_favorite_movie, parent, false)

        return FavoriteMovieViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavoriteMovieViewHolder, position: Int) {
        val movie = movies[position]

        Glide.with(holder.itemView.context)
            .load(movie.bg_url)
            .into(holder.poster)

        holder.title.text = movie.title

        val year = movie.release?.take(4) ?: "---"
        val rating = movie.rate?.toString() ?: "--"

        holder.info.text = "$year • ⭐ $rating"

        holder.itemView.setOnClickListener {
            onItemClick(movie)
        }

        holder.itemView.setOnFocusChangeListener { view, hasFocus ->
            if (hasFocus) {
                view.animate().scaleX(1.1f).scaleY(1.1f).setDuration(150).start()
                view.setBackgroundResource(R.drawable.item_focused_bg)
                onItemFocused(movie)
            } else {
                view.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
                view.setBackgroundResource(R.drawable.item_unfocused_bg)
            }
        }
    }


    override fun getItemCount(): Int = movies.size
}
