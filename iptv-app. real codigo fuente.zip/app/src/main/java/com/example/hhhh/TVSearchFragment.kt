package com.example.hhhh

import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.leanback.app.SearchSupportFragment
import androidx.leanback.widget.*
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class TVSearchFragment : SearchSupportFragment(),
    SearchSupportFragment.SearchResultProvider {

    private val TAG = "TVSearchFragment"
    private val mHandler = Handler(Looper.getMainLooper())
    private val mRowsAdapter = ArrayObjectAdapter(ListRowPresenter())
    private var searchQuery: String = ""
    private var searchRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setSearchResultProvider(this)
        setOnItemViewClickedListener(ItemViewClickedListener())

        // Set search badge drawable (optional - remove if you don't have an icon)
        try {
            setBadgeDrawable(
                ContextCompat.getDrawable(requireContext(), R.drawable.app_icon_your_company)
            )
        } catch (e: Exception) {
            Log.w(TAG, "Badge drawable not found")
        }
    }

    override fun getResultsAdapter(): ObjectAdapter {
        return mRowsAdapter
    }

    override fun onQueryTextChange(newQuery: String): Boolean {
        Log.d(TAG, "Search Query: $newQuery")
        searchQuery = newQuery
        loadSearchResults(newQuery)
        return true
    }

    override fun onQueryTextSubmit(query: String): Boolean {
        Log.d(TAG, "Search Submit: $query")
        searchQuery = query
        loadSearchResults(query)
        return true
    }

    private fun loadSearchResults(query: String) {
        if (query.isEmpty()) {
            mRowsAdapter.clear()
            return
        }

        // Remove previous search callback if exists
        searchRunnable?.let { mHandler.removeCallbacks(it) }

        // Create new search runnable
        searchRunnable = Runnable {
            CoroutineScope(Dispatchers.Main).launch {
                searchTVShows(query)
            }
        }

        // Post delayed search
        mHandler.postDelayed(searchRunnable!!, 500) // Debounce 500ms
    }

    private suspend fun searchTVShows(query: String) {
        try {
            mRowsAdapter.clear()

            val results = withContext(Dispatchers.IO) {
                // Search through all loaded TV shows
                val matchedShows = mutableListOf<TVShow>()

//                TVShowList.categories.forEach { category ->
//                    category.shows.forEach { show ->
//                        if (show.title.contains(query, ignoreCase = true) ||
//                            show.description?.contains(query, ignoreCase = true) == true) {
//                            matchedShows.add(show)
//                        }
//                    }
//                }
                matchedShows
            }

            if (results.isNotEmpty()) {
                val cardPresenter = TVShowCardPresenter()
                val listRowAdapter = ArrayObjectAdapter(cardPresenter)

                results.forEach { show ->
                    listRowAdapter.add(show)
                }

                val header = HeaderItem(0, "Search Results (${results.size})")
                mRowsAdapter.add(ListRow(header, listRowAdapter))
            } else {
                // Show "No results" message
                val header = HeaderItem(0, "No results found for \"$query\"")
                mRowsAdapter.add(ListRow(header, ArrayObjectAdapter()))
            }

        } catch (e: Exception) {
            Log.e(TAG, "Search error: ${e.message}")
        }
    }

    private inner class ItemViewClickedListener : OnItemViewClickedListener {
        override fun onItemClicked(
            itemViewHolder: Presenter.ViewHolder,
            item: Any,
            rowViewHolder: RowPresenter.ViewHolder,
            row: Row
        ) {
            if (item is TVShow) {
                Log.d(TAG, "TV Show clicked: ${item.title}")
                val intent = Intent(activity, TVShowDetailsActivity::class.java)
                intent.putExtra(TVShowDetailsActivity.TVSHOW, item)

                val bundle = ActivityOptionsCompat.makeSceneTransitionAnimation(
                    requireActivity(),
                    (itemViewHolder.view as ImageCardView).mainImageView,
                    TVShowDetailsActivity.SHARED_ELEMENT_NAME
                ).toBundle()

                startActivity(intent, bundle)
            }
        }
    }
}
