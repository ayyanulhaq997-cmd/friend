package com.example.hhhh

data class LoginRequest(
    val username: String,
    val password: String
)
