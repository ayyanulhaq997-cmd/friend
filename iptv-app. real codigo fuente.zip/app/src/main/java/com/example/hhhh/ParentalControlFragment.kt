package com.example.hhhh

import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.leanback.app.GuidedStepSupportFragment
import androidx.leanback.widget.GuidanceStylist
import androidx.leanback.widget.GuidedAction

class ParentalControlFragment : GuidedStepSupportFragment() {

    override fun onCreateGuidance(savedInstanceState: Bundle?): GuidanceStylist.Guidance {
        val title = "PARENTAL CONTROL"
        val description = "Adult Content Management"
        val icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_parental)

        return GuidanceStylist.Guidance(title, description, "", icon)
    }

    override fun onCreateActions(actions: MutableList<GuidedAction>, savedInstanceState: Bundle?) {
        // Add parental control options here
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(999L)
                .title("Back")
                .icon(R.drawable.ic_back)
                .build()
        )
    }

    override fun onGuidedActionClicked(action: GuidedAction) {
        if (action.id == 999L) {
            fragmentManager?.popBackStack()
        }
    }
}