// TVShowDetailsActivity.kt
package com.example.hhhh

import android.os.Bundle
import androidx.fragment.app.FragmentActivity

class TVShowDetailsActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tvshow_details)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.tvshow_details_fragment, TVShowDetailsFragment())
                .commit()
        }
    }

    companion object {
        const val TVSHOW = "TVShow"
        const val SHARED_ELEMENT_NAME = "hero"
    }
}