package com.example.hhhh

import android.content.Context.MODE_PRIVATE
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.leanback.app.GuidedStepSupportFragment
import androidx.leanback.widget.GuidanceStylist
import androidx.leanback.widget.GuidedAction
import java.util.*

class LanguageFragment : GuidedStepSupportFragment() {

    private val PREFS_NAME = "app_settings"
    private val PREF_LANGUAGE = "app_language"

    private val languages = listOf(
        "English" to "en",
        "Spanish" to "es"
    )

    override fun onCreateGuidance(savedInstanceState: Bundle?): GuidanceStylist.Guidance {
        val title = getString(R.string.language_title)
        val description = getString(R.string.language_description)
        val icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_language)
        return GuidanceStylist.Guidance(title, description, "", icon)
    }

    override fun onCreateActions(actions: MutableList<GuidedAction>, savedInstanceState: Bundle?) {
        val currentLang = getCurrentLanguage()

        languages.forEachIndexed { index, pair ->
            val (langName, langCode) = pair
            actions.add(
                GuidedAction.Builder(requireContext())
                    .id(index.toLong())
                    .title(langName)
                    .checkSetId(0)
                    .checked(currentLang == langCode)
                    .build()
            )
        }

        actions.add(
            GuidedAction.Builder(requireContext())
                .id(999L)
                .title(getString(R.string.back))
                .icon(R.drawable.ic_back)
                .build()
        )
    }

    override fun onGuidedActionClicked(action: GuidedAction) {
        when (action.id) {
            999L -> fragmentManager?.popBackStack()
            in languages.indices.map { it.toLong() } -> {  // Dynamic handling
                val langCode = languages[action.id.toInt()].second
                saveLanguage(langCode)

                // Apply language globally
                (requireActivity().application as MyApp).applyLanguage()

                // Show toast
                Toast.makeText(
                    requireContext(),
                    "${languages[action.id.toInt()].first} " + getString(R.string.language_selected),
                    Toast.LENGTH_SHORT
                ).show()

                // Restart HomeActivity with new language
                val intent = Intent(requireActivity(), HomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
            }
        }
    }


    private fun saveLanguage(languageCode: String) {
        requireContext().getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putString(PREF_LANGUAGE, languageCode)
            .apply()
    }

    private fun getCurrentLanguage(): String {
        return requireContext().getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(PREF_LANGUAGE, Locale.getDefault().language) ?: "en"
    }
}
