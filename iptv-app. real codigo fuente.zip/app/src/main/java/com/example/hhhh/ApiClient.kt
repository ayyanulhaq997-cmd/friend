package com.example.hhhh.api

import android.content.Context
import com.example.hhhh.MyApp
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

// Simple session manager to hold username/password in memory
object SessionManager {
    var username: String? = null
    var password: String? = null

    fun save(context: Context, user: String, pass: String) {
        username = user
        password = pass
        context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE).edit().apply {
            putString("username", user)
            putString("password", pass)
            apply()
        }
    }

    fun load(context: Context) {
        val prefs = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        username = prefs.getString("username", null)
        password = prefs.getString("password", null)
    }

    fun clear(context: Context) {
        username = null
        password = null
        context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE).edit().clear().apply()
    }
}

object ApiClient {

    private const val BASE_URL = "http://192.168.0.130:8000/api/"
    //private const val BASE_URL = "https://reseller.g-media.digital/api/"

    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(600, TimeUnit.SECONDS)
        .readTimeout(600, TimeUnit.SECONDS)
        .writeTimeout(600, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .addInterceptor { chain ->
            val original = chain.request()
            val originalUrl = original.url()

            // Only add username/password if not null
            val urlBuilder = originalUrl.newBuilder()
            SessionManager.username?.let { urlBuilder.addQueryParameter("username", it) }
            SessionManager.password?.let { urlBuilder.addQueryParameter("password", it) }

            val request = original.newBuilder().url(urlBuilder.build()).build()
            chain.proceed(request)
        }
        .build()

    val api: ApiService by lazy {
        // Load credentials from SharedPreferences on first use
        SessionManager.load(MyApp.context)

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttp)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}
