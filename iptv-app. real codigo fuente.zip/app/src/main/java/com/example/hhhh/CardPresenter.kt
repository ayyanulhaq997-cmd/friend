package com.example.hhhh

import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.leanback.widget.ImageCardView
import androidx.leanback.widget.Presenter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation
import java.security.MessageDigest

class CardPresenter : Presenter() {

    private val CARD_WIDTH = 250
    private val CARD_HEIGHT = (CARD_WIDTH * 1.333).toInt()
    private val CORNER_RADIUS = 16

    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val context = parent.context

        val cardView = ImageCardView(context).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setBackgroundColor(ContextCompat.getColor(context, android.R.color.transparent))
            setMainImageDimensions(CARD_WIDTH, CARD_HEIGHT)
            setInfoAreaBackgroundColor(Color.parseColor("#75132d"))
        }

        cardView.post { wrapImageWithBadges(cardView) }

        cardView.setOnFocusChangeListener { v, hasFocus ->
            val infoArea = v.findViewById<View>(androidx.leanback.R.id.info_field)
            infoArea.setBackgroundColor(if (hasFocus) Color.parseColor("#c15168") else Color.parseColor("#75132d"))
            v.foreground = if (hasFocus) ContextCompat.getDrawable(context, R.drawable.card_border)
            else ContextCompat.getDrawable(context, R.drawable.card_selector)
        }

        return ViewHolder(cardView)
    }

    private fun wrapImageWithBadges(cardView: ImageCardView) {
        val context = cardView.context
        val mainImageView = cardView.mainImageView
        val imageParent = mainImageView.parent as? ViewGroup ?: return

        if (imageParent.findViewWithTag<FrameLayout>("image_wrapper") != null) return

        val originalLayoutParams = mainImageView.layoutParams
        val imageIndex = imageParent.indexOfChild(mainImageView)
        imageParent.removeView(mainImageView)

        val wrapper = FrameLayout(context).apply {
            tag = "image_wrapper"
            layoutParams = originalLayoutParams
        }

        mainImageView.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        wrapper.addView(mainImageView)
        wrapper.addView(createViewedBadge(context))
        wrapper.addView(createRatingBadge(context))

        imageParent.addView(wrapper, imageIndex)
        cardView.tag = BadgeHolder(wrapper.getChildAt(1) as LinearLayout, wrapper.getChildAt(2) as LinearLayout)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val movie = item as Movie
        val cardView = viewHolder.view as ImageCardView
        val context = cardView.context

        cardView.titleText = movie.title
        cardView.contentText = movie.released_year ?: ""

        Glide.with(context)
            .load(movie.card_url)
            .transform(TopRoundedCorners(CORNER_RADIUS))
            .error(R.drawable.default_poster)
            .into(cardView.mainImageView)

        (cardView.tag as? BadgeHolder)?.let { updateBadges(it, movie) }
    }

    private fun updateBadges(badgeHolder: BadgeHolder, movie: Movie) {
        badgeHolder.viewedBadge.visibility = if (movie.viewed == true) View.VISIBLE else View.GONE
        val rating = movie.rate ?: 0f
        badgeHolder.ratingBadge.visibility = if (rating > 0f) View.VISIBLE else View.GONE
        if (rating > 0f) {
            val ratingText = badgeHolder.ratingBadge.getChildAt(1) as TextView
            ratingText.text = String.format("%.1f", rating)
        }
    }

    private fun createViewedBadge(context: android.content.Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        background = createRoundedBackground(Color.parseColor("#DD000000"), 12f)
        setPadding(12, 6, 12, 6)
        visibility = View.GONE
        layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.START or Gravity.TOP; setMargins(10, 10, 10, 10) }

        val icon = ImageView(context).apply {
            setImageResource(android.R.drawable.ic_menu_view)
            setColorFilter(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(24, 24)
        }
        addView(icon)
    }

    private fun createRatingBadge(context: android.content.Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        background = createRoundedBackground(Color.parseColor("#DD000000"), 12f)
        setPadding(12, 6, 12, 6)
        visibility = View.GONE
        layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.END or Gravity.BOTTOM; setMargins(10, 10, 10, 10) }

        val star = ImageView(context).apply {
            setImageResource(android.R.drawable.btn_star_big_on)
            setColorFilter(Color.parseColor("#FFD700"))
            layoutParams = LinearLayout.LayoutParams(24, 24)
        }
        addView(star)

        val ratingText = TextView(context).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(8, 0, 0, 0)
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
        }
        addView(ratingText)
    }

    private fun createRoundedBackground(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder) {
        val cardView = viewHolder.view as ImageCardView

        val imageView = cardView.mainImageView

        // Ensure the view is still attached. If not, skip Glide completely.
        if (!imageView.isAttachedToWindow) {
            return
        }

        // Use the ImageView as the lifecycle owner (safest)
        Glide.with(imageView)
            .clear(imageView)

        cardView.badgeImage = null
        cardView.mainImage = null
    }



    private data class BadgeHolder(val viewedBadge: LinearLayout, val ratingBadge: LinearLayout)

    class TopRoundedCorners(private val radius: Int) : BitmapTransformation() {
        override fun updateDiskCacheKey(messageDigest: MessageDigest) {
            messageDigest.update("top_rounded_$radius".toByteArray())
        }

        override fun transform(pool: BitmapPool, toTransform: Bitmap, outWidth: Int, outHeight: Int): Bitmap {
            val result = pool.get(toTransform.width, toTransform.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(result)
            val paint = Paint().apply { isAntiAlias = true }
            val rect = RectF(0f, 0f, toTransform.width.toFloat(), toTransform.height.toFloat())
            val radii = floatArrayOf(radius.toFloat(), radius.toFloat(), radius.toFloat(), radius.toFloat(), 0f, 0f, 0f, 0f)
            val path = Path().apply { addRoundRect(rect, radii, Path.Direction.CW) }
            canvas.clipPath(path)
            canvas.drawBitmap(toTransform, 0f, 0f, paint)
            return result
        }
    }
}
