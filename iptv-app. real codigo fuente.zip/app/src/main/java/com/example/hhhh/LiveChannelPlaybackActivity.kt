// LiveChannelPlaybackActivity.kt - FIXED VERSION
package com.example.hhhh

import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide

class LiveChannelPlaybackActivity : FragmentActivity() {

    private var playerView: PlayerView? = null
    private var channelLogo: ImageView? = null
    private var channelTitle: TextView? = null
    private var loadingProgress: ProgressBar? = null
    private var player: ExoPlayer? = null

    private var streamUrl: String? = null
    private var channelName: String? = null
    private var logoUrl: String? = null

    companion object {
        private const val TAG = "LiveChannelPlayback"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            Log.d(TAG, "onCreate started")
            setContentView(R.layout.activity_live_channel_playback)
            Log.d(TAG, "Layout set successfully")

            // Get data from intent
            streamUrl = intent.getStringExtra("url")
            channelName = intent.getStringExtra("title")
            logoUrl = intent.getStringExtra("logo")

            Log.d(TAG, "Stream URL: $streamUrl")
            Log.d(TAG, "Channel: $channelName")
            Log.d(TAG, "Logo: $logoUrl")

            // Initialize views
            playerView = findViewById(R.id.playerView)
            channelLogo = findViewById(R.id.channelLogo)
            channelTitle = findViewById(R.id.channelTitle)
            loadingProgress = findViewById(R.id.loadingProgress)

            Log.d(TAG, "Views initialized")

            // Set channel info
            channelTitle?.text = channelName ?: "Live Channel"

            if (!logoUrl.isNullOrEmpty()) {
                try {
                    Glide.with(this)
                        .load(logoUrl)
                        .into(channelLogo!!)
                } catch (e: Exception) {
                    Log.e(TAG, "Error loading logo: ${e.message}")
                }
            }

            // Initialize player
            if (!streamUrl.isNullOrEmpty()) {
                Log.d(TAG, "Initializing player...")
                initializePlayer()
            } else {
                Log.e(TAG, "Stream URL is empty!")
                Toast.makeText(this, "Invalid stream URL", Toast.LENGTH_LONG).show()
                finish()
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error in onCreate: ${e.message}", e)
            e.printStackTrace()
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun initializePlayer() {
        try {
            Log.d(TAG, "Creating ExoPlayer instance...")

            // Create ExoPlayer using Media3
            player = ExoPlayer.Builder(this).build()
            Log.d(TAG, "ExoPlayer created successfully")

            // Attach player to view
            playerView?.player = player
            Log.d(TAG, "Player attached to view")

            // Create MediaItem directly (simpler approach)
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse(streamUrl!!))
                .build()

            Log.d(TAG, "MediaItem created: ${mediaItem.localConfiguration?.uri}")

            // Set media item and prepare
            player?.setMediaItem(mediaItem)
            player?.prepare()
            player?.playWhenReady = true

            Log.d(TAG, "Player prepared and ready to play")

            // Add player listener
            player?.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    val stateName = when (playbackState) {
                        Player.STATE_IDLE -> "IDLE"
                        Player.STATE_BUFFERING -> "BUFFERING"
                        Player.STATE_READY -> "READY"
                        Player.STATE_ENDED -> "ENDED"
                        else -> "UNKNOWN"
                    }
                    Log.d(TAG, "Playback state changed: $stateName")

                    when (playbackState) {
                        Player.STATE_BUFFERING -> {
                            loadingProgress?.visibility = View.VISIBLE
                        }
                        Player.STATE_READY -> {
                            loadingProgress?.visibility = View.GONE
                            Toast.makeText(
                                this@LiveChannelPlaybackActivity,
                                "Playing: $channelName",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                        Player.STATE_ENDED -> {
                            loadingProgress?.visibility = View.GONE
                        }
                        Player.STATE_IDLE -> {
                            // Do nothing
                        }
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    Log.e(TAG, "Playback error: ${error.errorCodeName}")
                    Log.e(TAG, "Error message: ${error.message}")
                    Log.e(TAG, "Error cause: ${error.cause?.message}")
                    error.printStackTrace()

                    loadingProgress?.visibility = View.GONE

                    val errorMessage = when (error.errorCode) {
                        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ->
                            "Network connection failed"
                        PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS ->
                            "Bad HTTP status"
                        PlaybackException.ERROR_CODE_TIMEOUT ->
                            "Connection timeout"
                        PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE ->
                            "Invalid content type"
                        else ->
                            "Playback error: ${error.message}"
                    }

                    Toast.makeText(
                        this@LiveChannelPlaybackActivity,
                        errorMessage,
                        Toast.LENGTH_LONG
                    ).show()
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    Log.d(TAG, "Is playing: $isPlaying")
                }
            })

        } catch (e: Exception) {
            Log.e(TAG, "Error initializing player: ${e.message}", e)
            e.printStackTrace()
            Toast.makeText(this, "Player error: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume called")
        player?.playWhenReady = true
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause called")
        player?.playWhenReady = false
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy called - releasing player")
        player?.release()
        player = null
    }

    override fun onBackPressed() {
        Log.d(TAG, "onBackPressed called")
        player?.release()
        player = null
        super.onBackPressed()
        finish()
    }
}