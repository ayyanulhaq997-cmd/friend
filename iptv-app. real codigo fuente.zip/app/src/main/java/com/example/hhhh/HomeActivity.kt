// HomeActivity.kt - Updated with Multi-language Support
package com.example.hhhh

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.example.hhhh.api.ApiClient
import com.example.hhhh.api.SessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HomeActivity : FragmentActivity() {

    private var getMeJob: Job? = null
    private var trailerData: List<MovieTrailer>? = null
    private var back_url: String? = "https://image.tmdb.org/t/p/w1280//l2ji4YiNSPBV69WjGBgU0gCvRqy.jpg"
    private var lastSelectedTrailerIndex: Int? = null
    private lateinit var player: ExoPlayer

    // Non-trailer views to hide/show
    private lateinit var nonTrailerViews: List<View>

    private lateinit var homePlayer: PlayerView

    override fun attachBaseContext(newBase: Context) {
        // Apply language before creating activity
        val localizedContext = (newBase.applicationContext as MyApp).getLocalizedContext(newBase)
        super.attachBaseContext(localizedContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        (application as MyApp).applyLanguage()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        homePlayer = findViewById(R.id.homePlayer)

        // Initially hide
        homePlayer.visibility = View.GONE

        // Only call getMe() on first creation
        if (savedInstanceState == null) {
            getMe()
        }

        setupViews()
        initPlayer()
    }

    private fun setupViews() {
        val backgroundImage = findViewById<ImageView>(R.id.backgroundImage)
        val logoImage = findViewById<ImageView>(R.id.logoImage)
        val expiryLabel = findViewById<TextView>(R.id.expiryLabel)
        val daysRemaining = findViewById<TextView>(R.id.daysRemaining)
        val featuredTitle = findViewById<TextView>(R.id.featuredTitle)
        val genreText = findViewById<TextView>(R.id.genreText)
        val btnMovies = findViewById<LinearLayout>(R.id.btnMovies)
        val btnTVShow = findViewById<LinearLayout>(R.id.btnTVShow)
        val btnChannels = findViewById<LinearLayout>(R.id.btnChannels)
        val btnSettings = findViewById<LinearLayout>(R.id.btnSettings)

        btnMovies.post {
            btnMovies.requestFocus()
        }

        // Trailer indicators
        val indicators = listOf(
            findViewById<View>(R.id.trailer_0),
            findViewById<View>(R.id.trailer_1),
            findViewById<View>(R.id.trailer_2),
            findViewById<View>(R.id.trailer_3),
            findViewById<View>(R.id.trailer_4)
        )

        // Initialize non-trailer views list
        nonTrailerViews = listOf(
            logoImage,
            expiryLabel,
            daysRemaining,
            featuredTitle,
            genreText,
            btnMovies,
            btnTVShow,
            btnChannels,
            btnSettings
        )

        // Load default background
        Glide.with(this).load(back_url).centerCrop().into(backgroundImage)

        // Buttons click listeners
        btnMovies.setOnClickListener { startActivity(Intent(this, MovieActivity::class.java)) }
        btnTVShow.setOnClickListener { startActivity(Intent(this, TVShowsActivity::class.java)) }
        btnChannels.setOnClickListener { startActivity(Intent(this, LiveChannelsActivity::class.java)) }
        btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }

        // Trailer click listeners
        indicators.forEachIndexed { index, view ->
            view.setOnClickListener { updateTrailerShow(index) }
        }
    }

    private fun getMe() {
        getMeJob?.cancel()
        getMeJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = ApiClient.api.user()
                withContext(Dispatchers.Main) {
                    if (isDestroyed || isFinishing) return@withContext
                    if (response.status == true) {
                        Toast.makeText(
                            this@HomeActivity,
                            response.message ?: getString(R.string.get_user_success),
                            Toast.LENGTH_SHORT
                        ).show()
                        trailerData = response.movie_trailers
                        setUserInfo(response)
                    } else {
                        handleLogoutAndRedirect()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    if (isDestroyed || isFinishing) return@withContext
                    Toast.makeText(
                        this@HomeActivity,
                        getString(R.string.get_user_error, e.message),
                        Toast.LENGTH_LONG
                    ).show()
                    handleLogoutAndRedirect()
                }
            }
        }
    }

    private fun handleLogoutAndRedirect() {
        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        prefs.edit().clear().apply()
        SessionManager.clear(this)
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }, 3000)
    }

    private fun setUserInfo(data: UserResponse) {
        findViewById<TextView>(R.id.expiryLabel).text = data.expired_date ?: ""
        findViewById<TextView>(R.id.daysRemaining).text = data.expired_later ?: ""
        if (!trailerData.isNullOrEmpty()) {
            updateTrailerShow(0, true)
        }
    }

    private fun updateTrailerShow(index: Int, isFirst: Boolean = false) {
        val item = trailerData?.getOrNull(index) ?: return
        val url = item.trailer_url ?: ""

        // Change the title and genre and date
        findViewById<TextView>(R.id.featuredTitle).text = item.title ?: ""
        findViewById<TextView>(R.id.genreText).text = item.genre ?: ""
        findViewById<TextView>(R.id.durationText).text = item.duration ?: ""
        findViewById<TextView>(R.id.releaseText).text = item.release ?: ""

        // Stop previous playback & restore UI if switching
        if (lastSelectedTrailerIndex != null && lastSelectedTrailerIndex != index) {
            player.stop()
            player.clearMediaItems()
            showNonTrailerUI()
        }

        // Restart same trailer if clicked again
        if (lastSelectedTrailerIndex == index && !isFirst) {
            if (isYouTubeUrl(url)) {
                showNonTrailerUI()
                openYouTube(url)
            } else {
                hideNonTrailerUI()
                playTrailer(url)
            }
        }

        lastSelectedTrailerIndex = index

        // Update background image
        Glide.with(this).load(item.bg_url ?: "").centerCrop()
            .into(findViewById(R.id.backgroundImage))

        // Update trailer indicators
        updateTrailerIndicators(index)
    }

    private fun updateTrailerIndicators(selectedIndex: Int) {
        val indicators = listOf(
            findViewById<View>(R.id.trailer_0),
            findViewById<View>(R.id.trailer_1),
            findViewById<View>(R.id.trailer_2),
            findViewById<View>(R.id.trailer_3),
            findViewById<View>(R.id.trailer_4)
        )

        indicators.forEachIndexed { index, view ->
            val colorRes = if (index == selectedIndex)
                R.color.selected_home_trailer
            else
                R.color.unselected_home_trailer

            view.setBackgroundColor(ContextCompat.getColor(this, colorRes))
        }
    }

    private fun hideNonTrailerUI() {
        nonTrailerViews.forEach { it.visibility = View.GONE }
    }

    private fun showNonTrailerUI() {
        nonTrailerViews.forEach { it.visibility = View.VISIBLE }
    }

    private fun playTrailer(url: String) {
        homePlayer.visibility = View.VISIBLE
        val mediaItem = MediaItem.fromUri(url)
        player.setMediaItem(mediaItem)
        player.prepare()
        player.play()
    }

    private fun initPlayer() {
        player = ExoPlayer.Builder(this).build()
        homePlayer.player = player
    }

    private fun openYouTube(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    private fun isYouTubeUrl(url: String?): Boolean {
        return !url.isNullOrEmpty() && (url.contains("youtube.com") || url.contains("youtu.be"))
    }

    override fun onDestroy() {
        super.onDestroy()
        getMeJob?.cancel()
        player.release()
    }

    override fun onBackPressed() {
        getMeJob?.cancel()
        super.onBackPressed()
    }
}