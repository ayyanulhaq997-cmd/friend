package com.example.hhhh

data class EpisodePlayBackPositionResponse(
    val lastPosition: Long,
    val status : Boolean
)