package com.example.hhhh

data class MovieModel(
    val id: Int = 0,
    val title: String = "",
    val imageUrl: String = ""
)
