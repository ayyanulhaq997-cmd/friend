package com.example.hhhh

import androidx.leanback.widget.AbstractDetailsDescriptionPresenter

class DetailsDescriptionPresenter : AbstractDetailsDescriptionPresenter() {

    override fun onBindDescription(
        viewHolder: ViewHolder,
        item: Any
    ) {
        val movie = item as MovieDetail

        viewHolder.title.text = movie.title ?: "No Title"

        // Subtitle: studio + rating + quality
        val subtitleParts = listOfNotNull(
            movie.studio,
            movie.rating?.let { "★ $it" },
            movie.video_quality
        ).filter { it.isNotEmpty() }

        viewHolder.subtitle.text =
            if (subtitleParts.isNotEmpty()) subtitleParts.joinToString(" • ")
            else "Unknown"

        // Body text
        viewHolder.body.text =
            movie.description?.takeIf { it.isNotBlank() }
                ?: "No description available."
    }
}
