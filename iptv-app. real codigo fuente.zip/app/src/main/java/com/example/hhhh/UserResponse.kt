package com.example.hhhh
import com.example.hhhh.MovieTrailer
data class UserResponse(
    val status: Boolean?=false,
    val expired_date: String? = "",
    var message:String? = "",
    val expired_later: String? = "",
    val movie_trailers: List<MovieTrailer> ? = null
)


data class UserSettingDataResponse(
    val status: Boolean?=false,
    val username:String? = "",
    val expired_date: String? = "",
    var message:String? = "",
    var credits:String?=""

)

data class ChangePasswordRequest(
    val old_password: String,
    val new_password: String
)

data class BasicResponse(
    val status: Boolean,
    val message: String?
)