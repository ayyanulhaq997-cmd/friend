package com.example.hhhh

data class SignedUrlResponse(
    val signedUrl: String,
    val status : Boolean
)