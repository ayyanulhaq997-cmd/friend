package com.example.hhhh

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.example.hhhh.api.ApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class VideoDetailsFragment : Fragment(R.layout.video_details_custom) {

    private var mSelectedMovie: Movie? = null
    private var mMovieDetail: MovieDetail? = null

    // UI Components
    private lateinit var backgroundImage: ImageView
    private lateinit var posterImage: ImageView
    private lateinit var titleText: TextView
    private lateinit var genresText: TextView
    private lateinit var durationText: TextView
    private lateinit var yearText: TextView
    private lateinit var ratingText: TextView
    private lateinit var descriptionText: TextView
    private lateinit var actionsContainer: LinearLayout

    // Keep track of selections
    private var selectedAudioIndex = 0
    private var selectedSubtitleIndex = 1
    private var subtitleColor = Color.WHITE
    private var subtitleSize = 0.06f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        mSelectedMovie = requireActivity()
            .intent.getSerializableExtra(DetailsActivity.MOVIE) as? Movie

        if (mSelectedMovie == null) {
            startActivity(Intent(requireActivity(), MovieActivity::class.java))
            return
        }

        loadMovieDetail()
    }

    override fun onViewCreated(view: android.view.View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize UI components
        backgroundImage = view.findViewById(R.id.backgroundImage)
        posterImage = view.findViewById(R.id.posterImage)
        titleText = view.findViewById(R.id.titleText)
        genresText = view.findViewById(R.id.genresText)
        durationText = view.findViewById(R.id.durationText)
        yearText = view.findViewById(R.id.yearText)
        ratingText = view.findViewById(R.id.ratingText)
        descriptionText = view.findViewById(R.id.descriptionText)
        actionsContainer = view.findViewById(R.id.actionsContainer)

        setupUI()
    }

    private fun setupUI() {
        if (mMovieDetail == null) return

        // Load background image
        Glide.with(requireActivity())
            .asBitmap()
            .centerCrop()
            .error(R.drawable.default_background)
            .load(mSelectedMovie?.bg_url)
            .into(object : SimpleTarget<Bitmap>() {
                override fun onResourceReady(bitmap: Bitmap, transition: Transition<in Bitmap>?) {
                    backgroundImage.setImageBitmap(bitmap)
                }
            })

        // Load poster image
        Glide.with(requireActivity())
            .load(mSelectedMovie?.card_url)
            .centerCrop()
            .error(R.drawable.default_background)
            .into(posterImage)

        // Set text data
        titleText.text = mMovieDetail?.title ?: "N/A"
        genresText.text = mMovieDetail?.genre_names?: "N/A"
        durationText.text = "${mMovieDetail?.runtime ?: 0}"
        yearText.text = mMovieDetail?.released_year?.toString() ?: "N/A"
        ratingText.text = mMovieDetail?.rating?.toString() ?: "0"
        val htmlString = mMovieDetail?.description ?: "<p>No description available</p>"
        descriptionText.text = Html.fromHtml(htmlString, Html.FROM_HTML_MODE_LEGACY)

        // Setup action buttons
        setupActionButtons()
    }

    private fun setupActionButtons() {
        actionsContainer.removeAllViews()

        val actions = listOf(
            "WATCH NOW" to { startPlayback() },
            "WATCH TRAILER" to { playYouTubeTrailer(mMovieDetail?.trailler_youtube_source) },
            "ADD TO FAVORITES" to { toggleFavorite() },
            "AUDIO: ${getAudioLabel(selectedAudioIndex)}" to { showAudioSelection() },
            "SUBTITLE: ${getSubtitleLabel(selectedSubtitleIndex)}" to { showSubtitleSelection() }
        )

        for ((label, action) in actions) {
            val button = createActionButton(label, action)
            actionsContainer.addView(button)
        }
    }

    private fun createActionButton(label: String, action: () -> Unit): TextView {
        return TextView(requireContext()).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(16, 12, 16, 12)
            setBackgroundColor(Color.parseColor("#66000000"))
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
        }
    }

    private fun getAudioLabel(index: Int) = when (index) {
        0 -> "English"
        1 -> "Spanish"
        2 -> "Mute"
        else -> "Unknown"
    }

    private fun getSubtitleLabel(index: Int) = when (index) {
        0 -> "Disabled"
        1 -> "English"
        2 -> "Spanish"
        else -> "Unknown"
    }

    private fun startPlayback() {
        val intent = Intent(requireActivity(), PlaybackActivity::class.java)
        intent.putExtra(DetailsActivity.MOVIE, mSelectedMovie)
        intent.putExtra("audioIndex", selectedAudioIndex)
        intent.putExtra("subtitleIndex", selectedSubtitleIndex)
        intent.putExtra("subtitleColor", subtitleColor)
        intent.putExtra("subtitleSize", subtitleSize)
        intent.putExtra("savedPosition", mMovieDetail?.last_position)
        startActivity(intent)
    }

    private fun playYouTubeTrailer(url: String?) {
        if (url.isNullOrEmpty()) {
            Toast.makeText(requireActivity(), "Trailer not available", Toast.LENGTH_SHORT).show()
            return
        }
        val videoId = extractYouTubeId(url)
        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/watch?v=$videoId"))
        startActivity(intent)
    }

    private fun extractYouTubeId(url: String) = "(?<=watch\\?v=|/videos/|embed/|youtu.be/)[^#&?]*".toRegex().find(url)?.value ?: url

    private fun showAudioSelection() {
        val options = arrayOf("English", "Spanish", "Mute")
        android.app.AlertDialog.Builder(requireActivity())
            .setTitle("Select Audio")
            .setSingleChoiceItems(options, selectedAudioIndex) { dialog, which ->
                selectedAudioIndex = which
                setupActionButtons()
                dialog.dismiss()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun showSubtitleSelection() {
        val options = arrayOf("Disabled", "English", "Spanish")
        android.app.AlertDialog.Builder(requireActivity())
            .setTitle("Select Subtitle")
            .setSingleChoiceItems(options, selectedSubtitleIndex) { dialog, which ->
                selectedSubtitleIndex = which
                setupActionButtons()
                dialog.dismiss()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun toggleFavorite() {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response = ApiClient.api.addMovieFavorite(mSelectedMovie!!.videos_id)
                if (response.status) {
                    val message = if (response.favorite == 1) "Added to favorites" else "Removed from favorites"
                    Toast.makeText(requireActivity(), message, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireActivity(), "Failed to update favorite", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error updating favorite: ${e.message}")
            }
        }
    }

    private fun loadMovieDetail() {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response = ApiClient.api.getMovieDetail(mSelectedMovie!!.videos_id)
                mMovieDetail = response.data

                if (isAdded) {
                    setupUI()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error loading movie detail: ${e.message}")
            }
        }
    }

    companion object {
        const val TAG = "VideoDetailsFragment"
    }
}