package com.example.hhhh

import java.io.Serializable

/**
 * Movie class represents video entity with title, description, image thumbs and video url.
 */
data class Movie(
    var videos_id: Long = 0,
    var title: String? = null,
    var release: String? = null,
    var released_year: String? = null,
    var viewed: Boolean? = false,
    var rate: Float? = 0f,
    var bg_url: String? = null,
    var card_url: String? = null

) : Serializable