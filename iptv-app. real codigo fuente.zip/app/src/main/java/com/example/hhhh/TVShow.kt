// TVShow.kt
package com.example.hhhh

import java.io.Serializable

data class TVShow(
    val id: String?="",
    val title: String?="",
    val description: String?="",
    val card_url: String?="",
    var favorite : Boolean?=false,
    val bg_url: String?="",
    val released_year: String?,
    val viewed: Boolean?=false,
    val rate: Float? =0f,
    val genre_names: String?,
    val seasons: List<Season> = emptyList()
) : Serializable

data class Season(
    val  id: Int?=0,
    val  series_id: Int?=0,
    val season_number: Int?=0,
    val release_year: String?="",
    val episodes: List<Episode>
) : Serializable

data class Episode(
    val id: Int?=0,
    val episodeNumber: Int?=0,
    val seasonNumber: Int?=0,
    val title: String?="",
    val video_url: String?="",
    val viewed:  Boolean ?=false,
    val rating: Float?=0f,
    val last_position: Long? = null,
    val track: String? = "es"
) : Serializable



data class TVShowCategory(
    val  id: Int?=0,
    val name: String?="",
    val shows: List<TVShow>
) : Serializable

// API Response
data class TVShowsResponse(
    val  status : Boolean,
    val  data: List<TVShowCategory>
)