package com.example.hhhh

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.example.hhhh.api.MovieApi
import com.example.hhhh.api.TVShowApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class TVShowFavoriteActivity : AppCompatActivity() {

    private val TAG = "TVShowFavoriteActivity"
    private var job: Job? = null

    private lateinit var loadingBar: ProgressBar
    private lateinit var recyclerView: RecyclerView
    private lateinit var rootLayout: View

    private val allFavoriteTVShows = mutableListOf<TVShow>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tvshow_favorite)

        rootLayout = findViewById(R.id.rootLayoutFavorite)
        loadingBar = findViewById(R.id.loadingBar)
        recyclerView = findViewById(R.id.recyclerViewFavorites)

        loadFavoriteTVShow()
    }

    private fun loadFavoriteTVShow() {
        job?.cancel()

        job = CoroutineScope(Dispatchers.Main).launch {
            try {
                loadingBar.visibility = View.VISIBLE

                val response = TVShowApi.getFavoriteTVShows()

                loadingBar.visibility = View.GONE

                if (response?.data != null) {
                    allFavoriteTVShows.clear()

                    response.data.forEach { category ->
                        category.shows?.let { allFavoriteTVShows.addAll(it) }
                    }

                    if (allFavoriteTVShows.isNotEmpty()) {
                        displayFavorites(allFavoriteTVShows)
                    } else {
                        Toast.makeText(this@TVShowFavoriteActivity, "No favorites found", Toast.LENGTH_LONG).show()
                    }

                } else {
                    Toast.makeText(this@TVShowFavoriteActivity, "Failed to load favorites", Toast.LENGTH_LONG).show()
                }

            } catch (e: Exception) {
                Log.e(TAG, "Error loading favorites", e)
                loadingBar.visibility = View.GONE
            }
        }
    }

    private fun displayFavorites(favorites: List<TVShow>) {
        val adapter = FavoriteTVShowAdapter(
            favorites,
            onItemClick = { show -> navigateToTVShowDetails(show) },
            onItemFocused = { show -> updateBackground(show) }
        )

        recyclerView.layoutManager = GridLayoutManager(this, 5)
        recyclerView.adapter = adapter
    }

    private fun updateBackground(show: TVShow) {
        Glide.with(this)
            .load(show.bg_url)
            .transform(jp.wasabeef.glide.transformations.BlurTransformation(25, 4))
            .centerCrop()
            .into(object : CustomTarget<Drawable>() {
                override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable>?) {
                    rootLayout.background = resource
                }

                override fun onLoadCleared(placeholder: Drawable?) {}
            })
    }


    private fun navigateToTVShowDetails(show: TVShow) {
        val intent = android.content.Intent(this, TVShowDetailsActivity::class.java)
        intent.putExtra(TVShowDetailsActivity.TVSHOW, show)
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        job?.cancel()
    }
}
