// EpisodePresenter.kt
package com.example.hhhh

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.leanback.widget.Presenter
import com.bumptech.glide.Glide

class EpisodePresenter : Presenter() {

    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val view = android.widget.LinearLayout(parent.context).apply {
            orientation = android.widget.LinearLayout.HORIZONTAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(32, 24, 32, 24)
            setBackgroundColor(Color.parseColor("#2A2A2A"))
            isFocusable = true
            isFocusableInTouchMode = true
        }

        // Viewed icon (left)
        val viewedIcon = ImageView(parent.context).apply {
            setImageResource(android.R.drawable.ic_menu_view)
            setColorFilter(Color.WHITE)
            layoutParams = android.widget.LinearLayout.LayoutParams(40, 40).apply {
                marginEnd = 24
            }
            visibility = View.GONE
        }
        view.addView(viewedIcon)

        // Episode text (center, takes remaining space)
        val episodeTitle = TextView(parent.context).apply {
            textSize = 20f
            setTextColor(Color.WHITE)
            layoutParams = android.widget.LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            )
        }
        view.addView(episodeTitle)

        // Language flag (right)
        val flagIcon = ImageView(parent.context).apply {
            setImageResource(android.R.drawable.ic_dialog_info)
            setColorFilter(Color.parseColor("#FF9800"))
            layoutParams = android.widget.LinearLayout.LayoutParams(48, 32)
        }
        view.addView(flagIcon)

        // Focus effect
        view.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.setBackgroundColor(Color.parseColor("#4A4A4A"))
                (v as android.widget.LinearLayout).apply {
                    setPadding(28, 20, 28, 20) // Slightly smaller padding when focused for visual effect
                }
            } else {
                v.setBackgroundColor(Color.parseColor("#2A2A2A"))
                (v as android.widget.LinearLayout).apply {
                    setPadding(32, 24, 32, 24)
                }
            }
        }

        view.tag = EpisodeViewHolder(viewedIcon, episodeTitle, flagIcon)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val episode = item as Episode
        val holder = viewHolder.view.tag as EpisodeViewHolder

        // Set episode text
        holder.episodeTitle.text = "${episode.episodeNumber} - ${episode.title}"

        // Show viewed icon if watched
        holder.viewedIcon.visibility = if (episode.viewed == true) View.VISIBLE else View.GONE

        // Set flag based on audio language (you can customize this)
        // holder.flagIcon.setImageResource(getFlagResource(episode.audioLanguage))
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder) {
        // Nothing to unbind
    }

    private data class EpisodeViewHolder(
        val viewedIcon: ImageView,
        val episodeTitle: TextView,
        val flagIcon: ImageView
    )
}