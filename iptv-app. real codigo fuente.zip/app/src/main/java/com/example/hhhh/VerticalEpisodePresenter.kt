package com.example.hhhh

import android.graphics.Color
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.leanback.widget.Presenter

class VerticalEpisodePresenter : Presenter() {

    private val CARD_WIDTH = 190
    private val CARD_HEIGHT = 110

    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val context = parent.context

        // Main card container
        val cardView = android.widget.FrameLayout(context).apply {
            layoutParams = ViewGroup.LayoutParams(CARD_WIDTH, CARD_HEIGHT)
            setBackgroundColor(Color.parseColor("#1A1A1A"))
            isFocusable = true
            isFocusableInTouchMode = true
        }

        // Episode number text
        val episodeText = TextView(context).apply {
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(16, 16, 16, 16)
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = android.view.Gravity.START or android.view.Gravity.CENTER_VERTICAL
            }
        }
        cardView.addView(episodeText)

        // Info icon (bottom right)
        val infoIcon = ImageView(context).apply {
            setImageResource(android.R.drawable.ic_dialog_info)
            setColorFilter(Color.parseColor("#FFA500"))
            layoutParams = android.widget.FrameLayout.LayoutParams(40, 40).apply {
                gravity = android.view.Gravity.END or android.view.Gravity.BOTTOM
                marginEnd = 12
                bottomMargin = 12
            }
        }
        cardView.addView(infoIcon)

        // Focus effect
        cardView.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.setBackgroundColor(Color.parseColor("#3A3A3A"))
                v.scaleX = 1.05f
                v.scaleY = 1.05f
            } else {
                v.setBackgroundColor(Color.parseColor("#1A1A1A"))
                v.scaleX = 1.0f
                v.scaleY = 1.0f
            }
        }

        cardView.tag = EpisodeViewHolder(episodeText, infoIcon)
        return ViewHolder(cardView)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val episode = item as Episode
        val holder = viewHolder.view.tag as EpisodeViewHolder

        // Format: "1 - 1-1" (Episode number - Season-Episode)
        holder.episodeText.text = "${episode.episodeNumber} - ${episode.seasonNumber}-${episode.episodeNumber}"
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder) {}

    private data class EpisodeViewHolder(
        val episodeText: TextView,
        val infoIcon: ImageView
    )
}