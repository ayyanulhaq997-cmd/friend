// CardPresenter.kt
package com.example.hhhh

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.leanback.widget.ImageCardView
import androidx.leanback.widget.Presenter
import com.bumptech.glide.Glide
import androidx.core.graphics.toColorInt
import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation
import java.security.MessageDigest

class TVShowCardPresenter : Presenter() {

    private val CARD_WIDTH = 300
    private val CARD_HEIGHT = 200 // 2:3 ratio
    private val CORNER_RADIUS = 16
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val context = parent.context

        val cardView = ImageCardView(context).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setBackgroundColor(ContextCompat.getColor(context, android.R.color.transparent))
            setMainImageDimensions(CARD_WIDTH, CARD_HEIGHT)
            setInfoAreaBackgroundColor("#75132d".toColorInt())
        }

        cardView.post { wrapImageWithBadges(cardView) }

        cardView.setOnFocusChangeListener { v, hasFocus ->
            val infoArea = v.findViewById<View>(androidx.leanback.R.id.info_field)
            infoArea.setBackgroundColor(if (hasFocus) "#c15168".toColorInt() else "#75132d".toColorInt())
            v.foreground = if (hasFocus) ContextCompat.getDrawable(context, R.drawable.card_border)
            else ContextCompat.getDrawable(context, R.drawable.card_selector)
        }

        return ViewHolder(cardView)
    }

    private fun wrapImageWithBadges(cardView: ImageCardView) {
        val context = cardView.context
        val mainImageView = cardView.mainImageView
        val imageParent = mainImageView.parent as? ViewGroup ?: return

        if (imageParent.findViewWithTag<FrameLayout>("image_wrapper") != null) return

        val originalLayoutParams = mainImageView.layoutParams
        val imageIndex = imageParent.indexOfChild(mainImageView)
        imageParent.removeView(mainImageView)

        val wrapper = FrameLayout(context).apply {
            tag = "image_wrapper"
            layoutParams = originalLayoutParams
        }

        mainImageView.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        wrapper.addView(mainImageView)
        wrapper.addView(createViewedBadge(context))
        wrapper.addView(createRatingBadge(context))

        imageParent.addView(wrapper, imageIndex)
        cardView.tag = BadgeHolder(wrapper.getChildAt(1) as LinearLayout, wrapper.getChildAt(2) as LinearLayout)
    }


    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val tv_show = item as TVShow
        val cardView = viewHolder.view as ImageCardView
        val context = cardView.context

        cardView.titleText = tv_show.title
        cardView.contentText = tv_show.released_year ?: ""

        Glide.with(context)
            .load(tv_show.card_url)
            .transform(TopRoundedCorners(CORNER_RADIUS))
            .error(R.drawable.default_poster)
            .into(cardView.mainImageView)

        (cardView.tag as? BadgeHolder)?.let { updateBadges(it, tv_show) }
    }

    private fun updateBadges(badgeHolder: BadgeHolder, tv_show: TVShow) {
        badgeHolder.viewedBadge.visibility = if (tv_show.viewed == true) View.VISIBLE else View.GONE
        val rating = tv_show.rate ?: 0f
        badgeHolder.ratingBadge.visibility = if (rating > 0f) View.VISIBLE else View.GONE
        if (rating > 0f) {
            val ratingText = badgeHolder.ratingBadge.getChildAt(1) as TextView
            ratingText.text = String.format("%.1f", rating)
        }
    }


    private fun createViewedBadge(context: android.content.Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        background = createRoundedBackground("#DD000000".toColorInt(), 12f)
        setPadding(12, 6, 12, 6)
        visibility = View.GONE
        layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.START or Gravity.TOP; setMargins(10, 10, 10, 10) }

        val icon = ImageView(context).apply {
            setImageResource(android.R.drawable.ic_menu_view)
            setColorFilter(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(24, 24)
        }
        addView(icon)
    }

    private fun createRatingBadge(context: android.content.Context): LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        background = createRoundedBackground("#DD000000".toColorInt(), 12f)
        setPadding(12, 6, 12, 6)
        visibility = View.GONE
        layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.END or Gravity.BOTTOM; setMargins(10, 10, 10, 10) }

        val star = ImageView(context).apply {
            setImageResource(android.R.drawable.btn_star_big_on)
            setColorFilter("#FFD700".toColorInt())
            layoutParams = LinearLayout.LayoutParams(24, 24)
        }
        addView(star)

        val ratingText = TextView(context).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(8, 0, 0, 0)
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
        }
        addView(ratingText)
    }

    private fun createBadgeBackground(): GradientDrawable {
        return GradientDrawable().apply {
            setColor("#DD000000".toColorInt()) // Semi-transparent black
            cornerRadius = 16f
        }
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder) {
        val cardView = viewHolder.view as ImageCardView

        val imageView = cardView.mainImageView

        // Ensure the view is still attached. If not, skip Glide completely.
        if (!imageView.isAttachedToWindow) {
            return
        }

        // Use the ImageView as the lifecycle owner (safest)
        Glide.with(imageView)
            .clear(imageView)

        cardView.badgeImage = null
        cardView.mainImage = null
    }
    private fun createRoundedBackground(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }
    private data class BadgeHolder(val viewedBadge: LinearLayout, val ratingBadge: LinearLayout)

    class TopRoundedCorners(private val radius: Int) : BitmapTransformation() {
        override fun updateDiskCacheKey(messageDigest: MessageDigest) {
            messageDigest.update("top_rounded_$radius".toByteArray())
        }

        override fun transform(pool: BitmapPool, toTransform: Bitmap, outWidth: Int, outHeight: Int): Bitmap {
            val result = pool.get(toTransform.width, toTransform.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(result)
            val paint = Paint().apply { isAntiAlias = true }
            val rect = RectF(0f, 0f, toTransform.width.toFloat(), toTransform.height.toFloat())
            val radii = floatArrayOf(radius.toFloat(), radius.toFloat(), radius.toFloat(), radius.toFloat(), 0f, 0f, 0f, 0f)
            val path = Path().apply { addRoundRect(rect, radii, Path.Direction.CW) }
            canvas.clipPath(path)
            canvas.drawBitmap(toTransform, 0f, 0f, paint)
            return result
        }
    }
}