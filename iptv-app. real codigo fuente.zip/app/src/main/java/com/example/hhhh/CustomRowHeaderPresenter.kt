// CustomRowHeaderPresenter.kt - ENHANCED VERSION WITH MORE EFFECTS
package com.example.hhhh

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.TextView
import androidx.leanback.widget.Presenter
import androidx.leanback.widget.RowHeaderPresenter

class CustomRowHeaderPresenter : RowHeaderPresenter() {

    companion object {
        private const val CORNER_RADIUS = 16f
        private const val PADDING_HORIZONTAL = 32
        private const val PADDING_VERTICAL = 20
        private const val TEXT_SIZE = 18f
        private const val ELEVATION_FOCUSED = 12f
        private const val ELEVATION_DEFAULT = 0f
    }

    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val view = super.onCreateViewHolder(parent).view as TextView

        // Style the TextView
        view.apply {
            setPadding(PADDING_HORIZONTAL, PADDING_VERTICAL, PADDING_HORIZONTAL, PADDING_VERTICAL)
            background = createRoundedBackground(false)
            isFocusable = true
            isFocusableInTouchMode = true
            gravity = Gravity.CENTER_VERTICAL
            textSize = TEXT_SIZE
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#B3FFFFFF"))
            elevation = ELEVATION_DEFAULT
        }

        setupHoverEffect(view)

        return ViewHolder(view)
    }

    private fun setupHoverEffect(view: TextView) {
        view.setOnFocusChangeListener { v, hasFocus ->
            val textView = v as TextView

            if (hasFocus) {
                // Hover effect: scale, elevate, change background and text
                v.animate()
                    .scaleX(1.08f)
                    .scaleY(1.08f)
                    .translationZ(ELEVATION_FOCUSED)
                    .setDuration(250)
                    .withStartAction {
                        v.background = createRoundedBackground(true)
                        textView.setTextColor(Color.WHITE)
                    }
                    .start()
            } else {
                // Remove hover effect
                v.animate()
                    .scaleX(1.0f)
                    .scaleY(1.0f)
                    .translationZ(ELEVATION_DEFAULT)
                    .setDuration(250)
                    .withEndAction {
                        v.background = createRoundedBackground(false)
                        textView.setTextColor(Color.parseColor("#B3FFFFFF"))
                    }
                    .start()
            }
        }
    }

    private fun createRoundedBackground(isFocused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = CORNER_RADIUS

            if (isFocused) {
                // Focused state: gradient background with border
                colors = intArrayOf(
                    Color.parseColor("#60FFFFFF"), // Top: 38% white
                    Color.parseColor("#40FFFFFF")  // Bottom: 25% white
                )
                gradientType = GradientDrawable.LINEAR_GRADIENT
                orientation = GradientDrawable.Orientation.TOP_BOTTOM
                setStroke(3, Color.parseColor("#FFFFFFFF")) // White border
            } else {
                // Default state: subtle solid background
                setColor(Color.parseColor("#15FFFFFF")) // 8% white
                setStroke(0, Color.TRANSPARENT)
            }
        }
    }
}