package com.example.hhhh

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.leanback.widget.Presenter
import androidx.core.text.HtmlCompat
class MovieDetailsPresenter : Presenter() {

    override fun onCreateViewHolder(parent: ViewGroup?): ViewHolder {
        val view = LayoutInflater.from(parent?.context)
            .inflate(R.layout.movie_details_description, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder?, item: Any?) {
        val movie = item as MovieDetail
        val view = viewHolder!!.view

        val title = view.findViewById<TextView>(R.id.title)
        val genres = view.findViewById<TextView>(R.id.genres)
        val duration = view.findViewById<TextView>(R.id.duration)
        val year = view.findViewById<TextView>(R.id.year)
        val rating = view.findViewById<TextView>(R.id.rating)
        val desc = view.findViewById<TextView>(R.id.description)
        // Favorite & Viewed containers (to show/hide the whole block if needed)

        val favoriteIcon = view.findViewById<ImageView>(R.id.favorite_icon)
        val viewedIcon   = view.findViewById<ImageView>(R.id.viewed_icon)
        val favoriteText   = view.findViewById<TextView>(R.id.favorite_text)
        val viewedText   = view.findViewById<TextView>(R.id.viewed_text)
        title.text = movie.title

        genres.text = movie.genre_names

        duration.text = movie.runtime  // you can update to real data later
        year.text = movie.released_year.toString()  // replace with movie.year

        rating.text = movie.rating ?: "N/A"


        favoriteIcon.visibility   = if (movie.favorite == true) View.VISIBLE else View.GONE
        favoriteText.visibility   = if (movie.favorite == true) View.VISIBLE else View.GONE
        viewedIcon.visibility     = if (movie.viewed == true)   View.VISIBLE else View.GONE
        viewedText.visibility     = if (movie.viewed == true)   View.VISIBLE else View.GONE

        desc.text = HtmlCompat.fromHtml(
            movie.description ?: "",
            HtmlCompat.FROM_HTML_MODE_LEGACY
        )
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder?) {}
}
