package com.example.hhhh
import java.io.Serializable
class MovieTrailer (
    var id: Int = 0,
    var title: String? = null,
    var quality: String? = null,
    var trailer_url: String? = null,
    var bg_url: String? = null,
    var source: String? = null,
    var release: String? = null,
    var genre: String? = null,
    var duration: String? = null,
    var language: String? = null
): Serializable