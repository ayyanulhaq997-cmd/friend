// TVShowApi.kt - Updated to use your existing ApiClient
package com.example.hhhh.api

import android.util.Log
import com.example.hhhh.TVShowsResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object TVShowApi {

    private const val TAG = "TVShowApi"

    // Get all TV show categories
    suspend fun getTVShowCategories(): TVShowsResponse? = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.api.getTVShows()
            Log.d(TAG, "Successfully loaded TV show categories")
            response
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching TV show categories: ${e.message}")
            null
        }
    }

    // Get favorite TV shows
    suspend fun getFavoriteTVShows(): TVShowsResponse? = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.api.getFavoriteTVShow() // Adjust endpoint if needed
            Log.d(TAG, "Successfully loaded favorite tv")
            response
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching favorites: ${e.message}")
            null
        }
    }

    // Get TV shows with sort parameters
    suspend fun getTVShowBySort(sortBy: String, sortOrder: String): TVShowsResponse? = withContext(Dispatchers.IO) {
        try {
            val response = ApiClient.api.getTVShowBySort(sortBy, sortOrder)
            Log.d(TAG, "Successfully loaded TV shows with sort: $sortBy - $sortOrder")
            response
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching TV shows with sort: ${e.message}")
            null
        }
    }



}