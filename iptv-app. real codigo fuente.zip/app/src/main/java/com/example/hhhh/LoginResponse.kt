package com.example.hhhh

data class LoginResponse(
    val status: String,
    val token: String?,
    val message: String?
)