package com.example.hhhh

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class PhoneLauncherActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Redirect BlueStacks/phones to your TV LoginActivity
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}
