package com.example.hhhh

data  class MovieDetailResponse (
    val data: MovieDetail,
    val status : Boolean
)