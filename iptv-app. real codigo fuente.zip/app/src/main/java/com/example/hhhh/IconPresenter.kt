package com.example.hhhh

import android.graphics.drawable.Drawable
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.leanback.widget.ImageCardView
import androidx.leanback.widget.Presenter
import android.view.View


class IconPresenter : Presenter() {

    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val cardView = ImageCardView(parent.context).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setMainImageDimensions(120, 120)

            // Remove the gray info area
            (findViewById(androidx.leanback.R.id.info_field) as? View)?.apply {
                visibility = View.GONE
                layoutParams?.height = 0
            }

            // Make content fill the card
            mainImageView.scaleType = ImageView.ScaleType.FIT_XY
        }

        return ViewHolder(cardView)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val iconItem = item as IconItem
        val cardView = viewHolder.view as ImageCardView

        val drawable = ContextCompat.getDrawable(cardView.context, iconItem.iconRes)
        cardView.mainImage = drawable
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder) {
        (viewHolder.view as ImageCardView).mainImage = null
    }
}
