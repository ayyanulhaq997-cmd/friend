// MovieActivity.kt - FIXED VERSION
package com.example.hhhh

import android.os.Bundle
import androidx.fragment.app.FragmentActivity

class MovieActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        (application as MyApp).applyLanguage()
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.main_browse_fragment, MovieFragment())
                .commitNow()
        }
    }

    override fun onBackPressed() {
        // Cancel any pending operations before finishing
        super.onBackPressed()
        finish() // Explicitly finish to ensure clean exit
    }
}