package com.example.hhhh.api
import com.example.hhhh.BasicResponse
import com.example.hhhh.ChangePasswordRequest
import com.example.hhhh.EpisodePlayBackPositionResponse
import com.example.hhhh.FavoriteMovieResponse
import com.example.hhhh.FavoriteTVShowResponse
import com.example.hhhh.LoginResponse
import com.example.hhhh.MovieDetailResponse
import com.example.hhhh.SignedUrlResponse
import com.example.hhhh.TVShowsResponse
import com.example.hhhh.UserResponse
import com.example.hhhh.UserSettingDataResponse
import com.example.hhhh.models.ChannelsResponse
import com.example.hhhh.models.MovieCategoriesResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("login")
    suspend fun login(
        @Query("username") username: String,
        @Query("password") password: String
    ): LoginResponse

    @GET("user_home_data")
    suspend fun user(): UserResponse

    @GET("user_setting_data")
    suspend fun userSettingData(): UserSettingDataResponse

    @POST("change_password")
    suspend fun changePassword(
        @Body body: ChangePasswordRequest
    ): BasicResponse




    @GET("get_movie_by_sort")
    suspend fun getMovieCategories(): MovieCategoriesResponse

    @GET("get_movie_favorite")
    suspend fun getFavoriteMovies(): MovieCategoriesResponse

    @GET("get_movie_by_sort")
    suspend fun getMoviesBySort(
        @Query("sortBy") sortBy: String,
        @Query("sortOrder") sortOrder: String
    ): MovieCategoriesResponse

    @GET("add_movie_favorite")
    suspend fun addMovieFavorite(
        @Query("video") videoId: Long
    ): FavoriteMovieResponse


    @GET("get_signed_url")
    suspend fun getSignedUrl(
        @Query("video") videoId: Int,
        @Query("type") type: String
    ): SignedUrlResponse

    @GET("get_movie_detail")
    suspend fun getMovieDetail(
        @Query("video") videoId: Long,
    ): MovieDetailResponse

    @GET("get_tv_categories")
    suspend fun getTVShows(): TVShowsResponse

    @GET("get_tv_favorite")
    suspend fun getFavoriteTVShow(): TVShowsResponse

    @GET("get_tv_by_sort")
    suspend fun getTVShowBySort(
        @Query("sortBy") sortBy: String,
        @Query("sortOrder") sortOrder: String
    ): TVShowsResponse

    @GET("add_tv_favorite")
    suspend fun addTVShowFavorite(
        @Query("video") videoId: String?
    ): FavoriteTVShowResponse

    @GET("get_episode_last_position")
    suspend fun getEpisodeLastPosition(
        @Query("video") videoId: Int?
    ): EpisodePlayBackPositionResponse

    @POST("save_playback_position")
    suspend fun savePlayPosition(
        @Query("video") videoId: Int,
        @Query("type") type: String,
        @Query("position") position: Long
    ): Boolean


    @GET("get_all_channels")
    suspend fun getChannels(): ChannelsResponse

    @GET("channels/{category}")
    suspend fun getChannelsByCategory(@Path("category") category: String): ChannelsResponse


}
