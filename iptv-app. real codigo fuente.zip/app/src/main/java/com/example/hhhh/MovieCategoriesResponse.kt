// MovieCategoriesResponse.kt
package com.example.hhhh.models

data class MovieCategoriesResponse(
    val status: Boolean,
    val data: List<MovieCategory>,
    val message: String?
)
