package com.example.hhhh

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.SubtitleView
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import com.bumptech.glide.Glide
import com.example.hhhh.api.ApiClient
import kotlinx.coroutines.launch

@UnstableApi
class PlaybackVideoFragment : Fragment() {

    private var exoPlayer: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var customControls: CustomPlayerControls? = null
    private var trackSelector: DefaultTrackSelector? = null

    private var subtitleEnabled = true
    private var subtitleColor = Color.WHITE
    private var subtitleSize = 0.06f
    private var selectedSubtitleLanguage = "en"
    private var selectedAudioLanguage = "en"

    private var title: String? = null
    private var videoId: Int = 0
    private var type: String = "movie"
    private var savedPosition: Long = 0L
    private var showPlaybackDialog = true

    private data class AudioTrack(val language: String?, val label: String?, val trackIndex: Int, val groupIndex: Int)
    private data class SubtitleTrack(val language: String?, val label: String?, val trackIndex: Int, val groupIndex: Int)

    private val availableAudioTracks = mutableListOf<AudioTrack>()
    private val availableSubtitleTracks = mutableListOf<SubtitleTrack>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val movie = activity?.intent?.getSerializableExtra(DetailsActivity.MOVIE) as? Movie
        val episode = activity?.intent?.getSerializableExtra(PlaybackActivity.EPISODE) as? Episode

        if (movie != null) {
            videoId = movie.videos_id.toInt()
            type = "movie"
            title = movie.title
        } else if (episode != null) {
            videoId = episode.id?:0
            type = "episode"
            title = episode.title
        } else {
            Toast.makeText(activity, "No video data", Toast.LENGTH_LONG).show()
            activity?.finish()
            return
        }

        val audioIndex = activity?.intent?.getIntExtra("audioIndex", 0) ?: 0
        val subtitleIndex = activity?.intent?.getIntExtra("subtitleIndex", 1) ?: 1
        subtitleColor = activity?.intent?.getIntExtra("subtitleColor", Color.WHITE) ?: Color.WHITE
        subtitleSize = activity?.intent?.getFloatExtra("subtitleSize", 0.06f) ?: 0.06f
        savedPosition = activity?.intent?.getLongExtra("savedPosition", 0L) ?: 0L

        selectedAudioLanguage = getAudioLabel(audioIndex)
        selectedSubtitleLanguage = getSubtitleLabel(subtitleIndex)
    }

    private fun getAudioLabel(index: Int) = when (index) {
        0 -> "en"
        1 -> "es"
        2 -> "mute"
        else -> "en"
    }

    private fun getSubtitleLabel(index: Int) = when (index) {
        0 -> "disabled"
        1 -> "en"
        2 -> "es"
        else -> "en"
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return FrameLayout(requireContext()).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.BLACK)

            playerView = PlayerView(requireContext()).apply {
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
                useController = false
                controllerHideOnTouch = false
            }
            addView(playerView)

            customControls = CustomPlayerControls(requireContext()).apply {
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
                setPlayerFragment(this@PlaybackVideoFragment)
            }
            addView(customControls)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initializePlayer()
    }

    override fun onStart() {
        super.onStart()
        Log.d("PlaybackVideo", "onStart called, savedPosition: $savedPosition")
        lifecycleScope.launch {
            try {
                val response = ApiClient.api.getSignedUrl(videoId, type)
                val signedUrl = response.signedUrl
                Log.d("PlaybackVideo", "Signed URL: $signedUrl")
                setupPlayer(signedUrl)
            } catch (e: Exception) {
                Log.e("PlaybackVideo", "Failed to get signed URL", e)
                Toast.makeText(requireContext(), "Failed to load video", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun initializePlayer() {
        if (exoPlayer != null) return

        trackSelector = DefaultTrackSelector(requireContext()).apply {
            parameters = buildUponParameters()
                .setSelectUndeterminedTextLanguage(true)
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .setPreferredTextRoleFlags(C.ROLE_FLAG_SUBTITLE or C.ROLE_FLAG_CAPTION)
                .build()
        }

        exoPlayer = ExoPlayer.Builder(requireContext())
            .setTrackSelector(trackSelector!!)
            .build()

        playerView?.player = exoPlayer
        playerView?.subtitleView?.visibility = View.GONE
    }

    private fun setupPlayer(videoUrl: String) {
        if (videoUrl.isEmpty()) {
            Toast.makeText(requireContext(), "Invalid video URL", Toast.LENGTH_LONG).show()
            return
        }

        val mediaItem = MediaItem.fromUri(Uri.parse(videoUrl))
        exoPlayer?.apply {
            setMediaItem(mediaItem)
            prepare()

            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == Player.STATE_READY) {
                        detectAvailableTracks()
                        applyAudioTrack()
                        enableSubtitleTrack()
                        customControls?.updateDuration(duration)

                        if (showPlaybackDialog && savedPosition > 0) {
                            Log.d("PlaybackVideo", "Showing playback dialog, savedPosition: $savedPosition")
                            showPlaybackOptionsDialog()
                            showPlaybackDialog = false
                        } else {
                            playWhenReady = true
                        }
                    }
                    val isReady = state == Player.STATE_READY
                    customControls?.updateLoadingState(!isReady && isLoading)
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    customControls?.updatePlayPauseButton(isPlaying)
                }

                override fun onCues(cueGroup: CueGroup) {
                    customControls?.updateSubtitles(
                        if (subtitleEnabled) cueGroup.cues else emptyList(),
                        subtitleColor,
                        subtitleSize
                    )
                }

                override fun onTracksChanged(tracks: Tracks) {
                    detectAvailableTracks()
                    enableSubtitleTrack()
                }
            })
        }

        customControls?.startProgressUpdates()
    }

    private fun showPlaybackOptionsDialog() {
        try {
            val context = requireContext()

            // Create the dialog view programmatically
            val dialogContainer = LinearLayout(context).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                orientation = LinearLayout.VERTICAL
                setPadding(40, 30, 40, 30)
            }

            // Radio Group
            val radioGroup = RadioGroup(context).apply {
                layoutParams = RadioGroup.LayoutParams(
                    RadioGroup.LayoutParams.MATCH_PARENT,
                    RadioGroup.LayoutParams.WRAP_CONTENT
                )
                orientation = RadioGroup.VERTICAL
            }

            // Resume Radio Button
            val resumeButton = RadioButton(context).apply {
                id = R.id.resumeRadio
                text = "Resume"
                textSize = 16f
                setTextColor(Color.WHITE)
                isChecked = true
                setPadding(0, 16, 0, 16)
            }
            radioGroup.addView(resumeButton)

            // Start Again Radio Button
            val startAgainButton = RadioButton(context).apply {
                id = R.id.startAgainRadio
                text = "Start again"
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(0, 16, 0, 16)
            }
            radioGroup.addView(startAgainButton)

            dialogContainer.addView(radioGroup)

            // Checkbox
            val checkBox = android.widget.CheckBox(context).apply {
                text = "Do not ask again."
                textSize = 14f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = 24
                }
                setPadding(0, 16, 0, 16)
            }
            dialogContainer.addView(checkBox)

            AlertDialog.Builder(context)
                .setTitle("Playback Option")
                .setView(dialogContainer)
                .setPositiveButton("OK") { dialog, _ ->
                    val selectedId = radioGroup.checkedRadioButtonId
                    when (selectedId) {
                        R.id.resumeRadio -> {
                            Log.d("PlaybackVideo", "Resume selected, seeking to $savedPosition")
                            exoPlayer?.seekTo(savedPosition)
                            exoPlayer?.playWhenReady = true
                        }
                        R.id.startAgainRadio -> {
                            Log.d("PlaybackVideo", "Start again selected")
                            exoPlayer?.seekTo(0)
                            exoPlayer?.playWhenReady = true
                        }
                        else -> {
                            exoPlayer?.seekTo(savedPosition)
                            exoPlayer?.playWhenReady = true
                        }
                    }

                    if (checkBox.isChecked) {
                        saveDoNotAskAgainPreference()
                    }

                    dialog.dismiss()
                }
                .setNegativeButton("CANCEL") { dialog, _ ->
                    dialog.dismiss()
                    exoPlayer?.playWhenReady = true
                }
                .setCancelable(false)
                .show()

            Log.d("PlaybackVideo", "Playback dialog shown")
        } catch (e: Exception) {
            Log.e("PlaybackVideo", "Error showing playback dialog: ${e.message}", e)
            exoPlayer?.playWhenReady = true
        }
    }

    fun showExitConfirmationDialog() {
        try {
            AlertDialog.Builder(requireContext())
                .setTitle("Warning")
                .setMessage("Are you sure you want to leave?")
                .setPositiveButton("YES") { _, _ ->
                    savePlayerPosition()
                    activity?.finish()
                }
                .setNegativeButton("NO", null)
                .setCancelable(false)
                .show()

            Log.d("PlaybackVideo", "Exit confirmation dialog shown")
        } catch (e: Exception) {
            Log.e("PlaybackVideo", "Error showing exit dialog: ${e.message}", e)
        }
    }

    private fun savePlayerPosition() {
        val position = exoPlayer?.currentPosition ?: 0L
        val prefs = requireContext().getSharedPreferences("video_prefs", Context.MODE_PRIVATE)
        prefs.edit().putLong("${type}_${videoId}_position", position).apply()
        Log.d("PlaybackVideo", "Saved position: $position for ${type}_${videoId}")
        lifecycleScope.launch {
            try {
                val response = ApiClient.api.savePlayPosition(videoId, type,position)
                Log.d("PlaybackVideo", "Saved  on DB: $position for ${type}_${videoId}")

            } catch (e: Exception) {
                Log.e("PlaybackVideo", "Saved Failed", e)

            }
        }
    }

    private fun saveDoNotAskAgainPreference() {
        val prefs = requireContext().getSharedPreferences("video_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("${type}_${videoId}_dont_ask", true).apply()
        Log.d("PlaybackVideo", "Saved don't ask again preference")
    }

    private fun detectAvailableTracks() {
        val player = exoPlayer ?: return
        availableAudioTracks.clear()
        availableSubtitleTracks.clear()

        val tracks = player.currentTracks

        tracks.groups.forEachIndexed { groupIndex, group ->
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    availableAudioTracks.add(
                        AudioTrack(
                            language = format.language,
                            label = format.label ?: getLanguageDisplayName(format.language),
                            trackIndex = i,
                            groupIndex = groupIndex
                        )
                    )
                }
            }
        }

        tracks.groups.forEachIndexed { groupIndex, group ->
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    availableSubtitleTracks.add(
                        SubtitleTrack(
                            language = format.language,
                            label = format.label ?: getLanguageDisplayName(format.language),
                            trackIndex = i,
                            groupIndex = groupIndex
                        )
                    )
                }
            }
        }
    }

    private fun getLanguageDisplayName(languageCode: String?): String {
        return when (languageCode) {
            "en", "eng" -> "English"
            "es", "spa" -> "Spanish"
            else -> languageCode ?: "Unknown"
        }
    }

    fun showAudioTrackDialog() {
        if (availableAudioTracks.isEmpty()) {
            Toast.makeText(requireContext(), "No audio tracks available", Toast.LENGTH_SHORT).show()
            return
        }

        val trackNames = mutableListOf<String>()
        trackNames.add("Mute")
        trackNames.addAll(availableAudioTracks.map { "${it.label}" })

        val currentSelection = if (selectedAudioLanguage == "mute") {
            0
        } else {
            availableAudioTracks.indexOfFirst { it.language == selectedAudioLanguage } + 1
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Select Audio Track")
            .setSingleChoiceItems(trackNames.toTypedArray(), currentSelection) { dialog, which ->
                if (which == 0) {
                    selectedAudioLanguage = "mute"
                    exoPlayer?.volume = 0f
                } else {
                    val selectedTrack = availableAudioTracks[which - 1]
                    selectedAudioLanguage = selectedTrack.language ?: "en"
                    applyAudioTrackByIndex(selectedTrack)
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun showSubtitleTrackDialog() {
        val trackNames = mutableListOf<String>()
        trackNames.add("Disabled")
        trackNames.addAll(availableSubtitleTracks.map { "${it.label}" })

        val currentSelection = if (!subtitleEnabled || selectedSubtitleLanguage == "disabled") {
            0
        } else {
            availableSubtitleTracks.indexOfFirst { it.language == selectedSubtitleLanguage } + 1
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Select Subtitle Track")
            .setSingleChoiceItems(trackNames.toTypedArray(), currentSelection) { dialog, which ->
                if (which == 0) {
                    subtitleEnabled = false
                    selectedSubtitleLanguage = "disabled"
                } else {
                    val selectedTrack = availableSubtitleTracks[which - 1]
                    subtitleEnabled = true
                    selectedSubtitleLanguage = selectedTrack.language ?: "en"
                }
                enableSubtitleTrack()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun showSubtitleStyleDialog() {
        val colors = arrayOf("White", "Yellow", "Green", "Cyan", "Red", "Blue", "Magenta", "Black")
        val colorValues = arrayOf(
            Color.WHITE, Color.YELLOW, Color.GREEN, Color.CYAN,
            Color.RED, Color.BLUE, Color.MAGENTA, Color.BLACK
        )

        val sizes = arrayOf("Small", "Normal", "Large", "Extra Large")
        val sizeValues = arrayOf(0.04f, 0.06f, 0.08f, 0.10f)

        val currentColorIndex = colorValues.indexOf(subtitleColor).takeIf { it >= 0 } ?: 0
        val currentSizeIndex = sizeValues.indexOf(subtitleSize).takeIf { it >= 0 } ?: 1

        var selectedColor = subtitleColor
        var selectedSize = subtitleSize

        AlertDialog.Builder(requireContext())
            .setTitle("Subtitle Color")
            .setSingleChoiceItems(colors, currentColorIndex) { dialog, which ->
                selectedColor = colorValues[which]
                dialog.dismiss()

                AlertDialog.Builder(requireContext())
                    .setTitle("Subtitle Size")
                    .setSingleChoiceItems(sizes, currentSizeIndex) { sizeDialog, sizeWhich ->
                        selectedSize = sizeValues[sizeWhich]
                        subtitleColor = selectedColor
                        subtitleSize = selectedSize
                        applySubtitleStyle()
                        Toast.makeText(requireContext(), "Subtitle style updated", Toast.LENGTH_SHORT).show()
                        sizeDialog.dismiss()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun applyAudioTrackByIndex(audioTrack: AudioTrack) {
        val player = exoPlayer ?: return
        val selector = trackSelector ?: return

        val tracks = player.currentTracks
        val group = tracks.groups.getOrNull(audioTrack.groupIndex) ?: return

        val override = TrackSelectionOverride(group.mediaTrackGroup, audioTrack.trackIndex)
        selector.parameters = selector.parameters
            .buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
            .addOverride(override)
            .build()
        player.volume = 1f

        Toast.makeText(requireContext(), "Audio: ${audioTrack.label}", Toast.LENGTH_SHORT).show()
    }

    private fun applyAudioTrack() {
        val player = exoPlayer ?: return
        val selector = trackSelector ?: return

        if (selectedAudioLanguage == "mute") {
            player.volume = 0f
            return
        }

        val audioGroups = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }

        for (group in audioGroups) {
            for (i in 0 until group.length) {
                val format = group.getTrackFormat(i)
                if (format.language == selectedAudioLanguage) {
                    val override = TrackSelectionOverride(group.mediaTrackGroup, i)
                    selector.parameters = selector.parameters
                        .buildUpon()
                        .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                        .addOverride(override)
                        .build()
                    player.volume = 1f
                    return
                }
            }
        }

        if (audioGroups.isNotEmpty() && audioGroups[0].length > 0) {
            val group = audioGroups[0]
            val override = TrackSelectionOverride(group.mediaTrackGroup, 0)
            selector.parameters = selector.parameters
                .buildUpon()
                .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                .addOverride(override)
                .build()
            player.volume = 1f
        }
    }

    private fun enableSubtitleTrack() {
        val player = exoPlayer ?: return
        val selector = trackSelector ?: return

        val textGroups = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
        if (textGroups.isEmpty()) return

        val targetLang = if (subtitleEnabled && selectedSubtitleLanguage != "disabled") selectedSubtitleLanguage else null

        val newParams = selector.parameters.buildUpon().apply {
            setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            clearOverridesOfType(C.TRACK_TYPE_TEXT)
            if (targetLang != null) {
                var found = false
                for (group in textGroups) {
                    for (i in 0 until group.length) {
                        val format = group.getTrackFormat(i)
                        if (format.language == targetLang) {
                            addOverride(TrackSelectionOverride(group.mediaTrackGroup, i))
                            found = true
                            break
                        }
                    }
                    if (found) break
                }
            } else {
                setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            }
        }.build()

        selector.parameters = newParams
    }

    private fun applySubtitleStyle() {
        customControls?.applySubtitleStyle(subtitleColor, subtitleSize)
    }

    fun getPlayer() = exoPlayer

    override fun onPause() {
        super.onPause()
        exoPlayer?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        savePlayerPosition()
        exoPlayer?.release()
        exoPlayer = null
    }
}

@UnstableApi
class CustomPlayerControls(context: Context, attrs: AttributeSet? = null) : FrameLayout(context, attrs) {

    private var playerFragment: PlaybackVideoFragment? = null
    private val handler = Handler(Looper.getMainLooper())
    private var hideControlsRunnable: Runnable? = null
    private var progressUpdateRunnable: Runnable? = null

    // UI Components
    private lateinit var subtitleView: SubtitleView
    private lateinit var controlPanel: LinearLayout
    private lateinit var timelinePanel: LinearLayout
    private lateinit var buttonPanel: LinearLayout
    private lateinit var loadingSpinner: ProgressBar

    // Buttons
    private lateinit var playButton: android.widget.Button
    private lateinit var backButton: android.widget.Button
    private lateinit var forwardButton: android.widget.Button
    private lateinit var audioButton: android.widget.Button
    private lateinit var subtitleButton: android.widget.Button
    private lateinit var styleButton: android.widget.Button
    private lateinit var exitButton: android.widget.Button

    // Timeline
    private lateinit var seekBar: SeekBar
    private lateinit var timeTextView: TextView
    private lateinit var durationTextView: TextView
    private lateinit var thinProgressBar: ProgressBar

    private var duration = 0L
    private var isPlaying = false
    private var focusedButtonIndex = 0
    private val buttons = mutableListOf<android.widget.Button>()

    init {
        setBackgroundColor(Color.TRANSPARENT)
        isFocusable = true
        setupUI()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_BACK -> {
                playerFragment?.showExitConfirmationDialog()
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                showControls()
                resetHideTimer()

                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        focusedButtonIndex = (focusedButtonIndex - 1).coerceAtLeast(0)
                        updateButtonFocus()
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        focusedButtonIndex = (focusedButtonIndex + 1).coerceAtMost(buttons.size - 1)
                        updateButtonFocus()
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        buttons[focusedButtonIndex].performClick()
                    }
                }
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun updateButtonFocus() {
        buttons.forEachIndexed { index, button ->
            if (index == focusedButtonIndex) {
                button.setBackgroundColor(Color.argb(255, 0, 120, 215))
            } else {
                button.setBackgroundColor(Color.TRANSPARENT)
            }
        }
    }

    private fun setupUI() {
        // Subtitle view
        subtitleView = SubtitleView(context).apply {
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
            setStyle(
                CaptionStyleCompat(
                    Color.WHITE,
                    Color.TRANSPARENT,
                    Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_NONE,
                    Color.TRANSPARENT,
                    null
                )
            )
            setFractionalTextSize(0.06f)
            setBottomPaddingFraction(0.15f)
            setApplyEmbeddedStyles(false)
            setApplyEmbeddedFontSizes(false)
        }
        addView(subtitleView)

        // Loading spinner
        loadingSpinner = ProgressBar(context).apply {
            layoutParams = LayoutParams(120, 120, Gravity.CENTER)
            visibility = View.GONE
        }
        addView(loadingSpinner, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        // Main control panel container - positioned at bottom
        controlPanel = LinearLayout(context).apply {
            layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        // Top thin progress bar
        thinProgressBar = ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            layoutParams = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 4)
            progressDrawable.setColorFilter(Color.parseColor("#FF9800"), android.graphics.PorterDuff.Mode.SRC_IN)
        }
        controlPanel.addView(thinProgressBar)

        // Timeline Panel
        timelinePanel = LinearLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 120)
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.argb(230, 30, 30, 30))
            setPadding(20, 12, 20, 15)
        }

        // Seek bar with custom styling
        seekBar = SeekBar(context).apply {
            layoutParams = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            progressDrawable.setColorFilter(Color.parseColor("#FF9800"), android.graphics.PorterDuff.Mode.SRC_IN)
            thumb.setColorFilter(Color.parseColor("#FF9800"), android.graphics.PorterDuff.Mode.SRC_IN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        playerFragment?.getPlayer()?.seekTo(progress.toLong())
                    }
                    timeTextView.text = formatTime(progress.toLong())
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        timelinePanel.addView(seekBar)

        // Time display
        val timeContainer = LinearLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 8, 0, 0)
        }

        timeTextView = TextView(context).apply {
            layoutParams = LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
            text = "00:00"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(5, 0, 5, 0)
        }
        timeContainer.addView(timeTextView)

        val spacer = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)
        }
        timeContainer.addView(spacer)

        durationTextView = TextView(context).apply {
            layoutParams = LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
            text = "00:00"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(5, 0, 5, 0)
        }
        timeContainer.addView(durationTextView)

        timelinePanel.addView(timeContainer)
        controlPanel.addView(timelinePanel)

        // Button Panel with thumbnail
        val buttonPanelWrapper = LinearLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 100)
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.argb(230, 30, 30, 30))
            setPadding(20, 15, 20, 15)
        }

        // Thumbnail image
        val thumbnail = android.widget.ImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(77, 100).apply {
                setMargins(0, 0, 0, 0)
            }
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            setBackgroundColor(Color.argb(150, 100, 100, 100))
        }
        buttonPanelWrapper.addView(thumbnail)

        Glide.with(context)
            .load("https://image.tmdb.org/t/p/w300//c70L9jY4yWXT8JaaPgwWB7wlgHX.jpg")
            .into(thumbnail)

        buttonPanel = LinearLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, 1f)
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val buttonSize = 70
        val buttonParams = LinearLayout.LayoutParams(buttonSize, buttonSize).apply {
            setMargins(20, 0, 20, 0)
        }

        // Exit button
        exitButton = createButton("⬅", buttonParams) {
            playerFragment?.showExitConfirmationDialog()
        }
        buttons.add(exitButton)
        buttonPanel.addView(exitButton)

        // Audio button
        audioButton = createButton("🔊", buttonParams) {
            playerFragment?.showAudioTrackDialog()
        }
        buttons.add(audioButton)
        buttonPanel.addView(audioButton)

        // Back button
        backButton = createButton("⏮", buttonParams) {
            playerFragment?.getPlayer()?.apply {
                seekTo((currentPosition - 10000).coerceAtLeast(0))
            }
        }
        buttons.add(backButton)
        buttonPanel.addView(backButton)

        // Play/Pause button
        playButton = createButton("▶", buttonParams) {
            val player = playerFragment?.getPlayer()
            if (player?.isPlaying == true) {
                player.pause()
                isPlaying = false
            } else {
                player?.play()
                isPlaying = true
            }
        }
        buttons.add(playButton)
        buttonPanel.addView(playButton)

        // Forward button
        forwardButton = createButton("⏭", buttonParams) {
            playerFragment?.getPlayer()?.apply {
                seekTo((currentPosition + 10000).coerceAtMost(duration))
            }
        }
        buttons.add(forwardButton)
        buttonPanel.addView(forwardButton)

        // Subtitle button
        subtitleButton = createButton("CC", buttonParams) {
            playerFragment?.showSubtitleTrackDialog()
        }
        buttons.add(subtitleButton)
        buttonPanel.addView(subtitleButton)

        // Style button
        styleButton = createButton("A", buttonParams) {
            playerFragment?.showSubtitleStyleDialog()
        }
        buttons.add(styleButton)
        buttonPanel.addView(styleButton)

        buttonPanelWrapper.addView(buttonPanel)
        controlPanel.addView(buttonPanelWrapper)

        addView(controlPanel)

        focusedButtonIndex = 3 // Focus on play button
        updateButtonFocus()
    }

    private fun createButton(text: String, params: LinearLayout.LayoutParams, onClick: () -> Unit): android.widget.Button {
        return android.widget.Button(context).apply {
            layoutParams = params
            this.text = text
            setTextColor(Color.WHITE)
            textSize = 20f
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { onClick() }
        }
    }

    private fun showControls() {
        controlPanel.visibility = View.VISIBLE
        controlPanel.alpha = 1f
        resetHideTimer()
    }

    private fun hideControls() {
        controlPanel.animate().alpha(0f).duration = 300
        handler.postDelayed({ controlPanel.visibility = View.GONE }, 300)
    }

    private fun resetHideTimer() {
        hideControlsRunnable?.let { handler.removeCallbacks(it) }
        hideControlsRunnable = Runnable { hideControls() }
        handler.postDelayed(hideControlsRunnable!!, 5000)
    }

    fun updateDuration(dur: Long) {
        duration = dur
        seekBar.max = dur.toInt()
        thinProgressBar.max = dur.toInt()
        durationTextView.text = formatTime(dur)
    }

    fun updateProgress(position: Long) {
        seekBar.progress = position.toInt()
        thinProgressBar.progress = position.toInt()
        timeTextView.text = formatTime(position)
    }

    fun updatePlayPauseButton(playing: Boolean) {
        isPlaying = playing
        playButton.text = if (playing) "⏸" else "▶"
    }

    fun updateLoadingState(loading: Boolean) {
        loadingSpinner.visibility = if (loading) View.VISIBLE else View.GONE
    }

    fun updateSubtitles(cues: List<androidx.media3.common.text.Cue>, color: Int, size: Float) {
        subtitleView.setCues(cues)
        applySubtitleStyle(color, size)
    }

    fun applySubtitleStyle(color: Int, size: Float) {
        subtitleView.setStyle(
            CaptionStyleCompat(
                color,
                Color.TRANSPARENT,
                Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_NONE,
                Color.TRANSPARENT,
                null
            )
        )
        subtitleView.setFractionalTextSize(size)
    }

    fun setPlayerFragment(fragment: PlaybackVideoFragment) {
        playerFragment = fragment
    }

    fun startProgressUpdates() {
        progressUpdateRunnable = object : Runnable {
            override fun run() {
                playerFragment?.getPlayer()?.let { player ->
                    updateProgress(player.currentPosition)
                }
                handler.postDelayed(this, 100)
            }
        }
        handler.post(progressUpdateRunnable!!)
    }

    fun stopProgressUpdates() {
        progressUpdateRunnable?.let { handler.removeCallbacks(it) }
    }

    private fun formatTime(ms: Long): String {
        val seconds = (ms / 1000) % 60
        val minutes = (ms / 1000 / 60) % 60
        val hours = (ms / 1000 / 60 / 60)
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopProgressUpdates()
        hideControlsRunnable?.let { handler.removeCallbacks(it) }
    }
}