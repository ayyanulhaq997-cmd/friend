package com.example.hhhh

import com.example.hhhh.TVShowCategory

data class TVShowCategoriesResponse (
    val status: Boolean,
    val data: List<TVShowCategory>,
    val message: String?
)