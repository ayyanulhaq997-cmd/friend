package com.example.hhhh

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.hhhh.adapters.ChannelAdapter
import com.example.hhhh.api.ApiClient
import com.example.hhhh.models.Channel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LiveChannelsActivity : FragmentActivity() {

    private lateinit var channelRecyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var playerView: PlayerView
    private lateinit var channelTitle: TextView
    private lateinit var channelLogo: ImageView
    private lateinit var fullscreenButton: ImageButton
    private lateinit var sidebarContainer: View
    private lateinit var playerContainer: View

    private var player: ExoPlayer? = null
    private var channelsJob: Job? = null
    private val channels = mutableListOf<Channel>()
    private var currentChannel: Channel? = null
    private var isFullscreen = false

    companion object {
        private const val TAG = "LiveChannelsActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate started")

        try {
            setContentView(R.layout.activity_live_channels_split)
            Log.d(TAG, "setContentView successful")

            // Initialize views
            channelRecyclerView = findViewById(R.id.channelRecyclerView)
            progressBar = findViewById(R.id.progressBar)
            playerView = findViewById(R.id.playerView)
            channelTitle = findViewById(R.id.channelTitle)
            channelLogo = findViewById(R.id.channelLogo)
            fullscreenButton = findViewById(R.id.fullscreenButton)
            sidebarContainer = findViewById(R.id.sidebarContainer)
            playerContainer = findViewById(R.id.playerContainer)

            // Setup RecyclerView with vertical layout
            channelRecyclerView.layoutManager = LinearLayoutManager(this)

            // Fullscreen button
            fullscreenButton.setOnClickListener {
                toggleFullscreen()
            }

            // Initialize player
            initializePlayer()

            // Load channels (use dummy data for testing)
            //loadDummyChannels()

            // Uncomment to use real API
             loadChannelsFromAPI()

        } catch (e: Exception) {
            Log.e(TAG, "Error in onCreate: ${e.message}", e)
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun initializePlayer() {
        try {
            player = ExoPlayer.Builder(this).build()
            playerView.player = player

            player?.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_BUFFERING -> progressBar.visibility = View.VISIBLE
                        Player.STATE_READY -> progressBar.visibility = View.GONE
                        Player.STATE_ENDED -> progressBar.visibility = View.GONE
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    Log.e(TAG, "Playback error: ${error.message}", error)
                    Toast.makeText(
                        this@LiveChannelsActivity,
                        "Error playing channel",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })

            Log.d(TAG, "Player initialized")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing player: ${e.message}", e)
        }
    }

    private fun loadDummyChannels() {
        Log.d(TAG, "Loading dummy channels...")
        progressBar.visibility = View.VISIBLE

        CoroutineScope(Dispatchers.Main).launch {
            delay(1000)

            try {
                val dummyChannels = listOf(
                    Channel(
                        live_tv_id = 1,
                        tv_name = "Pay-Per-View ( PPV ) Event 1 HD",
                        thumbnail = "https://via.placeholder.com/80/FF0000/FFFFFF?text=PPV1",
                        url = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                        categories = "PPV",
                        publication = true
                    ),
                    Channel(
                        live_tv_id = 2,
                        tv_name = "Pay-Per-View ( PPV ) Event 2 HD°",
                        thumbnail = "https://via.placeholder.com/80/00FF00/FFFFFF?text=PPV2",
                        url = "https://test-streams.mux.dev/x36xhzz/url_0/193039199_mp4_h264_aac_hd_7.m3u8",
                        categories = "PPV",
                        publication = true
                    ),
                    Channel(
                        live_tv_id = 3,
                        tv_name = "Pay-Per-View ( PPV ) Event 3 HD°",
                        thumbnail = "https://via.placeholder.com/80/0000FF/FFFFFF?text=PPV3",
                        url = "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8",
                        categories = "PPV",
                        publication = true
                    ),
                    Channel(
                        live_tv_id = 4,
                        tv_name = "DO | Color Visión HD°",
                        thumbnail = "https://via.placeholder.com/80/FFFF00/000000?text=CV",
                        url = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                        categories = "DO",
                        publication = true
                    ),
                    Channel(
                        live_tv_id = 5,
                        tv_name = "DO | Telesistema HD°",
                        thumbnail = "https://via.placeholder.com/80/FF00FF/FFFFFF?text=TS",
                        url = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
                        categories = "DO",
                        publication = true
                    )
                )

                channels.clear()
                channels.addAll(dummyChannels)

                progressBar.visibility = View.GONE
                Log.d(TAG, "Dummy channels loaded: ${channels.size}")

                channelRecyclerView.adapter = ChannelAdapter(channels) { channel ->
                    playChannel(channel)
                }

                // Auto-play first channel
                if (channels.isNotEmpty()) {
                    playChannel(channels[0])
                    channelRecyclerView.post {
                        channelRecyclerView.getChildAt(0)?.requestFocus()
                    }
                }

            } catch (e: Exception) {
                Log.e(TAG, "Error loading dummy data: ${e.message}", e)
                progressBar.visibility = View.GONE
            }
        }
    }

    private fun loadChannelsFromAPI() {
        Log.d(TAG, "Loading channels from API...")
        progressBar.visibility = View.VISIBLE

        channelsJob = CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = ApiClient.api.getChannels()
                Log.d(TAG, "API Response: status=${response.status}")

                if (!isDestroyed && !isFinishing) {
                    withContext(Dispatchers.Main) {
                        progressBar.visibility = View.GONE

                        if (response.status == true && !response.data.isNullOrEmpty()) {
                            channels.clear()
                            channels.addAll(response.data)

                            channelRecyclerView.adapter = ChannelAdapter(channels) { channel ->
                                playChannel(channel)
                            }

                            // Auto-play first channel
                            if (channels.isNotEmpty()) {
                                playChannel(channels[0])
                            }
                        } else {
                            Toast.makeText(
                                this@LiveChannelsActivity,
                                response.message ?: "No channels available",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "API Error: ${e.message}", e)
                if (!isDestroyed && !isFinishing) {
                    withContext(Dispatchers.Main) {
                        progressBar.visibility = View.GONE
                        Toast.makeText(
                            this@LiveChannelsActivity,
                            "Network error: ${e.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
    }

    private fun playChannel(channel: Channel) {
        try {
            Log.d(TAG, "Playing channel: ${channel.tv_name}")

            if (channel.url.isNullOrEmpty()) {
                Toast.makeText(this, "Invalid channel URL", Toast.LENGTH_SHORT).show()
                return
            }

            currentChannel = channel

            // Update UI
            channelTitle.text = channel.tv_name ?: "Live Channel"

            if (!channel.thumbnail.isNullOrEmpty()) {
                Glide.with(this)
                    .load(channel.thumbnail)
                    .into(channelLogo)
            }

            // Play stream
            val mediaItem = MediaItem.Builder()
                .setUri(Uri.parse(channel.url))
                .build()

            player?.setMediaItem(mediaItem)
            player?.prepare()
            player?.playWhenReady = true

        } catch (e: Exception) {
            Log.e(TAG, "Error playing channel: ${e.message}", e)
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleFullscreen() {
        isFullscreen = !isFullscreen

        if (isFullscreen) {
            // Hide sidebar, show only player
            sidebarContainer.visibility = View.GONE
            playerContainer.layoutParams.width = android.view.ViewGroup.LayoutParams.MATCH_PARENT
            fullscreenButton.setImageResource(android.R.drawable.ic_menu_revert)
        } else {
            // Show sidebar
            sidebarContainer.visibility = View.VISIBLE
            playerContainer.layoutParams = (playerContainer.layoutParams as android.widget.LinearLayout.LayoutParams).apply {
                weight = 1f
                width = 0
            }
            fullscreenButton.setImageResource(android.R.drawable.ic_menu_zoom)
        }

        playerContainer.requestLayout()
    }

    override fun onResume() {
        super.onResume()
        player?.playWhenReady = true
    }

    override fun onPause() {
        super.onPause()
        player?.playWhenReady = false
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy called")
        channelsJob?.cancel()
        player?.release()
        player = null
    }

    override fun onBackPressed() {
        if (isFullscreen) {
            toggleFullscreen()
        } else {
            channelsJob?.cancel()
            player?.release()
            player = null
            super.onBackPressed()
        }
    }
}