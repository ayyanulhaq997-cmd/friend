package com.example.hhhh

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class FavoriteTVShowAdapter(
    private val shows: List<TVShow>,
    private val onItemClick: (TVShow) -> Unit,
    private val onItemFocused: (TVShow) -> Unit
) : RecyclerView.Adapter<FavoriteTVShowAdapter.FavoriteTVShowViewHolder>() {

    inner class FavoriteTVShowViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val poster: ImageView = view.findViewById(R.id.ivTVShowPoster)
        val title: TextView = view.findViewById(R.id.tvTVShowTitle)
        val info: TextView = view.findViewById(R.id.tvTVShowInfo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteTVShowViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_favorite_tv, parent, false)

        return FavoriteTVShowViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavoriteTVShowViewHolder, position: Int) {
        val tvShow = shows[position]

        Glide.with(holder.itemView.context)
            .load(tvShow.bg_url)
            .into(holder.poster)

        holder.title.text = tvShow.title

        val year = tvShow.released_year?.take(4) ?: "---"
        val rating = tvShow.rate?.toString() ?: "--"

        holder.info.text = "$year • ⭐ $rating"

        holder.itemView.setOnClickListener {
            onItemClick(tvShow)
        }

        holder.itemView.setOnFocusChangeListener { view, hasFocus ->
            if (hasFocus) {
                view.animate().scaleX(1.1f).scaleY(1.1f).setDuration(150).start()
                view.setBackgroundResource(R.drawable.item_focused_bg)
                onItemFocused(tvShow)
            } else {
                view.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
                view.setBackgroundResource(R.drawable.item_unfocused_bg)
            }
        }
    }


    override fun getItemCount(): Int = shows.size
}
