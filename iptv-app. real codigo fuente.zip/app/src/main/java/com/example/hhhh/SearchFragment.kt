package com.example.hhhh

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.app.ActivityOptionsCompat
import androidx.leanback.app.SearchSupportFragment
import androidx.leanback.widget.*
import android.util.Log

class SearchFragment : SearchSupportFragment(), SearchSupportFragment.SearchResultProvider {

    private val rowsAdapter = ArrayObjectAdapter(ListRowPresenter())
    private val handler = Handler(Looper.getMainLooper())
    private var searchRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setSearchResultProvider(this)
        setOnItemViewClickedListener(ItemViewClickedListener())
    }

    override fun getResultsAdapter(): ObjectAdapter {
        return rowsAdapter
    }

    override fun onQueryTextChange(newQuery: String): Boolean {
        Log.d("SearchFragment", "Query changed to: $newQuery")

        // Cancel previous search
        searchRunnable?.let { handler.removeCallbacks(it) }

        // Debounce search by 500ms
        searchRunnable = Runnable {
            performSearch(newQuery)
        }
        handler.postDelayed(searchRunnable!!, 500)

        return true
    }

    override fun onQueryTextSubmit(query: String): Boolean {
        Log.d("SearchFragment", "Query submitted: $query")
        performSearch(query)
        return true
    }

    private fun performSearch(query: String) {
        rowsAdapter.clear()

        if (query.isEmpty()) {
            return
        }

        // Get all movies from MovieList
        val allMovies = MovieList.categories.flatMap { it.movies }

        // Filter movies by name (case-insensitive)
        val filteredMovies = allMovies.filter { movie ->
            movie.title?.contains(query, ignoreCase = true) == true
        }

        Log.d("SearchFragment", "Found ${filteredMovies.size} results for '$query'")

        if (filteredMovies.isNotEmpty()) {
            val cardPresenter = CardPresenter()
            val listRowAdapter = ArrayObjectAdapter(cardPresenter)

            filteredMovies.forEach { movie ->
                listRowAdapter.add(movie)
            }

            val header = HeaderItem(0, "Search Results ($query)")
            rowsAdapter.add(ListRow(header, listRowAdapter))
        } else {
            // Show "No results" message
            val cardPresenter = CardPresenter()
            val listRowAdapter = ArrayObjectAdapter(cardPresenter)
            val header = HeaderItem(0, "No results found")
            rowsAdapter.add(ListRow(header, listRowAdapter))
        }
    }

    private inner class ItemViewClickedListener : OnItemViewClickedListener {
        override fun onItemClicked(
            itemViewHolder: Presenter.ViewHolder,
            item: Any,
            rowViewHolder: RowPresenter.ViewHolder,
            row: Row
        ) {
            if (item is Movie) {
                val intent = Intent(activity, DetailsActivity::class.java)
                intent.putExtra(DetailsActivity.MOVIE, item)

                val bundle = ActivityOptionsCompat.makeSceneTransitionAnimation(
                    activity!!,
                    (itemViewHolder.view as ImageCardView).mainImageView,
                    DetailsActivity.SHARED_ELEMENT_NAME
                ).toBundle()

                startActivity(intent, bundle)
            }
        }
    }
}