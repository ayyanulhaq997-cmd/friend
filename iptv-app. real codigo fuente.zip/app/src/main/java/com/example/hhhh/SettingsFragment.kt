// SettingsFragment.kt - Updated with String Resources
package com.example.hhhh

import android.content.Intent
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.leanback.app.GuidedStepSupportFragment
import androidx.leanback.widget.GuidanceStylist
import androidx.leanback.widget.GuidedAction

class SettingsFragment : GuidedStepSupportFragment() {

    companion object {
        private const val ACTION_USER = 1L
        private const val ACTION_PREFERENCE = 2L
        private const val ACTION_PARENTAL = 3L
        private const val ACTION_TUTORIAL = 4L
        private const val ACTION_LANGUAGE = 5L
        private const val ACTION_BACK = 6L
    }

    override fun onCreateGuidance(savedInstanceState: Bundle?): GuidanceStylist.Guidance {
        val title = getString(R.string.settings_title)
        val description = getString(R.string.settings_description)
        val icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_settings)

        return GuidanceStylist.Guidance(title, description, "", icon)
    }

    override fun onCreateActions(actions: MutableList<GuidedAction>, savedInstanceState: Bundle?) {
        // User Account
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_USER)
                .title(getString(R.string.user))
                .description(getString(R.string.user_account))
                .icon(R.drawable.ic_user)
                .build()
        )

        // Preference
//        actions.add(
//            GuidedAction.Builder(requireContext())
//                .id(ACTION_PREFERENCE)
//                .title(getString(R.string.preference))
//                .description(getString(R.string.set_user_preferences))
//                .icon(R.drawable.ic_preference)
//                .build()
//        )

        // Parental Control
//        actions.add(
//            GuidedAction.Builder(requireContext())
//                .id(ACTION_PARENTAL)
//                .title(getString(R.string.parental_control))
//                .description(getString(R.string.adult_content_management))
//                .icon(R.drawable.ic_parental)
//                .build()
//        )

        // Tutorial
//        actions.add(
//            GuidedAction.Builder(requireContext())
//                .id(ACTION_TUTORIAL)
//                .title(getString(R.string.tutorial))
//                .description(getString(R.string.show_video_tutorial))
//                .icon(R.drawable.ic_tutorial)
//                .build()
//        )

        // Language
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_LANGUAGE)
                .title(getString(R.string.language))
                .description(getString(R.string.language_of_application))
                .icon(R.drawable.ic_language)
                .build()
        )

        // Back
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_BACK)
                .title(getString(R.string.back))
                .description("")
                .icon(R.drawable.ic_back)
                .build()
        )
    }

    override fun onGuidedActionClicked(action: GuidedAction) {
        when (action.id) {
            ACTION_USER -> {
                add(fragmentManager, UserAccountFragment())
            }
            ACTION_PREFERENCE -> {
                add(fragmentManager, PreferenceFragment())
            }
            ACTION_PARENTAL -> {
                add(fragmentManager, ParentalControlFragment())
            }
            ACTION_TUTORIAL -> {
                // Show tutorial - you can implement this
            }
            ACTION_LANGUAGE -> {
                add(fragmentManager, LanguageFragment())
            }
            ACTION_BACK -> {
                val intent = Intent(requireContext(), HomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                startActivity(intent)
                activity?.finish()
            }
        }
    }
}