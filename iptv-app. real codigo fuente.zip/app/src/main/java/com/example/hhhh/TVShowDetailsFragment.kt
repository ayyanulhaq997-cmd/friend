// TVShowDetailsFragment.kt
package com.example.hhhh

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.hhhh.TVShowList.TAG
import com.example.hhhh.api.ApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TVShowDetailsFragment : Fragment() {

    private lateinit var tvShow: TVShow

    // UI references
    private lateinit var favoriteButton: Button
    private lateinit var favoriteBadge: TextView

    // Settings
    private var selectedAudioIndex = 0
    private var selectedSubtitleIndex = 1
    private var subtitleColor = Color.WHITE
    private var subtitleSize = 0.06f

    private var episodeLastPosition = 0L

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        tvShow = activity?.intent?.getSerializableExtra(TVShowDetailsActivity.TVSHOW) as TVShow
        return createCustomLayout()
    }

    private fun createCustomLayout(): View {
        val context = requireContext()

        // Main container
        val mainLayout = FrameLayout(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0A1929"))
        }

        // Background image
        val backgroundImage = ImageView(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.3f
        }
        Glide.with(context).load(tvShow.bg_url).into(backgroundImage)
        mainLayout.addView(backgroundImage)

        // Content container
        val contentLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setPadding(60, 60, 60, 60)
        }

        // ---------------- BUTTONS ROW -----------------
        val trailerButton = Button(context).apply {
            text = "WATCH TRAILER"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#3D5A80"))
            setPadding(40, 20, 40, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setOnClickListener { playTrailer() }
        }

        favoriteButton = Button(context).apply {
            text = if (tvShow.favorite == true) "REMOVE FAVORITE" else "ADD FAVORITE"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#3D5A80"))
            setPadding(40, 20, 40, 20)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setOnClickListener { toggleFavorite() }
        }

        val buttonRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 40 }
        }

        buttonRow.addView(trailerButton)
        // Space between buttons
        val gap = Space(context).apply { layoutParams = LinearLayout.LayoutParams(40, 1) }
        buttonRow.addView(gap)
        buttonRow.addView(favoriteButton)

        contentLayout.addView(buttonRow)
        // ----------------------------------------------

        // Content horizontal layout (poster + episodes + info)
        val horizontalLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        // Poster image
        val posterImage = ImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(300, 200).apply { marginEnd = 40 }
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        Glide.with(context).load(tvShow.card_url).into(posterImage)
        horizontalLayout.addView(posterImage)

        // Episodes container
        val episodesContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(520, LinearLayout.LayoutParams.MATCH_PARENT)
                .apply { marginEnd = 40 }
        }

        tvShow.seasons.forEach { season ->
            if (season.episodes.isNotEmpty()){
                val seasonHeader = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    setBackgroundColor(Color.parseColor("#2C4A6B"))
                    setPadding(20, 15, 20, 15)
                    isFocusable = true
                    isFocusableInTouchMode = true
                }

                val seasonText = TextView(context).apply {
                    text = "Season ${season.season_number}"
                    textSize = 20f
                    setTextColor(Color.WHITE)
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                seasonHeader.addView(seasonText)

                val dropdownIcon = TextView(context).apply {
                    text = "▼"
                    textSize = 16f
                    setTextColor(Color.WHITE)
                }
                seasonHeader.addView(dropdownIcon)
                episodesContainer.addView(seasonHeader)

                val episodesList = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    visibility = View.VISIBLE
                }

                season.episodes.forEach { episode ->
                    episodesList.addView(createEpisodeItem(episode))
                }
                episodesContainer.addView(episodesList)

                var isExpanded = true
                seasonHeader.setOnClickListener {
                    isExpanded = !isExpanded
                    episodesList.visibility = if (isExpanded) View.VISIBLE else View.GONE
                    dropdownIcon.text = if (isExpanded) "▼" else "▶"
                }
                seasonHeader.setOnFocusChangeListener { v, hasFocus ->
                    v.setBackgroundColor(if (hasFocus) Color.parseColor("#4C6A8B") else Color.parseColor("#2C4A6B"))
                }
            }

        }

        // Wrap episodes in ScrollView
        val episodesScroll = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(520, LinearLayout.LayoutParams.MATCH_PARENT)
                .apply { marginEnd = 40 }
            addView(episodesContainer)
        }
        horizontalLayout.addView(episodesScroll)

        // Info panel
        horizontalLayout.addView(createInfoPanel())
        contentLayout.addView(horizontalLayout)
        mainLayout.addView(contentLayout)

        return mainLayout
    }

    private fun createEpisodeItem(episode: Episode): View {
        val context = requireContext()
        val episodeLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(Color.parseColor("#2A2A2A"))
            setPadding(20, 20, 20, 20)
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { showEpisodeOptionsDialog(episode) }
        }

        // Viewed icon
        if (episode.viewed == true) {
            val viewedIcon = ImageView(context).apply {
                setImageResource(android.R.drawable.ic_menu_view)
                setColorFilter(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(40, 40).apply { marginEnd = 12 }
            }
            episodeLayout.addView(viewedIcon)
        }

        // Episode title
        val episodeText = TextView(context).apply {
            text = "${episode.episodeNumber} - Capitulo ${episode.episodeNumber}"
            textSize = 18f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            )
        }
        episodeLayout.addView(episodeText)

        // Flags container
        val flagsLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Add flags based on track field
        episode.track?.split(",")?.forEach { lang ->
            val flagIcon = ImageView(context).apply {
                layoutParams = LinearLayout.LayoutParams(36, 24).apply { marginEnd = 6 }
               when (lang.lowercase().trim()) {
                    "eng" -> setImageResource(R.drawable.flag_us)
                    "spa" -> setImageResource(R.drawable.flag_es)
                    "fra" -> setImageResource(R.drawable.flag_fr)
                    "pt" -> setImageResource(R.drawable.flag_pt)
                    else -> setImageResource(android.R.drawable.ic_dialog_info)
                }
            }
            flagsLayout.addView(flagIcon)
        }

        episodeLayout.addView(flagsLayout)

        // Focus effect
        episodeLayout.setOnFocusChangeListener { v, hasFocus ->
            v.setBackgroundColor(if (hasFocus) Color.parseColor("#4A4A4A") else Color.parseColor("#2A2A2A"))
        }

        return episodeLayout
    }


    private fun createInfoPanel(): View {
        val context = requireContext()
        val infoLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        }

        // Title
        infoLayout.addView(TextView(context).apply {
            text = tvShow.title
            textSize = 48f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 20 }
        })

        // Genre
        infoLayout.addView(TextView(context).apply {
            text = tvShow.genre_names ?: "Animation - Action - Adventure - Fantasy - Sci-Fi"
            textSize = 18f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 20 }
        })

        // Year
        infoLayout.addView(TextView(context).apply {
            text = "📅 ${tvShow.released_year ?: "1996"}"
            textSize = 16f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 20 }
        })

        // Badges row (Viewed + Favorite)
        val badgeRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 20 }
        }

        if (tvShow.viewed == true) {
            badgeRow.addView(TextView(context).apply {
                text = "👁️ Viewed"
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(10, 5, 20, 5)
            })
        }

        favoriteBadge = TextView(context).apply {
            text = "⭐ Favorite"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(10, 5, 10, 5)
            visibility = if (tvShow.favorite == true) View.VISIBLE else View.GONE
        }
        badgeRow.addView(favoriteBadge)

        if (tvShow.viewed == true || tvShow.favorite == true) infoLayout.addView(badgeRow)

        // Age rating
        infoLayout.addView(TextView(context).apply {
            text = "TV-PG"
            textSize = 16f
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.WHITE)
            setPadding(16, 8, 16, 8)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 20 }
        })

        // Rating
        infoLayout.addView(TextView(context).apply {
            text = "⭐⭐⭐⭐⭐ ${tvShow.rate ?: "8.7"}"
            textSize = 18f
            setTextColor(Color.parseColor("#FFD700"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 30 }
        })

        // Description
        infoLayout.addView(TextView(context).apply {
            text = tvShow.description ?: ""
            textSize = 16f
            setTextColor(Color.parseColor("#CCCCCC"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        })

        return infoLayout
    }

    private fun playTrailer() {
        Log.d("TVShowDetails", "Playing trailer")
    }

    private fun toggleFavorite() {
        Log.d(TAG, "toggleFavorite")
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response = ApiClient.api.addTVShowFavorite(tvShow.id)
                if (response.status) {
                    tvShow.favorite = response.favorite == 1

                    // Update button text and badge visibility
                    favoriteButton.text = if (tvShow.favorite == true) "REMOVE FAVORITE" else "ADD FAVORITE"
                    favoriteBadge.visibility = if (tvShow.favorite == true) View.VISIBLE else View.GONE

                    val message = if (tvShow.favorite == true) "Added to favorites" else "Removed from favorites"
                    Toast.makeText(requireActivity(), message, Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireActivity(), "Failed to update favorite", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error updating favorite: ${e.message}")
            }
        }
    }

    private fun showEpisodeOptionsDialog(episode: Episode) {
        val options = arrayOf("Watch now", "Audio", "Subtitle")
        val title = "${episode.title}\nRating: ⭐⭐⭐⭐⭐ ${episode.rating ?: "8.6"}"



        android.app.AlertDialog.Builder(requireActivity())
            .setTitle(title)
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> {
                        dialog.dismiss()
                        playEpisode(episode)
                    }
                    1 -> {
                        dialog.dismiss()
                        showAudioSelection(episode)
                    }
                    2 -> {
                        dialog.dismiss()
                        showSubtitleSelection(episode)
                    }
                }
            }
            .setNegativeButton("BACK", null)
            .show()
    }

    private fun showAudioSelection(episode: Episode) {
        // Map language codes to display names
        val languageMap = mapOf(
            "eng" to "English",
            "spa" to "Spanish",
            "fra" to "French",
            "pt"  to "Portuguese"
        )

        // Split episode.language by comma and map to display names
        val options = episode.track
            ?.split(",")
            ?.map { lang -> languageMap[lang.lowercase().trim()] ?: lang }
            ?.toMutableList() ?: mutableListOf()

        // Add Mute option
        options.add("Mute")

        // Show the dialog
        android.app.AlertDialog.Builder(requireActivity())
            .setTitle("Audio selection")
            .setSingleChoiceItems(options.toTypedArray(), selectedAudioIndex) { dialog, which ->
                selectedAudioIndex = which
                dialog.dismiss()
                showEpisodeOptionsDialog(episode)
            }
            .setNegativeButton("CANCEL") { _, _ ->
                showEpisodeOptionsDialog(episode)
            }
            .show()
    }


    private fun showSubtitleSelection(episode: Episode) {
        val options = arrayOf("Disabled", "English", "Spanish")
        android.app.AlertDialog.Builder(requireActivity())
            .setTitle("Subtitle selection")
            .setSingleChoiceItems(options, selectedSubtitleIndex) { dialog, which ->
                selectedSubtitleIndex = which
                dialog.dismiss()
                if (which == 0) {
                    android.app.AlertDialog.Builder(requireActivity())
                        .setTitle("Warning")
                        .setMessage("No subtitle included")
                        .setPositiveButton("OK") { warningDialog, _ ->
                            warningDialog.dismiss()
                            showEpisodeOptionsDialog(episode)
                        }
                        .show()
                } else showEpisodeOptionsDialog(episode)
            }
            .setNegativeButton("CANCEL") { _, _ -> showEpisodeOptionsDialog(episode) }
            .show()
    }

    private fun playEpisode(episode: Episode) {
        CoroutineScope(Dispatchers.Main).launch {
            // Wait for API result
            val position = getEpisodeLastPositionSuspend(episode.id)

            val intent = Intent(activity, PlaybackActivity::class.java).apply {
                putExtra(PlaybackActivity.EPISODE, episode)
                putExtra(PlaybackActivity.TVSHOW, tvShow)
                putExtra("audioIndex", selectedAudioIndex)
                putExtra("subtitleIndex", selectedSubtitleIndex)
                putExtra("subtitleColor", subtitleColor)
                putExtra("subtitleSize", subtitleSize)
                putExtra("savedPosition", position)
            }
            startActivity(intent)
        }
    }


    private suspend fun getEpisodeLastPositionSuspend(id: Int?): Long {
        return try {
            val response = ApiClient.api.getEpisodeLastPosition(id)
            if (response.status) response.lastPosition else 0L
        } catch (e: Exception) {
            0L
        }
    }
}
