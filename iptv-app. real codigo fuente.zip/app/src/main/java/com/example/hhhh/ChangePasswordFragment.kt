// ChangePasswordFragment.kt - Fixed Input Handling
package com.example.hhhh

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.leanback.app.GuidedStepSupportFragment
import androidx.leanback.widget.GuidanceStylist
import androidx.leanback.widget.GuidedAction
import com.example.hhhh.api.ApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChangePasswordFragment : GuidedStepSupportFragment() {

    companion object {
        private const val TAG = "ChangePasswordFragment"
        private const val ACTION_OLD_PASSWORD = 1L
        private const val ACTION_NEW_PASSWORD = 2L
        private const val ACTION_CONFIRM_PASSWORD = 3L
        private const val ACTION_SUBMIT = 4L
        private const val ACTION_CANCEL = 5L
    }

    private var oldPassword: String = ""
    private var newPassword: String = ""
    private var confirmPassword: String = ""

    private var changePasswordJob: Job? = null

    override fun onCreateGuidance(savedInstanceState: Bundle?): GuidanceStylist.Guidance {
        val title = getString(R.string.change_password_title)
        val description = getString(R.string.change_password_description)
        val icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_key)

        return GuidanceStylist.Guidance(title, description, "", icon)
    }

    override fun onCreateActions(actions: MutableList<GuidedAction>, savedInstanceState: Bundle?) {
        // Old Password
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_OLD_PASSWORD)
                .title(getString(R.string.current_password))
                .editTitle("")
                .editable(true)
                .inputType(android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD)
                .build()
        )

        // New Password
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_NEW_PASSWORD)
                .title(getString(R.string.new_password))
                .editTitle("")
                .editable(true)
                .inputType(android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD)
                .build()
        )

        // Confirm Password
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_CONFIRM_PASSWORD)
                .title(getString(R.string.confirm_password))
                .editTitle("")
                .editable(true)
                .inputType(android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD)
                .build()
        )

        // Submit
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_SUBMIT)
                .title(getString(R.string.submit))
                .icon(R.drawable.ic_key)
                .build()
        )

        // Cancel
        actions.add(
            GuidedAction.Builder(requireContext())
                .id(ACTION_CANCEL)
                .title(getString(R.string.cancel))
                .icon(R.drawable.ic_back)
                .build()
        )
    }

    override fun onGuidedActionClicked(action: GuidedAction) {
        when (action.id) {
            ACTION_SUBMIT -> {
                handleSubmit()
            }
            ACTION_CANCEL -> {
                fragmentManager?.popBackStack()
            }
        }
    }

    override fun onGuidedActionEditedAndProceed(action: GuidedAction): Long {
        // Store the entered values
        val inputText = action.editTitle?.toString() ?: ""

        when (action.id) {
            ACTION_OLD_PASSWORD -> {
                oldPassword = inputText
            }
            ACTION_NEW_PASSWORD -> {
                newPassword = inputText
            }
            ACTION_CONFIRM_PASSWORD -> {
                confirmPassword = inputText
            }
        }

        // Return GuidedAction.ACTION_ID_NEXT to proceed without showing error message
        return GuidedAction.ACTION_ID_NEXT
    }

    override fun onGuidedActionEditCanceled(action: GuidedAction) {
        // User canceled editing, keep the previous value
        super.onGuidedActionEditCanceled(action)
    }

    private fun handleSubmit() {
        // Validate inputs
        if (!validateInputs()) {
            return
        }

        // Call API to change password
        changePassword()
    }

    private fun validateInputs(): Boolean {
        // Check if old password is entered
        if (oldPassword.isEmpty()) {
            showError(getString(R.string.enter_current_password_prompt))
            // Focus on old password field
            actions?.find { it.id == ACTION_OLD_PASSWORD }?.let {
                selectedActionPosition = findActionPositionById(ACTION_OLD_PASSWORD)
            }
            return false
        }

        // Check if new password is entered
        if (newPassword.isEmpty()) {
            showError(getString(R.string.enter_new_password_prompt))
            selectedActionPosition = findActionPositionById(ACTION_NEW_PASSWORD)
            return false
        }

        // Check if new password is at least 6 characters
        if (newPassword.length < 6) {
            showError(getString(R.string.password_too_short))
            selectedActionPosition = findActionPositionById(ACTION_NEW_PASSWORD)
            return false
        }

        // Check if confirm password is entered
        if (confirmPassword.isEmpty()) {
            showError(getString(R.string.reenter_new_password))
            selectedActionPosition = findActionPositionById(ACTION_CONFIRM_PASSWORD)
            return false
        }

        // Check if passwords match
        if (newPassword != confirmPassword) {
            showError(getString(R.string.passwords_do_not_match))
            selectedActionPosition = findActionPositionById(ACTION_CONFIRM_PASSWORD)
            return false
        }

        // Check if new password is different from old password
        if (oldPassword == newPassword) {
            showError(getString(R.string.password_same_as_old))
            selectedActionPosition = findActionPositionById(ACTION_NEW_PASSWORD)
            return false
        }

        return true
    }

    private fun changePassword() {
        changePasswordJob?.cancel()
        changePasswordJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                // Show loading
                showLoading(true)

                // Create request body
                val request = ChangePasswordRequest(
                    old_password = oldPassword,
                    new_password = newPassword
                )

                // Call API
                val response = withContext(Dispatchers.IO) {
                    ApiClient.api.changePassword(request)
                }

                // Check if fragment is still active
                if (!isAdded) return@launch

                // Hide loading
                showLoading(false)

                // Handle response
                if (response.status) {
                    // Success
                    showSuccess(response.message ?: getString(R.string.password_changed_success))

                    Log.d(TAG, "Password changed successfully")

                    // Go back after short delay
                    kotlinx.coroutines.delay(1500)
                    if (isAdded) {
                        fragmentManager?.popBackStack()
                    }
                } else {
                    // Failed
                    showError(response.message ?: getString(R.string.failed_to_change_password))
                    Log.e(TAG, "Password change failed: ${response.message}")
                }

            } catch (e: Exception) {
                if (!isAdded) return@launch

                showLoading(false)

                Log.e(TAG, "Error changing password", e)
                showError("${getString(R.string.error)}: ${e.message ?: getString(R.string.unknown_error)}")
            }
        }
    }

    private fun showLoading(show: Boolean) {
        // Disable/enable actions during loading
        findActionById(ACTION_SUBMIT)?.let { action ->
            action.isEnabled = !show
            notifyActionChanged(findActionPositionById(ACTION_SUBMIT))
        }

        if (show) {
            Toast.makeText(requireContext(), getString(R.string.loading), Toast.LENGTH_SHORT).show()
        }
    }

    private fun showError(message: String) {
        if (isAdded) {
            Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
        }
    }

    private fun showSuccess(message: String) {
        if (isAdded) {
            Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        changePasswordJob?.cancel()

        // Clear sensitive data
        oldPassword = ""
        newPassword = ""
        confirmPassword = ""
    }
}