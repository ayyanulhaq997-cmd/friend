// TVShowList.kt - Updated to use your existing API
package com.example.hhhh

import android.util.Log
import com.example.hhhh.api.TVShowApi
import com.example.hhhh.TVShowCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object TVShowList {

    const val TAG = "TVShowList"
    val categories = mutableListOf<TVShowCategory>()

    suspend fun loadFromApi(): Boolean = withContext(Dispatchers.IO) {
        try {
            categories.clear()

            val response = TVShowApi.getTVShowCategories()
                ?: return@withContext false.also {
                    Log.e(TAG, "API call returned null")
                }

            val data = response.data

            if (data.isEmpty()) {
                Log.e(TAG, "No data in response")
                return@withContext false
            }

            categories.addAll(data)
            Log.d(TAG, "Loaded ${categories.size} categories")

            true

        } catch (e: Exception) {
            Log.e(TAG, "Error loading from API: ${e.message}", e)
            false
        }
    }


    suspend fun loadFromApiWithSort(sortBy: String, sortOrder: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                categories.clear()

                val response = TVShowApi.getTVShowBySort(sortBy, sortOrder)
                    ?: return@withContext false.also {
                        Log.e(TAG, "API call returned null")
                    }

                val data = response.data

                if (data.isEmpty()) {
                    Log.e(TAG, "No data in response")
                    return@withContext false
                }

                categories.addAll(data)
                Log.d(TAG, "Loaded ${categories.size} categories with sort: $sortBy - $sortOrder")
                true

            } catch (e: Exception) {
                Log.e(TAG, "Error loading from API with sort: ${e.message}", e)
                false
            }
        }

    suspend fun loadFavoriteTVShows(): Boolean = withContext(Dispatchers.IO) {
        try {
            categories.clear()

            val response = TVShowApi.getFavoriteTVShows()
                ?: return@withContext false.also {
                    Log.e(TAG, "API call returned null")
                }

            val data = response.data

            if (data.isEmpty()) {
                Log.e(TAG, "No data in response")
                return@withContext false
            }

            categories.addAll(data)
            Log.d(TAG, "Loaded ${categories.size} favorite categories")

            true

        } catch (e: Exception) {
            Log.e(TAG, "Error loading favorites: ${e.message}", e)
            false
        }
    }

}