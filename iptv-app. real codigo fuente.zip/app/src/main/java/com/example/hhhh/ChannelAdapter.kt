package com.example.hhhh.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.hhhh.R
import com.example.hhhh.models.Channel

class ChannelAdapter(
    private val channels: List<Channel>,
    private val onChannelClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.ChannelViewHolder>() {

    inner class ChannelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val channelNumber: TextView = itemView.findViewById(R.id.channelNumber)
        private val channelLogo: ImageView = itemView.findViewById(R.id.channelLogo)
        private val channelName: TextView = itemView.findViewById(R.id.channelName)

        fun bind(channel: Channel, position: Int) {
            channelNumber.text = (position + 1).toString()
            channelName.text = channel.tv_name ?: "Unknown Channel"

            Glide.with(itemView.context)
                .load(channel.thumbnail)
                .placeholder(R.drawable.gradient_overlay)
                .into(channelLogo)

            itemView.setOnClickListener {
                onChannelClick(channel)
            }

            // TV Focus effect
            itemView.setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    itemView.setBackgroundColor(0xFF00a8e8.toInt())
                } else {
                    itemView.setBackgroundColor(0x00000000)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel_list, parent, false)
        return ChannelViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        holder.bind(channels[position], position)
    }

    override fun getItemCount() = channels.size
}