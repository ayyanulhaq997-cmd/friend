// TVShowsActivity.kt
package com.example.hhhh

import android.os.Bundle
import androidx.fragment.app.FragmentActivity

class TVShowsActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tvshows)

        if (savedInstanceState == null) {
            val fragment = TVShowsFragment()
            supportFragmentManager.beginTransaction()
                .replace(R.id.tvshows_fragment, fragment)
                .commitNow()
        }
    }
}