package com.example.hhhh

data class IconItem(
    val id: Int,
    val title: String,
    val iconRes: Int
)
