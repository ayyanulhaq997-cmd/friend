<?php


use App\Http\Controllers\SubresellersController;
use App\Http\Controllers\ResellersController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\CustomersController;
use App\Http\Controllers\MoviesController;
use App\Http\Controllers\SeriesController;
use App\Http\Controllers\TransactionsController;
use App\Http\Controllers\ChannelsController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\ProxyController;
use Inertia\Inertia;

Route::get('/', function () {
    return redirect()->route('dashboard');
});

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/home/menu', [DashboardController::class, 'getMenuData'])->name('home.menu');
});

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::middleware(['auth'])->group(function () {
    //Profile Routes
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    //Customers Routes
    Route::get('/customers/index', [CustomersController::class, 'index'])->name('customers.index');
    Route::get('/customers/create', [CustomersController::class, 'create'])->name('customers.create');
    Route::get('/customers/demo', [CustomersController::class, 'demo'])->name('customers.demo');
    Route::post('/customers/store', [CustomersController::class, 'store'])->name('customers.store');
    Route::get('/customers/edit/{id}', [CustomersController::class, 'edit'])->name('customers.edit');
    Route::post('/customers/update/{id}', [CustomersController::class, 'update'])->name('customers.update');
    Route::post('/customers/delete/{id}', [CustomersController::class, 'delete'])->name('customers.delete');
    Route::post('/customers/add/subscription', [CustomersController::class, 'addSubscription']);
    Route::post('/customers/stop/subscription/{id}', [CustomersController::class, 'stopSubscription']);
    Route::post('/customers/resume/subscription/{id}', [CustomersController::class, 'resumeSubscription']);
    Route::post('/customers/delete/subscription/{id}', [CustomersController::class, 'deleteSubscription']);
    //SubResellers Routes
    Route::get('/subresellers/index', [SubresellersController::class, 'index'])->name('subresellers.index');

    Route::middleware(['role'])->group(function () {


        Route::get('/subresellers/create', [SubresellersController::class, 'create'])->name('subresellers.create');
        Route::post('/subresellers/store', [SubresellersController::class, 'store'])->name('subresellers.store');
        Route::get('/subresellers/edit/{id}', [SubresellersController::class, 'edit'])->name('subresellers.edit');
        Route::post('/subresellers/update/{id}', [SubresellersController::class, 'update'])->name('subresellers.update');
        Route::post('/subresellers/delete/{id}', [SubresellersController::class, 'delete'])->name('subresellers.delete');
        Route::post('/subresellers/add/credit', [SubresellersController::class, 'addCredit'])->name('subresellers.addCredit');
    });


    // Route::middleware(['role'])->group(function () {
    Route::get('/resellers/index', [ResellersController::class, 'index'])->name('resellers.index');
    Route::get('/resellers/create', [ResellersController::class, 'create'])->name('resellers.create');
    Route::post('/resellers/store', [ResellersController::class, 'store'])->name('resellers.store');
    Route::get('/resellers/edit/{id}', [ResellersController::class, 'edit'])->name('resellers.edit');
    Route::post('/resellers/update/{id}', [ResellersController::class, 'update'])->name('resellers.update');
    Route::post('/resellers/delete/{id}', [ResellersController::class, 'delete'])->name('resellers.delete');
    Route::post('/resellers/add/credit', [ResellersController::class, 'addCredit'])->name('resellers.addCredit');
    // });

    //Movie, Vod Routes
    Route::get('/movie_vod/index', [MoviesController::class, 'index'])->name('movie_vod.index');
    Route::get('/movie_vod/search', [MoviesController::class, 'search'])->name('movie_vod.search');
    Route::get('/movie_vod/detail', [MoviesController::class, 'detail'])->name('movie_vod.detail');
    Route::post('/movie_vod/delete/{id}', [MoviesController::class, 'delete'])->name('movie_vod.delete');
    Route::post('/movie_vod/upload', [MoviesController::class, 'upload'])->name('movie_vod.upload');

    Route::get('/movie_vod/import', [MoviesController::class, 'import'])->name('movie_vod.import');
    Route::post('/movie_vod/tmdb_data', [MoviesController::class, 'tmdbData'])->name('movie_vod.tmdb');
    Route::post('/movie_vod/import_movie', [MoviesController::class, 'importMovie'])->name('movie_vod.import');
    Route::get('/movie_vod/edit/{id}', action: [MoviesController::class, 'editMovie'])->name('movie_vod.editMovie');
    Route::post('/movie_vod/edit', action: [MoviesController::class, 'updateMovie'])->name('movie_vod.updateMovie');
    Route::get('/movie_match/index', action: [MoviesController::class, 'matchIndex'])->name('movie_match.index');
    Route::post('/movie_match/manual', action: [MoviesController::class, 'matchByManual'])->name('movie_match.manual');
    //Series Route
    Route::get('/series/index', [SeriesController::class, 'index'])->name('series.index');
    Route::get('/series/season/{id}', [SeriesController::class, 'season'])->name('series.season');
    Route::get('/series/episod/{id}', [SeriesController::class, 'episod'])->name('series.episod');
    Route::get('/series/search', [SeriesController::class, 'search'])->name('series.search');
    Route::get('/episod/detail', [SeriesController::class, 'episodDetail'])->name('episod.detail');

    //Transactions Routes
    Route::get('/transactions/index', [TransactionsController::class, 'index'])->name('transactions.index');
    Route::get('/transactions/search', [TransactionsController::class, 'search'])->name('transactions.search');
    Route::get('/transactions/sent/index', [TransactionsController::class, 'sent'])->name('transactions.sent');

    //Channels Routes
    Route::get('/channels/index', [ChannelsController::class, 'index'])->name('channels.index');
    Route::get('/channels/create', [ChannelsController::class, 'create'])->name('channels.create');
    Route::get('/channels/edit/{id}', [ChannelsController::class, 'edit'])->name('channels.edit');
    Route::post('/channels/store', [ChannelsController::class, 'store'])->name('channels.store');
    Route::post('/channels/update', [ChannelsController::class, 'update'])->name('channels.update');
    Route::post('/channels/delete/{id}', [ChannelsController::class, 'delete'])->name('channels.delete');
    Route::get('/channels/search', [ChannelsController::class, 'search'])->name('channels.search');
    Route::post('/channels/publish', [ChannelsController::class, 'publish'])->name('channels.publish');


});



Route::get('/m3u8-proxy', [ProxyController::class, 'fetchM3u8']);
Route::get('/proxy', [ProxyController::class, 'segment']);


Route::get('/video/playlist', [ProxyController::class, 'signedMasterPlaylist']);
Route::get('/video/getmp4', [ProxyController::class, 'getSignedMp4Url']);
Route::get('/video/signed/{filename}', [ProxyController::class, 'signedUrl']);
Route::get('/video/signed/{filename}/{segment}', [ProxyController::class, 'signedSegmentUrl']);
Route::get('/video/{filename}/master', [ProxyController::class, 'signedMaster']);
Route::get('/segment/{filename}/{segment}', [ProxyController::class, 'signedSegmentUrl']);
Route::get('/test', function () {
    return Inertia('Test');
});


//Route::get('/movie_match/sync_by_tmdb', action: [MoviesController::class, 'syncByTmdb'])->name('movie_match.tmdb');
Route::get('/movie_match/sync_by_tmdb', action: [SeriesController::class, 'suncSeriesByTmdb'])->name('movie_match.tmdb');
Route::get('/series_match/sync_by_tmdb', action: [SeriesController::class, 'suncSeriesByTmdb'])->name('series_match.tmdb');
Route::get('/movie_match/sync_by_ai', action: [MoviesController::class, 'syncByAI'])->name('movie_match.tmdb');

//Sync Top Rated Vidoes
Route::get('/sync/top_rate', action: function () {
    syncTopRate();
});

//Sync Popular Vidoes
Route::get('/sync/popular', action: function () {
    syncPopular();
});

//Sync Oscar Vidoes
Route::get('/sync/oscar', action: function () {
    syncOscar();
});


//Sync Oscar Vidoes
Route::get('/sync/saga', action: function () {
    syncSaga();
});

//Import Live Channel 
Route::get('/import/live_channel', action: function () {
    importLiveChannel();
});


//Sync Oscar Vidoes
Route::get('/sync/series_data', action: function () {
    syncSeriesData();
});


require __DIR__ . '/auth.php';
