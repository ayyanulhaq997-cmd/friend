<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProxyController;
use App\Http\Controllers\HLSController;

Route::get('/check_info/{title}', [ApiController::class, 'checkInfo']);

Route::get('/movies/{title}', [ApiController::class, 'confirmMovie']);
Route::get('/movies_count', [ApiController::class, 'confirmCount']);
Route::post('/movies_create/tv', [ApiController::class, 'createSeries']);
Route::post('/movies_create/movie', [ApiController::class, 'createMovie']);
Route::post('/movies_update', [ApiController::class, 'updateMovie']);
Route::get('/movies_edit/{id}', [ApiController::class, 'editMovie']);

Route::get('/login', [ApiController::class, 'login'])->middleware('log.login');;
Route::middleware('credit')->group(function () {
    
    //Movie Routes
    Route::get('/get_movie_by_sort', [ApiController::class, 'getMovieBySort']);
    Route::get('/get_movie_favorite', [ApiController::class, 'getMovieFavorite']);
    Route::get('/get_movie_detail', [ApiController::class, 'getMovieDetail']);
    Route::get('/add_movie_favorite', [ApiController::class, 'addMovieFavorite']);
    
    //Sereis Routes    
    Route::get('/get_tv_categories', [ApiController::class, 'getTVCategories']);
    Route::get('/get_tv_by_sort', [ApiController::class, 'getTvBySort']);
    Route::get('/get_tv_favorite', [ApiController::class, 'getTVFavorite']);
    Route::get('/add_tv_favorite', [ApiController::class, 'addTVFavorite']);
    Route::get('/get_episode_last_position', [ApiController::class, 'getEpisodeLastPosition']);
    
    //User Routes
    Route::get('/user_home_data', [ApiController::class, 'getUserHomeData']);
    Route::get('/user_setting_data', [ApiController::class, 'getUserSettingData']);
    Route::post('/change_password', [ApiController::class, 'changePassword']);
    //Urlsigning Routes
    Route::get('/get_signed_url', [ApiController::class, 'getSignedUrl']);
    //Save Playback Position
    Route::post('/save_playback_position', [ApiController::class, 'savePlaybackPosition']);
    // search with movie title
    Route::get('/search_movies', [ApiController::class, 'searchMovies']);
    // search with series title
    Route::get('/search_series', [ApiController::class, 'searchSeries']);
    

    //Channels Routes
    Route::get('get_all_channels', [ApiController::class, 'getAllChannels']);

});






Route::get('/check_info_all', [ApiController::class, 'checkInfoAll']);
Route::get('/movie_exist/{type}/{tmdb_id}', [ApiController::class, 'checkMovie']);

// generate HLS route
Route::get('/hls/{path}', [HLSController::class, 'proxy'])
    ->where('path', '.*');
