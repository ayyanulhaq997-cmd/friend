<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class HLSController extends Controller
{
    public function proxy(Request $request, $path)
    {
        /** @var \Illuminate\Filesystem\AwsS3V3Adapter|\Illuminate\Filesystem\FilesystemAdapter $disk */
        $disk = Storage::disk('sharktech');
        if (str_ends_with($path, '.m3u8')) {
            $signed = $disk->temporaryUrl($path, now()->addMinutes(60));
            $response = Http::get($signed);
            $content = $response->body();
            return $this->rewriteM3U8($content, $path);
        }
        // TS or VTT segments: return signed URL directly
        $signed = $disk->temporaryUrl($path, now()->addMinutes(10));
        return redirect($signed);
    }

    private function rewriteM3U8($content, $basePath)
    {
        $lines = explode("\n", $content);
        $baseDir = dirname($basePath);
        $new = [];

        foreach ($lines as $line) {
            $trim = trim($line);

            if ($trim !== '' && !str_starts_with($trim, '#')) {
                // Rewrite the path to go through your Laravel route
                $proxyPath = $baseDir . '/' . $trim;
                $new[] = url("/api/hls/" . $proxyPath);
            } else {
                $new[] = $line;
            }
        }

        return response(implode("\n", $new), 200)
            ->header('Content-Type', 'application/vnd.apple.mpegurl');
    }
}

/* *********
 hls viewer

<video id="player" controls width="800"></video>

<script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>
<script>
var video = document.getElementById('player');
var hls = new Hls();

hls.loadSource("http://localhost:8000/api/hls/Movies/Another.2013/master.m3u8");
hls.attachMedia(video);
hls.on(Hls.Events.MANIFEST_PARSED, () => video.play());
</script>
*/
