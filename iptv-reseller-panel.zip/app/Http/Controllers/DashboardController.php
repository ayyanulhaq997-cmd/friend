<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Subscription;
use App\Models\Device;
use App\Models\CreditTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;
use App\Models\Menu;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $data = [];
        $user =  Auth::user();
        if ($user->role ==  'admin') {
            $total_users = User::where('role', 'user')->count();
            $total_resellers = User::where('role', 'reseller')->count();
            $total_subresellers = User::where('role', 'subreseller')->count();
            $expire_soon_count = User::where('role', 'user')->get()
                ->filter(function ($user) {
                    return $user->latest_subscription_end_date &&
                        $user->latest_subscription_end_date->between(
                            now(),
                            now()->addDays(10)
                        );
                })
                ->count();
            $activate_users =  Subscription::where('status', 1)
                ->where('end_date', '>', now())
                ->groupBy('user_id')
                ->count();
            $expired_users =  Subscription::where('end_date', '<', now())
                ->groupBy('user_id')
                ->count();
            $trial_users = Subscription::where('status', 1)
                ->whereRaw("DATE_ADD(start_date, INTERVAL 2 DAY) <= NOW()")
                ->whereRaw("DATE_ADD(end_date, INTERVAL -2 DAY) = start_date")
                ->groupBy('user_id')
                ->count();


            $data['users'] = $total_users;
            $data['resellers'] = $total_resellers;
            $data['subresellers'] = $total_subresellers;
            $data['expire_soon_count'] = $expire_soon_count;
            $data['activate_users'] = $activate_users;
            $data['expired_users'] = $expired_users;
            $data['trial_users'] = $trial_users;
            return Inertia::render('DashboardAdmin', ['data' => $data]);
        } else {
            $total_users = User::where('role', 'user')->where('parent_id', $user->user_id)->count();
            $expire_soon_count = User::where('role', 'user')->where('parent_id', $user->user_id)->get()
                ->filter(function ($user) {
                    return $user->latest_subscription_end_date &&
                        $user->latest_subscription_end_date->between(
                            now(),
                            now()->addDays(10)
                        );
                })
                ->count();
            $activate_users =  Subscription::where('subscription.status', 1)
                ->join('user', 'user.user_id', 'subscription.user_id')
                ->where('subscription.end_date', '>', now())
                ->where('parent_id', $user->user_id)
                ->groupBy('user.user_id')
                ->count();
            $expired_users =  Subscription::where('subscription.end_date', '<', now())
                ->join('user', 'user.user_id', 'subscription.user_id')
                ->where('parent_id', $user->user_id)
                ->groupBy('user.user_id')
                ->count();
            $trial_users = Subscription::where('subscription.status', 1)
                ->join('user', 'user.user_id', 'subscription.user_id')
                ->whereRaw("DATE_ADD(subscription.start_date, INTERVAL 2 DAY) <= NOW()")
                ->whereRaw("DATE_ADD(subscription.end_date, INTERVAL -2 DAY) = subscription.start_date")
                ->groupBy('user.user_id')
                ->count();


            $data['users'] = $total_users;
            $data['expire_soon_count'] = $expire_soon_count;
            $data['activate_users'] = $activate_users;
            $data['expired_users'] = $expired_users;
            $data['trial_users'] = $trial_users;
            return Inertia::render('Dashboard', ['data' => $data]);
        }
    }


    public function  getMenuData(Request $request)
    {
        $user =  Auth::user();
        $menus =  Menu::with(['items' => function ($query) {
            $query->orderBy('order', 'asc'); // order items by their 'order' column
        }])
            ->whereNull('parent_id');
        if ($user->role == 'reseller' && $user->is_manager == 1)
            $menus = $menus->whereIn('id', [1, 5, 8]);
        else if ($user->role == 'reseller' && $user->is_manager == 0)
            $menus = $menus->whereIn('id', [1, 8]);
        else if ($user->role == 'subreseller')
            $menus = $menus->whereIn('id', [1, 8]);
        $menus = $menus->orderBy('order', 'asc')
            ->get();
        if ($menus) return response()->json(['success' => true, 'data' => $menus]);
        else return response()->json(['success' => false, 'data' => []]);
    }
}
