<?php

namespace App\Http\Controllers;
use Illuminate\Auth\Events\Registered;
use App\Models\User;
use App\Models\Credits;
use App\Models\TransactionReseller;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Hash;
use DateTime;

class SubresellersController extends Controller
{
    /**
     * customer list
     */
    public function index(Request $request): Response
    {
        $user = Auth::user();   // returns the User model
        $user_id = $user->user_id;
        if($user->role == 'reseller') $users = User::where('parent_id', $user_id)->where('role','subreseller')->get();
        else if($user->role == 'admin'){
            $users = User::where('role','subreseller')->get();
        }
        return Inertia::render('Subresellers/Index', ['users' => $users]);
    }

    public function create(Request $request): Response
    {

        return Inertia::render('Subresellers/Create');
    }

    public function store(Request $request)
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();   // returns the User model
        $user_id = $user->user_id;

        
        $request->validate([
            'name' => 'nullable|string|max:255',
            'username' => 'required|string|max:255|unique:user,username',
            'email' => 'nullable|string|lowercase|email|max:255|unique:user,email',
            'password' => 'required|string|min:8',           
            'phone' => 'nullable|string|max:20',
            'active' => 'boolean',
        ]);        

        if($user->role != 'admin' && $user->credit < $request->credit) {
            return response()->json([
                'success' => false,
                'message' => 'Insufficient credits to create customer with the selected subscription duration.'
            ]);
        }
        
        $newSubreseller = new User();
        $newSubreseller->name = $request->name ?? '';      
        $newSubreseller->username = $request->username;      
        $newSubreseller->email = $request->email ?? '';     
        $newSubreseller->slug = "";      
        $newSubreseller->password = Hash::make($request->password);      
        $newSubreseller->phone = $request->phone;    
        $newSubreseller->parent_id = $user_id;      
        $newSubreseller->role = "subreseller";      
        $newSubreseller->status = intval($request->active); 
        $newSubreseller->save();     

        $credit = new Credits();
        $credit->sender_id = $user_id;
        $credit->receiver_id = $newSubreseller->user_id;    
        $credit->amount = $request->credit;
        $credit->date = new DateTime();     
        $credit->save();

        $credit_tmp = new Credits();
        $credit_tmp->sender_id = $newSubreseller->user_id;
        $credit_tmp->receiver_id = $user_id;    
        $credit_tmp->amount = $request->credit * -1;  
        $credit_tmp->date = new DateTime();
        $credit_tmp->save();
        event(new Registered($newSubreseller));
        return response()->json([
            'success' => true,
            'message' => 'Subreseller created successfully.',
            'user' => $newSubreseller,
        ]);
    }

    public function edit(Request $request, $id = null): Response
    {
        $user = User::find($id);
        $credits = Credits::where('receiver_id', $id)->orderBy('date','desc')->get();
        return Inertia::render('Subresellers/Edit', ['user' => $user, 'credits' => $credits]);
    }


    public function update(Request $request, $id = null)
    {
        /** @var \App\Models\User $reseller */
        $reseller = Auth::user();   // returns the User model
        $subreseller = User::find($id);
        $validator = Validator::make($request->all(), [
            'name' => 'nullable|string|max:255',
            'username' => 'required|string|max:255',
            'email' => 'nullable|string|lowercase|email|max:255',
            'phone' => 'nullable|string|max:20',
            'active' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }
        $subreseller->name = $request->name ?? '';
        $subreseller->username = $request->username;
        $subreseller->email = $request->email ?? '';
        $subreseller->phone = $request->phone;
        $subreseller->status = $request->status;
        $subreseller->save();
        return response()->json([
            'success' => true,
            'message' => 'Customer Updated successfully.',
            'user' => $subreseller,
        ]);
    }

    public function delete(Request $request, $id = null)
    {

        $user = User::find($id);
        if($user == null) return response()->json(['success'=>false,'message'=>'Subreseller not found']);
        try {

            $user->delete();
            return response()->json([
                'success' => true,
                'message' => 'Subreseller deleted successfully'
            ]);
            // process $user
        } catch (ModelNotFoundException $e) {
            // handle error
            return redirect()->route('subresellers.index')
                ->with('error', 'Subreseller not found.');
        }
    }

    public  function addCredit(Request $request){
        $user = Auth::user();
        $user_id = $user->user_id;
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|numeric|numeric',
            'credit' => 'required|numeric|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        if($user->role != 'admin' &&  $user->credit < $request->credit) {
            return response()->json([
                'success' => false,
                'message' => 'Insufficient credits to create customer with the selected subscription duration.'
            ]);
        }

        $subreseller = User::find($request->user_id);
        if($subreseller == null) return response()->json(['success'=>false,'message'=>'Subreseller not found']);
        
        $credit = new Credits();
        $credit->sender_id = $user_id;
        $credit->receiver_id = $subreseller->user_id;    
        $credit->amount = $request->credit;
        $credit->date = new DateTime();     
        $credit->save();

        $credit_tmp = new Credits();
        $credit_tmp->sender_id = $subreseller->user_id;
        $credit_tmp->receiver_id = $user_id;    
        $credit_tmp->amount = $request->credit * -1;  
        $credit_tmp->date = new DateTime();
        $credit_tmp->save();        

        return response()->json(['success' => true,'message' => 'Credit added successfully']);

    }
}
