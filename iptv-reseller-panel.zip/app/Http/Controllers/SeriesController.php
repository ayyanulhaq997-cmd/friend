<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\Episode;
use App\Models\User;
use App\Models\VideoFile;
use App\Models\Series;
use App\Models\Video;
use App\Models\Star;
use App\Models\Genre;
use App\Models\Country;
use App\Models\Season;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use DateTime;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Laravel\SerializableClosure\Serializers\Native;

class SeriesController extends Controller
{
    /**
     * customer list
     */
    public function index(Request $request): Response
    {

        $page = $request->page;
        $series = Series::orderBy('created_at', 'DESC')
            ->paginate(10, ['*'], 'page', $page);
        foreach($series as $item){
            $item_country_str = "";
            if($item->country != ""){
                $countries = explode(",",$item->country);
                foreach($countries as $index => $county){
                    $str_iso = "";
                    if($county ==  68 && $county ==  3) $str_iso = "usa";
                    else if($county ==  70) $str_iso = "eng";
                    else if($county ==  5) $str_iso = "ja";
                    else if($county ==  24) $str_iso = "esp";

                    if($index != 0) $item_country_str .= ",";
                    else $item_country_str .=$str_iso;
                }
            }
            $item->country = $item_country_str;
            $item_country_str = "";
        }
        return Inertia::render('Series/Index', ['series' => $series]);
    }

    public function search(Request $request)
    {
        $page = $request->page;
        $search = $request->search;
        $data = Series::where('title', 'LIKE', '%' . $search . '%')
            ->orderBy('id', 'DESC')
            ->paginate(10, ['*'], 'page', $page);
            $series = Series::orderBy('created_at', 'DESC')
            ->paginate(10, ['*'], 'page', $page);
        foreach($data as $item){
            $item_country_str = "";
            // if($item->country != ""){
            //     $countries = explode(",",$item->country);
            //     foreach($countries as $index => $county){
            //         $str_iso = "";
            //         if($county ==  68 && $county ==  3) $str_iso = "usa";
            //         else if($county ==  70) $str_iso = "eng";
            //         else if($county ==  5) $str_iso = "ja";
            //         else if($county ==  24) $str_iso = "esp";

            //         if($index != 0) $item_country_str .= ",";
            //         else $item_country_str .=$str_iso;
            //     }
            // }
            //$item->country = $item_country_str;
            $item->country = "";
            $item_country_str = "";
        }
        return response()->json(['data' => $data]);
    }
    public function season($id = null)
    {
        if ($id == null) return;
        $series = Series::with(['seasons'])->find($id);        
        return Inertia::render('Series/Season', ['series' => $series]);
    }

    public function episod($id = null)
    {
        if ($id == null) return;
        $seasons = Season::with([
            'episodes' => function ($q) {
                $q->orderBy('episode_number', 'asc');
            }
        ])->find($id);


        return Inertia::render('Series/Episod', ['seasons' => $seasons]);
    }

    public function episodDetail(Request $request)
    {
        $episode_id = $request->id;
        $episod = Episode::find($episode_id);
        if (!$episod)  return response()->json(['success' => false, 'messege' => 'Not Found Episod']);
        return response()->json(['success' => true, 'data' => $episod]);
    }

    public function suncSeriesByTmdb(Request $request)
    {
        
        $sync_data =  DB::table('processed_s_files')
            ->whereIn('status', ['synced', 'invalid_season'])
            ->orderBy('id')
            ->limit(200)
            ->get();
        foreach ($sync_data as $item) {
            if (!$item->series_tmdb) continue;
            $tmdb_data = Series::with(['seasons.episodes'])
                ->where('tmdb_id', $item->series_tmdb)
                ->first();
            if (!$tmdb_data)
                $tmdb_data = importTmdbData($item->series_tmdb, 'tv');
            $newEpisode = new Episode();
            $newEpisode->source_type = 'mp4';
            $newEpisode->series_id = $tmdb_data->id;
            $newEpisode->video_url = $item->path;
            $newEpisode->track = $item->track;
            // ===============================
            // CASE: SEASONLESS (flag_season = 2)
            // ===============================
            if ($item->status == 'synced' && $item->flag_season == 2) {
                // Use first season (Season 1)
                $season = $tmdb_data->seasons->first();
                $newEpisode->season_id = $season->id;
                $newEpisode->episode_number = $item->episode_number;
                $newEpisode->title = "1-" . $item->episode_number;
            }
            // ===============================
            // CASE: TMDB HAS THIS SEASON (flag_season = 0)
            // ===============================
            else if ($item->status == 'synced' && $item->flag_season == 0) {
                $season = Season::where('tmdb_id', $item->season_tmdb)
                    ->where('series_id', $tmdb_data->id)
                    ->first();
                if ($season) {
                    $newEpisode->season_id = $season->id;
                    $newEpisode->episode_number = $item->episode_number;
                    $newEpisode->title = $season->season_number . "-" . $item->episode_number;
                }
            }
            // ===============================
            // CASE: LOCAL SEASON EXISTS BUT TMDB DOES NOT HAVE SEASON (flag_season = 1)
            // Create fallback season
            // ===============================
            else if ($item->status == 'synced' && $item->flag_season == 1) {
                $season = Season::where('series_id', $tmdb_data->id)
                    ->where('season_number', $item->season_number)
                    ->first();

                if (!$season) {
                    $season = new Season();
                    $season->series_id = $tmdb_data->id;
                    $season->tmdb_id = $item->season_tmdb; // NULL but OK
                    $season->season_number = $item->season_number;
                    $season->save();
                }

                $newEpisode->season_id = $season->id;
                $newEpisode->episode_number = $item->episode_number;
                $newEpisode->title = $season->season_number . "-" . $item->episode_number;
            }

            // ===============================
            // CASE: invalid_season (fallback)
            // ===============================
            else if ($item->status == 'invalid_season') {

                if ($item->season_number) {
                    $season = Season::where('season_number', $item->season_number)
                        ->where('series_id', $tmdb_data->id)
                        ->first();
                }
                // fallback: first available season
                if (empty($season)) {
                    $season = Season::where('series_id', $tmdb_data->id)->first();
                }
                // if still empty, create season 1
                if (!$season) {
                    $season = new Season();
                    $season->series_id = $tmdb_data->id;
                    $season->season_number = 1;
                    $season->tmdb_id = null;
                    $season->save();

                }
                $newEpisode->season_id = $season->id;
                $newEpisode->episode_number = $item->episode_number;
                $newEpisode->title = $season->season_number . "-" . $item->episode_number;
            }

            $newEpisode->save();

            DB::table('processed_s_files')->where('id', $item->id)->update(['status' => 'matched']);
        }
        return response()->json([
            'success' => true,
            'message' => 'Series Sync successfully.',
        ]);
    }
}
