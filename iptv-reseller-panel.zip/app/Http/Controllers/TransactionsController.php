<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\User;
use App\Models\Credits;
use GuzzleHttp\Promise\Create;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TransactionsController extends Controller
{
    /**
     * customer list
     */
    public function index(Request $request): Response
    {

        $user = Auth::user();
        $user_id = $user->user_id;
        $page = $request->page;
        $search = $request->search;
        $transactions = DB::table('credits')
            ->join('user as sender', 'sender.user_id', '=', 'credits.sender_id')
            ->select(
                'credit_id',
                'sender.username as user_name',
                'credits.amount',
                'credits.date',
                DB::raw("'received' as type")
            )
            ->where('credits.receiver_id', $user_id)
            ->where('credits.amount', '>', 0)
            ->where('credits.date', 'LIKE', '%'.$search.'%')
            ->unionAll(
                DB::table('credits')
                    ->join('user as receiver', 'receiver.user_id', '=', 'credits.receiver_id')
                    ->select(
                        'credit_id',
                        'receiver.username as user_name',
                        'credits.amount',
                        'credits.date',
                        DB::raw("'sent' as type")
                    )
                    ->where('credits.sender_id', $user_id)
                    ->where('credits.amount', '>', 0)
                    ->where('credits.date', 'LIKE', '%'.$search.'%')
            );

        $transactions = DB::query()
            ->fromSub($transactions, 't')
            ->orderByDesc('date')
            ->paginate(10, ['*'], 'page', $page);
       
        $balance = Credits::where('receiver_id', $user_id)->where('amount','>',0)->sum('amount') - Credits::where('sender_id', $user_id)->where('amount','>',0)->sum('amount');
        $received_total = Credits::where('receiver_id', $user_id)->where('amount','>',0)->sum('amount');
        $sent_total = Credits::where('sender_id', $user_id)->where('amount','>',0)->sum('amount');
        return Inertia::render('Transactions/Index',
         ['transaction_list' => $transactions, 
                'balance' => $balance,
                'received_total'=>$received_total,
                'sent_total'=>$sent_total]);
    }

    public function search(Request $request)
    {

        $user = Auth::user();
        $user_id = $user->user_id;
        $page = $request->page;
        $search = $request->search;
        $transactions = DB::table('credits')
            ->join('user as sender', 'sender.user_id', '=', 'credits.sender_id')
            ->select(
                'credit_id',
                'sender.name as user_name',
                'credits.amount',
                'credits.date',
                DB::raw("'received' as type")
            )
            ->where('credits.receiver_id', $user_id)
            ->where('credits.amount', '>', 0)
            ->where('credits.date', 'LIKE', '%'.$search.'%')

            ->unionAll(
                DB::table('credits')
                    ->join('user as receiver', 'receiver.user_id', '=', 'credits.receiver_id')
                    ->select(
                        'credit_id',
                        'receiver.name as user_name',
                        'credits.amount',
                        'credits.date',
                        DB::raw("'sent' as type")
                    )
                    ->where('credits.sender_id', $user_id)
                    ->where('credits.amount', '>', 0)
                    ->where('credits.date', 'LIKE', '%'.$search.'%')
            );

        $transactions = DB::query()
            ->fromSub($transactions, 't')
            ->orderByDesc('date')
            ->paginate(10, ['*'], 'page', $page);
        
        return response()->json(['transaction_list' => $transactions]);
    }
}
