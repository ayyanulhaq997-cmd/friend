<?php

namespace App\Http\Controllers;
use Illuminate\Auth\Events\Registered;
use App\Models\User;
use App\Models\Credits;
use App\Models\TransactionReseller;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Hash;
use DateTime;

class ResellersController extends Controller
{
    /**
     * customer list
     */
    public function index(Request $request): Response
    {
        $user = Auth::user();   // returns the User model
        $user_id = $user->user_id;
        $users = User::where('parent_id', $user_id)->where('role','reseller')->get();
        return Inertia::render('Resellers/Index', ['users' => $users]);
    }

    public function create(Request $request): Response
    {

        return Inertia::render('Resellers/Create');
    }

    public function store(Request $request)
    {
        /** @var \App\Models\User $user */
        $user = Auth::user();   // returns the User model
        $user_id = $user->user_id;       
        $validator = Validator::make($request->all(), [
            'name' => 'nullable|string|max:255',
            'username' => 'required|string|max:255|unique:user,username',
            'email' => 'nullable|string|lowercase|email|max:255|unique:user,email',
            'password' => 'required|string|min:8',
            'phone' => 'nullable|string|max:20',
            'credit' => 'required|integer',
            'status' => 'bool',            
        ], [            
            'password.min' => 'Password should be over 8 characters.',
            'username.unique' => 'This username is already taken.']);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }            
        
        $newReseller = new User();
        $newReseller->name = $request->name ?? '';      
        $newReseller->username = $request->username;      
        $newReseller->email = $request->email ?? '';     
        $newReseller->slug = "";      
        $newReseller->password = Hash::make($request->password);      
        $newReseller->phone = $request->phone;    
        $newReseller->parent_id = $user_id;      
        $newReseller->role = "reseller";      
        $newReseller->status = intval($request->active); 
        $newReseller->save();     

        $credit = new Credits();
        $credit->sender_id = $user_id;
        $credit->receiver_id = $newReseller->user_id;    
        $credit->amount = $request->credit;
        $credit->date = new DateTime();     
        $credit->save();

        $credit_tmp = new Credits();
        $credit_tmp->sender_id = $newReseller->user_id;
        $credit_tmp->receiver_id = $user_id;    
        $credit_tmp->amount = $request->credit * -1;  
        $credit_tmp->date = new DateTime();
        $credit_tmp->save();
        event(new Registered($newReseller));
        return response()->json([
            'success' => true,
            'message' => 'Reseller created successfully.',
            'user' => $newReseller,
        ]);
    }

    public function edit(Request $request, $id = null): Response
    {
        $user = User::find($id);
        $credits = Credits::where('receiver_id', $id)->orderBy('date','desc')->get();
        return Inertia::render('Resellers/Edit', ['user' => $user, 'credits' => $credits]);
    }


    public function update(Request $request, $id = null)
    {
        /** @var \App\Models\User $reseller */
        $reseller = Auth::user();   // returns the User model
        $subreseller = User::find($id);
        $validator = Validator::make($request->all(), [
            'name' => 'nullable|string|max:255',
            'username' => 'required|string|max:255',
            'email' => 'nullable|string|lowercase|email|max:255',
            'phone' => 'nullable|string|max:20',
            'active' => 'boolean',
            'is_manager' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }
        $subreseller->name = $request->name ?? '';
        $subreseller->username = $request->username;
        $subreseller->email = $request->email ?? '';
        $subreseller->phone = $request->phone;
        $subreseller->status = $request->status;        
        $subreseller->is_manager = intval($request->is_manager); 
        $subreseller->save();
        return response()->json([
            'success' => true,
            'message' => 'Customer Updated successfully.',
            'user' => $subreseller,
        ]);
    }

    public function delete(Request $request, $id = null)
    {

        $user = User::find($id);
        if($user == null) return response()->json(['success'=>false,'message'=>'Reseller not found']);
        try {

            $user->delete();
            return response()->json([
                'success' => true,
                'message' => 'Reseller deleted successfully'
            ]);
            // process $user
        } catch (ModelNotFoundException $e) {
            // handle error
            return redirect()->route('resellers.index')
                ->with('error', 'Reseller not found.');
        }
    }

    public  function addCredit(Request $request){
        $user = Auth::user();
        $user_id = $user->user_id;
        $validator = Validator::make($request->all(), [
            'user_id' => 'required|numeric|numeric',
            'credit' => 'required|numeric|numeric',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

       

        $subreseller = User::find($request->user_id);
        if($subreseller == null) return response()->json(['success'=>false,'message'=>'Reseller not found']);
        
        $credit = new Credits();
        $credit->sender_id = $user_id;
        $credit->receiver_id = $subreseller->user_id;    
        $credit->amount = $request->credit;
        $credit->date = new DateTime();     
        $credit->save();

        $credit_tmp = new Credits();
        $credit_tmp->sender_id = $subreseller->user_id;
        $credit_tmp->receiver_id = $user_id;    
        $credit_tmp->amount = $request->credit * -1;  
        $credit_tmp->date = new DateTime();
        $credit_tmp->save();        

        return response()->json(['success' => true,'message' => 'Credit added successfully']);

    }
}
