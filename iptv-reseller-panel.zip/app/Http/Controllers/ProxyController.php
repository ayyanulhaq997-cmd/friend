<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Aws\S3\S3Client;
use Aws\Exception\AwsException;
use Illuminate\Support\Facades\Storage;
use Illuminate\Filesystem\FilesystemAdapter;
use Illuminate\Support\Carbon;
use Exception;

class ProxyController extends Controller
{
    protected $s3;

    public function __construct()
    {
        $this->s3 = new S3Client([
            'version'     => 'latest',
            'region'      => 'us-west-1', // Sharktech region
            'endpoint'    => 'https://s3.lax.sharktech.net',
            'use_path_style_endpoint' => true,
            'credentials' => [
                'key'    => env('S3_KEY', 'd3e4ff6dd49c9e6d0LZV'),
                'secret' => env('S3_SECRET', 'B9ISoUt72sfAsbAI3Don1yqYPUEnNdkNhAHc2lc'),
            ],
        ]);
    }

    /**
     * Fetch master.m3u8 and rewrite URLs with presigned links
     */
    function fetchM3u8(Request $request, $res = null, $headers = [])
    {
        $targetUrl  = $request->url;
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $targetUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);


            // Set headers
            if (!empty($headers)) {
                $curlHeaders = [];
                foreach ($headers as $key => $value) {
                    $curlHeaders[] = "$key: $value";
                }
                curl_setopt($ch, CURLOPT_HTTPHEADER, $curlHeaders);
            }

            $body = curl_exec($ch);

            $err = curl_error($ch);
            curl_close($ch);

            if ($err) {
                error_log("Request error: $err");
                http_response_code(500);
                echo json_encode(['error' => 'Failed to fetch m3u8 file']);
                return;
            }

            // Rewrite URLs
            $proxyBaseUrl = '/proxy/';
            $headers = [];
            $rewrittenBody = $this->rewriteUrls($body, $proxyBaseUrl, $headers, $targetUrl);

            // Handle nested channel?url= links
            if (strpos($rewrittenBody, 'channel?url=') !== false) {
                if (preg_match('/channel\?url=([^&\s]+)/', $rewrittenBody, $matches)) {
                    $channelUrl = urldecode($matches[1]);
                    $this->fetchM3u8($res, $channelUrl, $headers);
                    return;
                }
            }

            // Add EXT-X-DISCONTINUITY before EXTINF
            $updatedM3u8 = preg_replace('/(#EXTINF.*)/', "#EXT-X-DISCONTINUITY\n$1", $rewrittenBody);

            header('Content-Type: application/vnd.apple.mpegurl');
            return $updatedM3u8;
        } catch (\Exception $e) {
            error_log('Failed to proxy request: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'Proxy request failed']);
        }
    }

    /**
     * Rewrite URLs inside the m3u8 content
     * Example: replace absolute URLs with proxy URLs
     */
    function rewriteUrls($body, $proxyBaseUrl)
    {
        // Simple example: prepend proxyBaseUrl to all URLs
        $lines = explode("\n", $body);
        foreach ($lines as &$line) {
            if (strpos($line, 'http') === 0) {
                $line = $proxyBaseUrl . '?url=' . urlencode($line);
            }
        }
        return implode("\n", $lines);
    }

    function segment(Request $request)
    {

        // --- Validate input ---
        $url = $request->url;

        if (empty($url)) {
            http_response_code(400);
            echo json_encode(['error' => 'Missing url query parameter']);
            return;
        }

        error_log("Proxy request to: " . $url);

        // --- Allow CORS ---
        header("Access-Control-Allow-Origin: *");

        // --- Default headers to simulate a browser ---
        $defaultHeaders = [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' .
                'AppleWebKit/537.36 (KHTML, like Gecko) ' .
                'Chrome/120.0.0.0 Safari/537.36',
            'Accept: */*',
            'Accept-Language: en-US,en;q=0.9',
            'Referer: https://drive.google.com/',
            'Connection: keep-alive',
        ];

        // --- Initialize cURL ---
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_HTTPHEADER => $defaultHeaders,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true, // follow redirects
            CURLOPT_HEADER => true,          // return headers + body
            CURLOPT_SSL_VERIFYPEER => false, // disable SSL check (for dev)
            CURLOPT_SSL_VERIFYHOST => false,
        ]);

        $response = curl_exec($ch);

        // --- Handle cURL error ---
        if ($response === false) {
            $error = curl_error($ch);
            curl_close($ch);
            error_log("Proxy request error: " . $error);
            http_response_code(502);
            echo json_encode(['error' => 'Upstream request failed']);
            return;
        }

        // --- Extract headers and body ---
        $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $headers = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);

        $contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        $contentLength = curl_getinfo($ch, CURLINFO_SIZE_DOWNLOAD);

        curl_close($ch);

        // --- Forward important headers ---
        if ($contentType) header("Content-Type: $contentType");
        if ($contentLength) header("Content-Length: $contentLength");

        // --- Stream binary content ---
        echo $body;
    }


    /**
     * Generate a signed URL for the master.m3u8 of a video
     */
    public function signedUrl($filename)
    {
        $bucket = 'data';
        $key = "{$filename}/master.m3u8";

        try {
            $cmd = $this->s3->getCommand('GetObject', [
                'Bucket' => $bucket,
                'Key'    => $key,
            ]);

            $request = $this->s3->createPresignedRequest($cmd, '+24 hours');
            $signedUrl = (string) $request->getUri();

            $targetUrl  = $signedUrl;
            try {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $targetUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);


                // Set headers
                if (!empty($headers)) {
                    $curlHeaders = [];
                    foreach ($headers as $key => $value) {
                        $curlHeaders[] = "$key: $value";
                    }
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $curlHeaders);
                }

                $body = curl_exec($ch);

                $err = curl_error($ch);
                curl_close($ch);

                // 2️⃣ Split into lines
                $lines = preg_split("/\r\n|\n|\r/", $body);
                $new_lines = [];

                foreach ($lines as $line) {
                    $line = trim($line);
                    if (preg_match('/\d+\.ts$/', $line)) {
                        // 3️⃣ Generate signed URL for each segment
                        $key = "$filename/$line";
                        $cmd = $this->s3->getCommand('GetObject', [
                            'Bucket' => $bucket,
                            'Key' => $key,
                        ]);
                        $request = $this->s3->createPresignedRequest($cmd, '+24 hours');
                        $signedUrl = (string) $request->getUri();

                        $new_lines[] = $signedUrl;
                    } else {
                        $new_lines[] = $line;
                    }
                }

                // 4️⃣ Join back with proper newlines
                $playlist = implode("\n", $new_lines);

                // 5️⃣ Serve it as proper HLS content
                header('Content-Type: application/vnd.apple.mpegurl');

                return $playlist;
            } catch (\Exception $e) {
                error_log('Failed to proxy request: ' . $e->getMessage());
                http_response_code(500);
                echo json_encode(['error' => 'Proxy request failed']);
            }

            return response()->json([
                'url' => $signedUrl,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Video not found or S3 error',
                'message' => $e->getMessage(),
            ], 404);
        }
    }

    public function signedSegmentUrl($filename, $segment = "000.ts")
    {
        $bucket = 'data';
        $key = "{$filename}/{$segment}";

        try {
            $cmd = $this->s3->getCommand('GetObject', [
                'Bucket' => $bucket,
                'Key'    => $key,
            ]);

            $request = $this->s3->createPresignedRequest($cmd, '+24 hours');
            $signedUrl = (string) $request->getUri();

            return response()->json([
                'url' => $signedUrl,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Video not found or S3 error',
                'message' => $e->getMessage(),
            ], 404);
        }
    }

    public function signedMasterPlaylist(Request $request)
    {
        $bucket = 'data';
        $masterKey = $request->filePath;
        $path = dirname($masterKey);
        try {
            //Get the master.m3u8 content
            $result = $this->s3->getObject([
                'Bucket' => $bucket,
                'Key' => $masterKey,
            ]);

            $body = (string) $result['Body'];
            $lines = preg_split("/\r\n|\n|\r/", $body);
            $new_lines = [];
            foreach ($lines as $line) {
                $line = trim($line);
                if (preg_match('/\d+\.ts$/', $line)) {
                    //Generate signed URL for segment                    
                    $key = "$path/$line";
                    $cmd = $this->s3->getCommand('GetObject', [
                        'Bucket' => $bucket,
                        'Key' => $key,
                    ]);
                    $request = $this->s3->createPresignedRequest($cmd, '+24 hours');
                    $signedUrl = (string) $request->getUri();
                    $new_lines[] = $signedUrl;
                } else if (preg_match('/\s*index\.m3u8$/', $line)) {
                    $path_sub = dirname($line);
                    $master_sub = "$path/$line";
                    $result_sub = $this->s3->getObject([
                        'Bucket' => $bucket,
                        'Key' => $master_sub,
                    ]);
                    $body_sub = (string) $result_sub['Body'];
                    $lines_sub = preg_split("/\r\n|\n|\r/", $body_sub);
                    foreach ($lines_sub as $line_sub) {
                        $line_sub = trim($line_sub);
                        if (preg_match('/\d+\.ts$/', $line_sub)) {
                            $key_sub = "$path/$path_sub/$line_sub";
                            $cmd_sub = $this->s3->getCommand('GetObject', [
                                'Bucket' => $bucket,
                                'Key' => $key_sub,
                            ]);
                            $request_sub = $this->s3->createPresignedRequest($cmd_sub, '+24 hours');
                            $signedUrl_sub = (string) $request_sub->getUri();
                            $new_lines[] = $signedUrl_sub;
                        }
                        else{
                            $new_lines[] = $line_sub;
                        }
                    }

                    break;
                } else {
                    $new_lines[] = $line;
                }
            }

            $playlist = implode("\n", $new_lines);
            //dd($playlist);
            return response($playlist, 200)
                ->header('Content-Type', 'application/vnd.apple.mpegurl');
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Video not found or S3 error',
                'message' => $e->getMessage(),
            ], 404);
        }
    }
    /**
     * Generate a signed master.m3u8 with all segments signed.
     */
    public function signedMaster($filename)
    {
        $bucket = 'data';
        $key = "{$filename}/master.m3u8";

        try {
            // Get master.m3u8 content
            $object = $this->s3->getObject([
                'Bucket' => $bucket,
                'Key'    => $key,
            ]);

            $content = (string) $object['Body'];

            // Replace all .ts lines with signed URLs
            $lines = explode("\n", $content);
            foreach ($lines as &$line) {
                $line = trim($line);
                if ($line === '' || str_starts_with($line, '#')) {
                    continue;
                }
                // Assume line is a segment like 000.ts
                $segmentKey = "{$filename}/{$line}";
                $cmd = $this->s3->getCommand('GetObject', [
                    'Bucket' => $bucket,
                    'Key'    => $segmentKey,
                ]);
                $request = $this->s3->createPresignedRequest($cmd, '+24 hours');
                $line = (string) $request->getUri();
            }

            $signedMasterContent = implode("\n", $lines);

            return response($signedMasterContent, 200)
                ->header('Content-Type', 'application/vnd.apple.mpegurl');
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Video not found or S3 error',
                'message' => $e->getMessage(),
            ], 404);
        }
    }

    public static function getSignedMp4Url(Request $request)
    {
        $filePath =  $request->input('filePath', null);
        $expiresInMinutes =  $request->input('expiresInMinutes', 120);
        if ($filePath ==  null)
            return response()->json([
                'success' => false,
                'message' => 'Movie get error.',
            ]);        
        $url =  getSignedMp4UrlFromS3($filePath,$expiresInMinutes);
        return response()->json([
            'success' => true,
            'message' => 'Movie deleted successfully.',
            'url' => $url
        ]);
    }

    /**
     * Build a file path dynamically from parts.
     *
     * @param array $parts Array of path segments, e.g., ['BUNNYG','M','1940','file.mp4']
     * @return string
     */
    public static function buildPath(array $parts): string
    {
        return implode('/', $parts);
    }
}
