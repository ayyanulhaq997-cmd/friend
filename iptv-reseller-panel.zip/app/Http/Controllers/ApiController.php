<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\User;
use App\Models\VideoFile;
use App\Models\Video;
use App\Models\Star;
use App\Models\Genre;
use App\Models\Country;
use App\Models\Episode;
use App\Models\FavoriteMovie;
use App\Models\FavoriteTv;
use App\Models\LiveTv;
use App\Models\MovieTrailer;
use App\Models\Series;
use App\Models\Season;
use App\Models\MovieViewLog;
use App\Models\Oscar;
use App\Models\Popular;
use App\Models\Saga;
use App\Models\TopRates;
use App\Models\TvViewLog;
use Illuminate\Support\Carbon;
use AWS\CRT\Log as CRTLog;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use DateTime;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Laravel\SerializableClosure\Serializers\Native;
use Illuminate\Support\Facades\FacadeLog;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Log;
use Ramsey\Uuid\Type\Integer;
use Illuminate\Support\Facades\Cache;

define('TMDB_IMAGE_W342', 'https://image.tmdb.org/t/p/w185/');
define('TMDB_IMAGE_ORIGINAL', 'https://image.tmdb.org/t/p/original/');

class ApiController extends Controller
{
    public function checkMovie(Request $request, $type, $tmdb_id)
    {
        if ($type == 'movie') {
            $data = Video::where('tmdbid', $tmdb_id)->has('file')->count() == 0 ? false : true;
        } else {
            $data = Series::where('tmdb_id', $tmdb_id)->has('seasons')->count() == 0 ? false : true;
        }
        return response()->json(['status_code' => 200, 'exist' => $data]);
    }

    public function checkInfo(Request $request, $name)
    {
        $key = env('TMDB_API_KEY');
        $data = find_media_from_filename($name, $key);
        return response()->json(['status_code' => 200, 'param' => $data]);
    }

    public function checkInfoAll(Request $request)
    {
        $key = env('TMDB_API_KEY');
        $videos = DB::table('processed_files')->where('status', 'sync_faild')->where('id', '<', 1000)->get();
        $count = 0;
        foreach ($videos as $item) {
            $name = basename($item->path);
            $data =  find_media_from_filename($name, $key);
            if ($data != null) {
                DB::table('processed_files')
                    ->where('id', $item->id)
                    ->update(['tmdb_id' => $data['result']['id'], 'status' => 'synced']);
                $count++;
            }
        }
        //$data = find_media_from_filename($name, $key);
        return response()->json(['status_code' => 200, 'count' => $count]);
    }


    public function confirmCount(Request $request)
    {
        $movies = VideoFile::count();
        return response()->json(['status_code' => 200, 'exist' => true]);
    }

    /**
     * @label : coming from upload video file name
     * 
     */
    public function confirmMovie(Request $request, $label = null)
    {
        $movies = VideoFile::where('label', 'like', $label)->get();
        if (count($movies) > 0) return response()->json(['status_code' => 200, 'exist' => true]);
        else return response()->json(['status_code' => 200, 'exist' => false]);
    }

    /**
     * Create video file after upload the movie
     * @param \Illuminate\Http\Request $request
     * title : movie file title is folder name include master.m3u8 file(M) or master.m3u file(S) 
     * @return \Illuminate\Http\JsonResponse
     */
    public function createMovie(Request $request)
    {
        $tmdb_id = $request->input('tmdb_id');
        $title = $request->input('title');
        $file_path = $request->input('file_path');
        $audio_tracks = $request->input('audio_tracks');
        $source_type = $request->input('type', 'm3u8');
        $path = 'Movies';

        if ($tmdb_id) {
            $video = Video::where('tmdbid', $tmdb_id)->first();

            if (empty($video)) {
                // create a video from TMDB
                $video = importTmdbData($tmdb_id, 'movie');
            }
            $videos_id = $video->videos_id;

            $movie = VideoFile::where('videos_id', $videos_id)->first();
            if (empty($movie)) $movie = new VideoFile();
            $movie->videos_id = $videos_id;
            $movie->file_source = 'link';
            $movie->source_type = $source_type;
            $movie->file_url = $path . '/' . $file_path;
            $movie->label = $title;
            // todo: audio tracks
            // $movie->audio_tracks = 
            $movie->save();

            return response()->json(['success' => true, 'id' => $movie->video_file_id]);
        } else {
            return response()->json(['success' => false, 'id' => null]);
        }
    }

    public function createSeries(Request $request)
    {
        $tmdb_id = $request->input('tmdb_id');
        $title = $request->input('title');
        $has_season = $request->input('has_season');
        $audio_tracks = $request->input('audio_tracks');
        $series_path = $request->input('series_path');
        $seasonsByEpisodes = $request->input('episodes');
        $source_type = $request->input('type', 'm3u8');
        $path = 'Series';

        if ($tmdb_id) {
            $series = Series::where('tmdb_id', $tmdb_id)->first();

            if (empty($series)) {
                // create a series from TMDB
                $series = importTmdbData($tmdb_id, 'tv');
            }
            $series_id = $series->id;

            foreach ($seasonsByEpisodes as $season_number => $episodes) {
                $season = Season::where('series_id', $series_id)->where('season_number', $season_number)->first();
                $season_id = $season->id;
                $has_season = $season->has_season;
                Episode::where('season_id', $season_id)->where('series_id', $series_id)->delete();
                foreach ($episodes as $idx => $ep) {
                    $episode = new Episode();
                    $episode->series_id = $series_id;
                    $episode->season_id = $season_id;
                    $episode->episode_number = $idx + 1;
                    $episode->title = "Episode " . $idx + 1;
                    $episode->source_type = $source_type;
                    // todo: audio tracks
                    // $episode->audio_tracks = 
                    if ($has_season) {
                        $episode->video_url = 'Series/' . $series_path . '/' . $season_number . '/' . $ep;
                    } else {
                        $episode->video_url = 'Series/' . $series_path . '/' . $ep;
                    }
                    $episode->save();
                    Log::info([$series_id, $episode->video_url]);
                }
            }
            return response()->json(['success' => true, 'id' => $series_id]);
        } else {
            return response()->json(['success' => false, 'id' => null]);
        }
    }





    public function  editMovie(Request $request, $id =  null)
    {
        if ($id == null)
            return  response()->json(['success' => false]);
        $data =  Video::find($id);
        if ($data ==  null) return  response()->json(['success' => false]);
        $starts_id = explode(",", $data->stars);
        $stars = "";
        foreach ($starts_id as  $index =>  $item) {
            $star =  Star::find($item);
            if ($index == 0) $stars .= $star->star_name;
            else $stars .= ", " . $star->star_name;
        }
        $data->stars = $stars;
        $directors_id = explode(",", $data->director);
        $directors = "";
        foreach ($directors_id  as  $index =>  $item) {
            $star =  Star::find($item);
            if ($index == 0) $directors .= $star->star_name;
            else $directors .= ", " . $star->star_name;
        }
        $data->director = $directors;

        $writers_id = explode(",", $data->writer);
        $writers = "";
        foreach ($writers_id  as  $index =>  $item) {
            $star =  Star::find($item);
            if ($index == 0) $writers .= $star->star_name;
            else $writers .= ", " . $star->star_name;
        }
        $data->writer = $writers;

        $country_id = explode(",", $data->country);
        $countries = "";
        foreach ($country_id  as  $index =>  $item) {
            $country =  Country::find($item);
            if ($index == 0) $countries .= $country->name;
            else $countries .= ", " . $country->name;
        }
        $data->country = $countries;


        $genre_id = explode(",", $data->genre);
        $genres = "";
        foreach ($genre_id  as  $index =>  $item) {
            $genre =  Genre::find($item);
            if ($index == 0) $genres .= $genre->name;
            else $genres .= ", " . $genre->name;
        }
        $data->genre = $genres;
        return response()->json(['status_code' => 200,  'data' => $data]);
    }

    public function  updateMovie(Request $request)
    {
        $video = Video::find($request->id);
        $video->title = $request->title;
        $video->is_paid = intval($request->is_paid);
        $video->trailler_youtube_source = $request->trailler_youtube_source;
        $video->enable_download = intval($request->enable_download);
        $video->save();
        //dd($request->thumb_file);
        if ($request->thumb_file != "null") {
            $destinationPath = "uploads/video_thumb";
            $fileName = $request->id . ".jpg";
            $request->file('thumb_file')->move($destinationPath, $fileName);
        }
        if ($request->poster_file != "null") {
            $destinationPath = "uploads/poster_image";
            $fileName = $request->id . ".jpg";
            $request->file('poster_file')->move($destinationPath, $fileName);
        }
        return response()->json(['data' => $video, 'success' => true]);
    }


    public function login(Request $request)
    {
        $username =  $request->input('username');
        $password =  $request->input('password');
        $user = User::where('username', $username)->first();


        if ($password == null || $user == null) {
            return response()->json(['status' => false, 'message' => 'User not found.']); //--- IGNORE ---
        }
        if ($password == $user->password) {
            $credit_end_date = Carbon::parse($user->latest_subscription_end_date);
            $current_date = Carbon::now();
            if ($credit_end_date->greaterThanOrEqualTo($current_date) && $user->status == 1) {
                return response()->json(['status' => 'success', 'message' => 'Login successful']);
            } else {
                return response()->json(['status' => 'error', 'message' => 'Your subscription has expired. Please renew to continue accessing our services.']);
            }
        } else {
            return response()->json(['status' => 'error', 'message' => 'Password is incorrect.']);
        }
    }
    //User API

    public function getUserHomeData(Request $request)
    {
        $username =  $request->input('username');
        $password =  $request->input('password');
        $user = User::where('username', $username)->first();
        if ($user && $password == $user->password) {
            $expiryDate = Carbon::parse($user->latest_subscription_end_date);
            $now = Carbon::now();
            $daysLeft = $now->diffInDays($expiryDate, false); // false = return negative if expired
            $date = $user->latest_subscription_end_date
                ? (is_string($user->latest_subscription_end_date)
                    ? date('Y-m-d', strtotime($user->latest_subscription_end_date))
                    : $user->latest_subscription_end_date->format('Y-m-d'))
                : null;
            $str_formatted = strtoupper("expires: " . Carbon::parse($date)->format('j F Y'));
            $str_leftDay = str(round($daysLeft) . " Day(s) to expired credits");
            $popular_images = Popular::select(                
                DB::raw("CONCAT('" . TMDB_IMAGE_ORIGINAL . "', SUBSTRING_INDEX(poster_path, '/', -1)) AS bg_url")
            )->get()->toArray();
            $data = [
                'status' => true,
                'expired_date' => $str_formatted,
                'expired_later' => $str_leftDay,
                'popular_images' => $popular_images,
                'message' => 'Login Successful',
                'movie_trailers' => $this->getMovieTrailer(),
            ];
            return response()->json($data);
        } else if ($user && $password != $user->password) {
            return response()->json(['status' => false, 'message' => 'Password is incorrect.']);
        } else {
            return response()->json(['status' => false, 'message' => 'User not found.']);
        }
    }
    public function getUserSettingData(Request $request)
    {
        $username =  $request->input('username');
        $password =  $request->input('password');
        $user = User::where('username', $username)->first();
        if ($user && $password == $user->password) {
            $expiryDate = Carbon::parse($user->latest_subscription_end_date);
            $now = Carbon::now();
            $daysLeft = $now->diffInDays($expiryDate, false); // false = return negative if expired
            $expired_date = $user->latest_subscription_end_date
                ? (is_string($user->latest_subscription_end_date)
                    ? date('d/m/Y', strtotime($user->latest_subscription_end_date))
                    : $user->latest_subscription_end_date->format('d/m/Y'))
                : null;
            $credits = intval($daysLeft / 30) + 1;
            $data = [
                'status' => true,
                'expired_date' => $expired_date,
                'credits' => $credits,
                'message' => "User",
                'username' => $username
            ];
            return response()->json($data);
        } else if ($user && $password != $user->password) {
            return response()->json(['status' => false, 'message' => 'Password is incorrect.']);
        } else {
            return response()->json(['status' => false, 'message' => 'User not found.']);
        }
    }
    public function changePassword(Request $request)
    {
        $username =  $request->input('username');
        $password =  $request->input('password');
        $old_password = $request->input('old_password');
        $new_password = $request->input('new_password');
        Log::info($old_password);
        $user = User::where('username', $username)->first();
        if ($old_password == $user->password) {
            $user->password =  $new_password;
            $user->save();
            return response()->json(['status' => true, 'message' => 'Password Changed']);
        } else return response()->json(['status' => false, 'message' => 'Old Password Incorrect']);
    }

    //////////////////////////// MOVIE API /////////////////////////////////

    private function getMovieHomeList($userId, $sort = 'created_at', $order = 'DESC')
    {


        $recent = $this->getMovieRecentView($userId);
        $just = $this->getMovieJustAdded($userId);
        $premiere = $this->getMoviePremiere($userId);
        $popular = $this->getMoviePopular($userId, $sort, $order);
        $top_rate = $this->getMovieTopRate($userId, $sort, $order);
        $oscars = $this->getMovieOscar($userId, $sort, $order);
        $c_argentine = $this->getMovieByCountry($userId, 47, $sort, $order);
        $c_cuban = $this->getMovieByCountry($userId, 111, $sort, $order);
        $c_dominica = $this->getMovieByCountry($userId, 105, $sort, $order);
        $data = $this->getMovieDataWithGenre($userId, $sort, $order);

        $categories = [
            $recent,
            $just,
            $premiere,
            $popular,
            $top_rate,
            $oscars,
            $c_argentine,
            $c_cuban,
            $c_dominica
        ];
        array_unshift($data, ...$categories);

        return $data;
    }



    public function getMovieBySort(Request $request)
    {
        $userId = $this->getUserId($request->input('username'));

        $sortMap = [
            'Year'       => 'release',
            'Title'      => 'title',
            'Just Added' => 'created_at',
            'Año'       => 'release',
            'Título'      => 'title',
            'Recién agregado' => 'created_at',
        ];

        $orderMap = [
            'Ascending'  => 'ASC',
            'Descending' => 'DESC',
            'Ascendente'  => 'ASC',
            'Descendente' => 'DESC',
        ];

        // Get inputs
        $sortInput  = $request->input('sortBy');
        $orderInput = $request->input('sortOrder');

        // Map inputs or use default
        $sort  = $sortMap[$sortInput] ?? 'release';
        $order = $orderMap[$orderInput] ?? 'DESC';

        $data = $this->getMovieHomeList($userId, $sort, $order);

        return response()->json([
            "status" => true,
            "data" => $data
        ]);
    }

    public function getMovieFavorite(Request $request)
    {
        $userId = $this->getUserId($request->input('username'));
        $video_ids = FavoriteMovie::where('user_id', $userId)->pluck('movie_id')->toArray();

        $movies = Video::whereIn('videos_id', $video_ids)
            ->has('file')
            ->select('videos_id', 'title', 'genre', 'release', 'poster', 'thumbnail', 'vote_average as rate')
            ->with(['file', 'viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id', 'last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id');
            }])
            ->orderByDesc('updated_at')
            ->get();

        $result[] = [
            'id' => null,
            'name' => 'Favorite',
            'movies' => $movies
        ];

        return response()->json([
            "status" => true,
            "data" => $result
        ]);
    }

    public function getMovieDetail(Request $request)
    {
        $videos_id =  $request->video;
        $userId = $this->getUserId($request->input('username'));
        $data = Video::orderBy('videos_id','DESC')->limit(3)->get();        
        $video = Video::select(
            'videos_id',
            'title',
            'genre',
            'release',
            'poster',
            'thumbnail',
            'stars',
            'rating',            
            'total_rating',
            'video_quality',
            'trailler_youtube_source',
            'runtime',
            'description'
        )
            ->with(['file', 'viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id', 'last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id');
            }])
            ->find($videos_id);
        $video->rating = number_format((float)$video->rating, 2);
        return response()->json([
            "status" => true,
            "data" => $video
        ]);
    }

    public function addMovieFavorite(Request $request)
    {
        $userId = $this->getUserId($request->input('username'));

        $movie_id = $request->video;
        $favorite = FavoriteMovie::where('user_id', $userId)->where('movie_id', $movie_id)->first();

        if ($favorite) {
            // remove favorite
            $favorite->delete();
            return response()->json(['status' => true, 'favorite' => 0]);
        } else {
            // add favorite
            $favorite = new FavoriteMovie();
            $favorite->user_id = $userId;
            $favorite->movie_id = $movie_id;
            $favorite->save();
            return response()->json(['status' => true, 'favorite' => 1]);
        }
    }

    public function getSignedUrl(Request $request)
    {

        Log::info("********" . $request->type);
        if (!$request->video) return response()->json(['status' => false, 'message' => 'Not Find Video']);
        if ($request->type == 'movie') {
            $video = Video::with(['file'])->find($request->video);
            if (!$video->file) return response()->json(['status' => false, 'message' => 'Not Find File']);
            if ($video->file->source_type == 'mp4') {
                $data =  getSignedMp4UrlFromS3($video->file->file_url);
                $movieViewLog = MovieViewLog::where('user_id', $this->getUserId($request->input('username')))
                    ->where('movie_id', $video->videos_id)
                    ->first();
                if (!$movieViewLog) {
                    $movieViewLog = new MovieViewLog();
                    $movieViewLog->user_id = $this->getUserId($request->input('username'));
                    $movieViewLog->movie_id = $video->videos_id;
                }
                $movieViewLog->views += 1;
                $movieViewLog->viewed_at = Carbon::now();
                $movieViewLog->save();
            } else {
                $data = null;
            }
        } else if ($request->type == 'episode') {
            $video = Episode::find($request->video);
            if (!$video->video_url) return response()->json(['status' => false, 'message' => 'Not Find File']);
            if ($video->source_type == 'mp4') {
                $data =  getSignedMp4UrlFromS3($video->video_url);
                $tvViewLog = TvViewLog::where('user_id', $this->getUserId($request->input('username')))
                    ->where('episode_id', $video->id)
                    ->first();
                if (!$tvViewLog) {
                    $tvViewLog = new TvViewLog();
                    $tvViewLog->user_id = $this->getUserId($request->input('username'));
                    $tvViewLog->episode_id = $video->id;
                    $tvViewLog->series_id = $video->series_id;
                    $tvViewLog->season_id = $video->season_id;
                }
                $tvViewLog->views += 1;
                $tvViewLog->viewed_at = Carbon::now();
                $tvViewLog->save();
            } else {
                $data = null;
            }
        }

        return response()->json(['status' => true, 'signedUrl' => $data]);
    }

    public function savePlaybackPosition(Request $request)
    {
        $userId = $this->getUserId($request->input('username'));
        $video_type = $request->input('type');
        $video_id = $request->input('video');
        $position = $request->input('position');
        Log::info($request->all());
        if ($video_type == 'movie') {
            $log = MovieViewLog::where('user_id', $userId)->where('movie_id', $video_id)->first();
            if (!$log) {
                $log = new MovieViewLog();
                $log->user_id = $userId;
                $log->movie_id = $video_id;
            }
            $log->last_position = $position;
            $log->save();
        } else if ($video_type == 'episode') {
            $log = TvViewLog::where('user_id', $userId)->where('episode_id', $video_id)->first();
            if (!$log) {
                $log = new TvViewLog();
                $log->user_id = $userId;
                $log->episode_id = $video_id;
            }
            $log->last_position = $position;
            $log->save();
        }

        return response()->json(['status' => true]);
    }

    // get video list by genre
    private function getMovieDataWithGenre($userId, $sort = 'created_at', $order = 'DESC')
    {

        $genre_list = Cache::rememberForever('genre_list_new', function () {
            return Genre::pluck('name', 'genre_id')->toArray();
        });

        $data = [];
        $limit = config('constants.movie_count_on_app_list');

        foreach ($genre_list as $genre_id => $name) {
            $movies = Video::whereRaw("FIND_IN_SET(?, genre)", [$genre_id])
                ->has('file')
                ->select('videos_id', 'title', 'genre', 'release', 'poster', 'thumbnail', 'rating as rate')
                ->with(['file', 'viewLogs' => function ($query) use ($userId) {
                    $query->where('user_id', $userId)
                        ->select('movie_id', 'user_id', 'last_position', 'viewed_at');
                }, 'favorites' => function ($query) use ($userId) {
                    $query->where('user_id', $userId)
                        ->select('movie_id', 'user_id');
                }])
                ->orderBy($sort, $order)
                ->limit($limit)
                ->get();
            $data[] = [
                'id' => $genre_id,
                'name' => $name,
                'movies' => $movies,
            ];
        }

        return $data;
    }

    private function getMovieRecentView($userId)
    {

        $limit = config('constants.movie_count_on_app_list');

        $movies = Video::select('videos_id', 'title', 'genre', 'release', 'poster', 'thumbnail', 'rating as rate', DB::raw('true as viewed, true as favorite'))
            ->join('movie_view_logs as logs', 'logs.movie_id', '=', 'videos.videos_id')
            ->where('logs.user_id', $userId)
            ->has('file')
            ->orderByDesc('logs.viewed_at')
            ->limit(30)
            ->get();

        $result = ['id' => null, 'name' => 'Recent Viewed', 'movies' => $movies];
        return $result;
    }

    private function getMovieJustAdded($userId)
    {
        $limit = config('constants.movie_count_on_app_list');

        $movies = Video::has('file')
            ->select('videos_id', 'title', 'genre', 'release', 'poster', 'thumbnail', 'rating as rate')
            ->with(['file', 'viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id', 'last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id');
            }])
            ->orderByDesc('updated_at')
            ->limit($limit)
            ->get();

        $result = ['id' => null, 'name' => 'Just Added', 'movies' => $movies];
        return $result;
    }

    private function getMoviePremiere($userId)
    {
        $limit = config('constants.movie_count_on_app_list');

        $movies = Video::has('file')
            ->select('videos_id', 'title', 'genre', 'release', 'poster', 'thumbnail', 'rating as rate')
            ->with(['file', 'viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id', 'last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id');
            }])
            ->orderByDesc('release')
            ->limit($limit)
            ->get();

        $result = ['id' => null, 'name' => 'Premiere', 'movies' => $movies];
        return $result;
    }

    private function getMoviePopular($userId, $sort = 'created_at', $order = 'DESC')
    {
        $limit = config('constants.movie_count_on_app_list');

        $tmdb_ids = Popular::where('type', 'movie')->pluck('tmdb_id')->toArray();

        $movies = Video::whereIn('tmdbid', $tmdb_ids)
            // ->has('file')
            ->select('videos_id', 'title', 'genre', 'release', 'poster', 'thumbnail', 'rating as rate')
            ->with(['file', 'viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id', 'last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id');
            }])
            ->orderBy($sort, $order)
            ->limit($limit)
            ->get();

        $result = ['id' => null, 'name' => 'Popular Movies', 'movies' => $movies];
        return $result;
    }

    private function getMovieTopRate($userId, $sort = 'created_at', $order = 'DESC')
    {
        $limit = config('constants.movie_count_on_app_list');

        $tmdb_ids = TopRates::where('type', 'movie')->pluck('tmdb_id')->toArray();

        $movies = Video::whereIn('tmdbid', $tmdb_ids)
            // ->has('file')
            ->select('videos_id', 'title', 'genre', 'release', 'poster', 'thumbnail', 'rating as rate')
            ->with(['file', 'viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id', 'last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id');
            }])
            ->orderBy($sort, $order)
            ->limit($limit)
            ->get();

        $result = ['id' => null, 'name' => 'Top Rate Movies', 'movies' => $movies];
        return $result;
    }

    private function getMovieOscar($userId, $sort = 'created_at', $order = 'DESC')
    {
        $limit = config('constants.movie_count_on_app_list');
        $tmdb_ids = Oscar::where('type', 'movie')->pluck('tmdb_id')->toArray();

        $movies = Video::whereIn('tmdbid', $tmdb_ids)
            // ->has('file')
            ->select('videos_id', 'title', 'genre', 'release', 'poster', 'thumbnail', 'rating as rate')
            ->with(['file', 'viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id', 'last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id');
            }])
            ->orderBy($sort, $order)
            ->limit($limit)
            ->get();

        $result = ['id' => null, 'name' => 'Oscar', 'movies' => $movies];
        return $result;
    }

    private function getMovieByCountry($userId, $country = 105, $sort = 'created_at', $order = 'DESC')
    {
        $limit = config('constants.movie_count_on_app_list');

        if ($country == 105) $country_name = 'Dominican Cinema';
        else if ($country == 47) $country_name = 'Argentine Cinema';
        else if ($country == 111) $country_name = 'Cuban Cinema';
        else $country_name = Country::find($country)->name . ' Cinema';

        $movies = Video::whereRaw("FIND_IN_SET(?, country)", [$country])
            ->has('file')
            ->select('videos_id', 'title', 'genre', 'release', 'poster', 'thumbnail', 'rating as rate')
            ->with(['file', 'viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id', 'last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id');
            }])
            ->orderBy($sort, $order)
            ->limit($limit)
            ->get();

        $result = ['id' => null, 'name' => $country_name, 'movies' => $movies];
        return $result;
    }

    //////////////////////// TV API ///////////////////////

    private function getTVHomeList($userId, $sort = 'created_at', $order = 'DESC')
    {
        $data = $this->getTVDataWithGenre($userId, $sort, $order);
        $recent = $this->getTvRecentView($userId);
        $just = $this->getTVJustAdded($userId);
        $premiere = $this->getTVPremiere($userId);
        $anime = $this->getTVAnime($userId, $sort, $order);
        $narco = $this->getTVNarco($userId, $sort, $order);
        $retro = $this->getTVRetro($userId, $sort, $order);
        $saga = $this->getTVSaga($userId);
        $spanish = $this->getTvByCountry($userId, 24, $sort, $order);
        $latin = $this->getTvLatinoamericanas($userId, $sort, $order);
        $turnkey = $this->getTVPopular($userId);

        $categories = [
            $recent,
            $just,
           // $premiere,
            $anime,
            $narco,
            $retro,
            //$saga,
            $spanish,
            $latin,
            $turnkey
        ];
        //array_unshift($data, ...$categories);

        return $data;
    }

    public function getTVBySort(Request $request)
    {
        $userId = $this->getUserId($request->input('username'));
        $sortMap = [
            'Year'       => 'release',
            'Title'      => 'title',
            'Just Added' => 'created_at',
            'Año'       => 'release',
            'Título'      => 'title',
            'Recién agregado' => 'created_at',
        ];

        $orderMap = [
            'Ascending'  => 'ASC',
            'Descending' => 'DESC',
            'Ascendente'  => 'ASC',
            'Descendente' => 'DESC',
        ];

        // Get inputs
        $sortInput  = $request->input('sortBy');
        $orderInput = $request->input('sortOrder');

        // Map inputs or use default
        $sort  = $sortMap[$sortInput] ?? 'release';
        $order = $orderMap[$orderInput] ?? 'DESC';
        $data = $this->getTVHomeList($userId, $sort, $order);

        return response()->json([
            "status" => true,
            "data" => $data
        ]);
    }
    public function getEpisodeLastPosition(Request $request)
    {
        $userId = $this->getUserId($request->input('username'));
        $episode_id = $request->input('video');
        $log = TvViewLog::where('user_id', $userId)->where('episode_id', $episode_id)->first();
        $last_position = 0;
        if ($log) {
            $last_position = $log->last_position;
        }
        Log::info("Last position for user_id: $userId, episode_id: $episode_id is $last_position");
        return response()->json([
            "status" => true,
            "lastPosition" => $last_position
        ]);
    }


    public function getTVFavorite(Request $request)
    {
        $userId = $this->getUserId($request->input('username'));
        $favorites = FavoriteTv::select('series_id')->where('user_id', $userId)
            ->groupBy('series_id')
            ->get();
        if ($favorites->isEmpty()) {
            //TODO: return empty structure
            return response()->json(['id' => null, 'name' => 'Favorite', 'shows' => []]);
        }
        Log::info($favorites);
        $shows = Series::whereIn('id', $favorites)->with([
            'seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            },
            'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                    ->orderBy('episode_number', 'ASC');
            },
            'seasons.episodes.viewLogs' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            },
            'viewLogs' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            },
            'favorites' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            }
        ])
            ->get();

        $result[] = [
            'id' => null,
            'name' => 'Favorite',
            'shows' => $shows
        ];

        return response()->json([
            "status" => true,
            "data" => $result
        ]);
    }

    public function addTvFavorite(Request $request)
    {
        $userId = $this->getUserId($request->input('username'));
        Log::info("******************** TV Favorite ********************");
        $series_id = $request->video;
        $favorite = FavoriteTv::where('user_id', $userId)->where('series_id', $series_id)->first();
        if ($favorite) {
            // remove favorite
            $favorite->delete();
            return response()->json(['status' => true, 'favorite' => 0]);
        } else {
            // add favorite
            $favorite = new FavoriteTv();
            $favorite->user_id = $userId;
            $favorite->series_id = $series_id;
            $favorite->save();
            return response()->json(['status' => true, 'favorite' => 1]);
        }
    }

    private function getTVDataWithGenre($userId, $sort = 'created_at', $order = 'DESC')
    {

        $genre_list = Cache::rememberForever('genre_list_new', function () {
            return Genre::pluck('name', 'genre_id')->toArray();
        });

        $data = [];
        $limit = config('constants.movie_count_on_app_list');

        foreach ($genre_list as $genre_id => $name) {
            $shows = Series::whereRaw("FIND_IN_SET(?, genre)", [$genre_id])
                ->has('seasons.episodes')
                ->select('id', 'title', 'genre','description', 'release', 'poster', 'thumbnail', 'vote_average as rate','backdrop','stars')
                ->with(['seasons' => function ($query) {
                    $query->select('id', 'series_id', 'season_number', 'release_year');
                }, 'seasons.episodes' => function ($query) {
                    $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                        ->orderBy('episode_number', 'ASC');
                }, 'seasons.episodes.viewLogs' => function ($query) use ($userId) {
                    $query->where('user_id', $userId)
                        ->select('series_id','user_id','episode_id', 'last_position', 'viewed_at');
                }, 'favorites' => function ($query) use ($userId) {
                    $query->where('user_id', $userId)
                        ->select('series_id', 'user_id');
                }])
                ->orderBy($sort, $order)
                ->limit($limit)
                ->get();
            $data[] = [
                'id' => $genre_id,
                'name' => $name,
                'shows' => $shows,
            ];
        }

        return $data;
    }

    private function getTVRecentView($userId)
    {

        $latestLogs = DB::table('tv_view_logs')
            ->select('series_id', DB::raw('MAX(viewed_at) as last_viewed'))
            ->where('user_id', $userId)
            ->groupBy('series_id');

        $shows = Series::select(
            'series.id',
            'series.title',
            'series.genre',
            'series.release',
            'series.poster',
            'series.description',
            'series.thumbnail', 
            'series.stars',         
            'vote_average as rate',
            'backdrop',
            DB::raw('true as viewed'),
            DB::raw('true as favorite'),
            'l.last_viewed'
        )
            ->joinSub($latestLogs, 'l', 'l.series_id', '=', 'series.id')
            ->with(['seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            }, 'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                    ->orderBy('episode_number', 'ASC');
            }])
            ->has('seasons.episodes')
            ->orderByDesc('l.last_viewed')
            ->limit(30)
            ->get();

        return ['id' => null, 'name' => 'Recent Viewed', 'shows' => $shows];
    }

    private function getTVJustAdded($userId)
    {
        //
        $shows = Series::has('seasons.episodes')
            ->select('id', 'title', 'genre','description', 'release', 'poster', 'thumbnail', 'vote_average as rate','backdrop')
            ->with(['seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            }, 'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                    ->orderBy('episode_number', 'ASC');
            }, 'seasons.episodes.viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('series_id', 'user_id', 'episode_id','last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('series_id', 'user_id');
            }])
            ->orderByDesc('created_at')
            ->limit(30)
            ->get();

        $result = ['id' => null, 'name' => 'Just Added', 'shows' => $shows];
        return $result;
    }
    private function getTVPremiere($userId)
    {
        //
        $shows = Series::has('seasons.episodes')
            ->select('id', 'title', 'genre','description', 'release', 'poster', 'thumbnail', 'vote_average as rate','backdrop')
            ->with(['seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            }, 'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                    ->orderBy('episode_number', 'ASC');
            }, 'seasons.episodes.viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('series_id', 'user_id', 'episode_id','last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('series_id', 'user_id');
            }])
            ->orderByDesc('release')
            ->limit(30)
            ->get();

        $result = ['id' => null, 'name' => 'Premiere', 'shows' => $shows];
        return $result;
    }
    private function getTVPopular($userId)
    {
        //  
        $tmdb_ids = Popular::where('type', 'tv')->pluck('tmdb_id')->toArray();

        $shows = Series::whereIn('tmdb_id', $tmdb_ids)->with([
            'seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            },
            'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                    ->orderBy('episode_number', 'ASC');
            },
            'seasons.episodes.viewLogs' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            },
            'viewLogs' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            },
            'favorites' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            }
        ])
            ->get();

        $result = ['id' => null, 'name' => 'Turkey', 'shows' => $shows];
        return $result;
    }

    private function getTvAnime($userId, $sort = 'created_at', $order = 'DESC')
    {
        $limit = config('constants.movie_count_on_app_list');
        $shows = Series::with([
            'seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            },
            'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                    ->orderBy('episode_number', 'ASC');
            },
            'seasons.episodes.viewLogs' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            },
            'viewLogs' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            },
            'favorites' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            }
        ])
            ->whereRaw("FIND_IN_SET(?, genre)", [5]) // 5 is the genre ID for Animation
            ->whereRaw("FIND_IN_SET(?, country)", [5]) // 5 is the country ID for japan
            ->orderBy($sort, $order)
            ->limit($limit)
            ->get();



        $result = ['id' => null, 'name' => 'Anime', 'shows' => $shows];
        return $result;
    }

    private function getTvNarco($userId, $sort = 'created_at', $order = 'DESC')
    {
        $limit = config('constants.movie_count_on_app_list');
        $shows = Series::with([
            'seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            },
            'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                    ->orderBy('episode_number', 'ASC');
            },
            'seasons.episodes.viewLogs' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            },
            'viewLogs' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            },
            'favorites' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            }
        ])
            ->whereRaw("FIND_IN_SET(?, genre)", [8]) // 8 is the genre ID for Crime
            ->whereRaw("FIND_IN_SET(?, genre)", [10]) // 10 is the genre ID for Drama
            ->orderBy($sort, $order)
            ->limit($limit)
            ->get();


        $result = ['id' => null, 'name' => 'Narco Series', 'shows' => $shows];
        return $result;
    }

    private function getTvRetro($userId, $sort = 'created_at', $order = 'DESC')
    {
        $limit = config('constants.movie_count_on_app_list');

        $shows = Series::with([
            'seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            },
            'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                    ->orderBy('episode_number', 'ASC');
            },
            'seasons.episodes.viewLogs' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            },
            'viewLogs' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            },
            'favorites' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            }
        ])
            ->where('release', '<', '2000-01-01')
            ->where('release', '!=', null)
            ->orderBy($sort, $order)
            ->limit($limit)
            ->get();


        $result = ['id' => null, 'name' => 'Retro Series', 'shows' => $shows];
        return $result;
    }

    private function getTvSaga($userId)
    {
        $limit = config('constants.movie_count_on_app_list');
        $videos = Saga::limit($limit)->get();
        $shows = [];
        foreach ($videos as $item) {
            $shows[] = Series::with([
                'seasons' => function ($query) {
                    $query->select('id', 'series_id', 'season_number', 'release_year');
                },
                'seasons.episodes' => function ($query) {
                    $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                        ->orderBy('episode_number', 'ASC');
                },
                'seasons.episodes.viewLogs' => function ($q) use ($userId) {
                    $q->where('user_id', $userId);
                },
                'viewLogs' => function ($q,) use ($userId) {
                    $q->where('user_id', $userId);   // only logs for this user
                },
                'favorites' => function ($q,) use ($userId) {
                    $q->where('user_id', $userId);   // only logs for this user
                }
            ])->where('tmdb_id', $item->tmdb_id)->first();
        }
        $result = ['id' => null, 'name' => 'Saga', 'shows' => $shows];
        return $result;
    }


    private function getTvByCountry($userId, $country = 24, $sort = 'created_at', $order = 'DESC')
    {

        $limit = config('constants.movie_count_on_app_list');
        $shows = Series::with([
            'seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            },
            'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                    ->orderBy('episode_number', 'ASC');
            },
            'seasons.episodes.viewLogs' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            },
            'viewLogs' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            },
            'favorites' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            }
        ])
            ->whereRaw("FIND_IN_SET(?, country)", [$country])
            ->orderBy($sort, $order)
            ->get();

        if ($country == 105) $country_name = 'Dominican Series';
        else if ($country == 47) $country_name = 'Argentine Series';
        else if ($country == 111) $country_name = 'Cuban Series';
        else if ($country == 24) $country_name = 'Spanish Series';
        else $country_name = Country::find($country)->name . ' Series';
        $result = ['id' => null, 'name' => $country_name, 'shows' => $shows];
        return $result;
    }

    private function getTvLatinoamericanas($userId, $sort = 'created_at', $order = 'DESC')
    {
        $limit = config('constants.movie_count_on_app_list');
        $shows = Series::with([
            'seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            },
            'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                    ->orderBy('episode_number', 'ASC');
            },
            'seasons.episodes.viewLogs' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            },
            'viewLogs' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            },
            'favorites' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            }
        ])
            ->whereRaw("FIND_IN_SET(?, country)", [105]) // Dominican Republic
            ->orWhereRaw("FIND_IN_SET(?, country)", [47]) // Argentina
            ->orWhereRaw("FIND_IN_SET(?, country)", [111]) // Cuba
            ->orWhereRaw("FIND_IN_SET(?, country)", [97]) // Mexico
            ->orWhereRaw("FIND_IN_SET(?, country)", [102]) // Colombia
            ->orderBy($sort, $order)
            ->get();
        $result = ['id' => null, 'name' => 'Latinoamericanas', 'shows' => $shows];
        return $result;
    }

    private function getMovieTrailer()
    {
        $data = MovieTrailer::with('movie')->get();
        $trailers = [];

        foreach ($data as $item) {
            $trailer = [];
            $trailer['id'] = $item->id;
            $trailer['title'] = $item->movie->title;
            $trailer['trailer_url'] = $item->movie->trailler_youtube_source;
            $trailer['bg_url'] = $item->movie->bg_url ? TMDB_IMAGE_ORIGINAL . basename($item->movie->bg_url) : null;
            $trailer['source'] = 'youtube';
            $trailer['release'] = $item->movie->released_year;
            $trailer['duration'] = $item->movie->runtime;
            $trailer['genre'] = $item->movie->genre_names;
            $trailers[] = $trailer;
        }

        return $trailers;
    }


    public function getAllChannels(Request $request)
    {
        $channels = LiveTv::select('live_tv_id', 'tv_name', 'thumbnail', 'categories', 'publish')
            ->where('publish', 1)
            ->get();

        Log::info($channels);
        if ($channels) return response()->json(['status' => true, 'message' => 'Get Channels Successful.', 'data' => $channels]);
        else return response()->json(['status' => false, 'message' => 'Get Channels Failed.', 'data' => []]);
    }
    private function returnTVShowsData($videos)
    {
        $shows = [];
        foreach ($videos as $item) {
            if ($item && $item->seasons->isNotEmpty()) {
                $show = $this->returnSeriesData($item);
                $shows[] = $show;
            }
        }
        return $shows;
    }

    private function returnSeriesData($item)
    {
        $series = [
            'id' => $item->id,
            'title' => $item->title,
            'rating' => $item->rating,
            'year' => $item->release ? explode("-", $item->release)[0] : 'N/A',
            'description' => $item->description,
            'backgroundImageUrl' => $item->poster ? TMDB_IMAGE_ORIGINAL . basename($item->poster) : null,
            'cardImageUrl' => $item->poster ? TMDB_IMAGE_W342 . basename($item->poster) : null,
            'viewed' => $item->viewLogs && $item->viewLogs->count() > 0 ? true : false,
            'favorites' => $item->favorite && $item->favorite->count() > 0 ? true : false,
            'seasons' => $item->seasons->map(function ($season) {
                return [
                    'seasonNumber' => $season->season_number,
                    // Episodes
                    'episodes' => $season->episodes
                        ->sortBy('episode_number')
                        ->map(function ($ep) {
                            return [
                                'id' => $ep->id,
                                'episodeNumber' => $ep->episode_number,
                                'title' => $ep->title,
                                'description' => $ep->overview,
                                'thumbnailUrl' => $ep->thumbnail ? 'https://image.tmdb.org/t/p/w500/' . basename($ep->thumbnail) : null,
                                'videoUrl' => $ep->video_url ?? null,
                                'duration' => $ep->runtime,
                                'language' => $ep->track,
                                'lastPosition' => $ep->viewLogs->first() ? $ep->viewLogs->first()->last_position : 0,
                                'viewed' => $ep->viewLogs && $ep->viewLogs->count() > 0 ? true : false
                            ];
                        })->values()
                ];
            })->values()
        ];

        return $series;
    }

    private function getUserId($username)
    {
        $user = User::where('username', $username)->first();
        if ($user) {
            return $user->user_id;
        } else {
            return null;
        }
    }

    private function searchMovies(Request $request){
        $action  = $request->input('action');
        $title  = $request->input('title');
        $actor_id  = $request->input('actor_id');
        $userId = $this->getUserId($request->input('username'));
        $limit = config('constants.movie_count_on_app_list');
        if($action == 'title'){
            $data = Video::where("title", '%'.$title.'%');
        } elseif($action == 'actor') {
            // by actor
            $data = Video::whereRaw("FIND_IN_SET(?, stars)", [$actor_id]);
        } else {
            return response()->json([
                "status" => false,
                "data" => []
            ]);
        }

        $data = $data->has('file')
            ->select('videos_id', 'title', 'genre', 'release', 'poster', 'thumbnail', 'rating as rate')
            ->with(['file', 'viewLogs' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id', 'last_position', 'viewed_at');
            }, 'favorites' => function ($query) use ($userId) {
                $query->where('user_id', $userId)
                    ->select('movie_id', 'user_id');
            }])
            // ->orderBy($sort, $order)
            ->limit($limit)
            ->get();

        return response()->json([
            "status" => true,
            "data" => $data
        ]);
    }
    
    private function searchSeries(Request $request){
        $action  = $request->input('action');
        $title  = $request->input('title');
        $actor_id  = $request->input('actor_id');
        $userId = $this->getUserId($request->input('username'));
        $limit = config('constants.movie_count_on_app_list');
        
        $shows = Series::with([
            'seasons' => function ($query) {
                $query->select('id', 'series_id', 'season_number', 'release_year');
            },
            'seasons.episodes' => function ($query) {
                $query->select('id', 'season_id', 'title', 'video_url', 'track', 'episode_number')
                ->orderBy('episode_number', 'ASC');
            },
            'seasons.episodes.viewLogs' => function ($q) use ($userId) {
                $q->where('user_id', $userId);
            },
            'viewLogs' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            },
            'favorites' => function ($q,) use ($userId) {
                $q->where('user_id', $userId);   // only logs for this user
            }
        ]);
            
        if($action == 'title'){
            $data = $shows->where("title", '%'.$title.'%')
            // ->orderBy($sort, $order)
            ->get();
        } elseif($action == 'actor') {
            // by actor
            $data = $shows->whereRaw("FIND_IN_SET(?, stars)", [$actor_id])
            // ->orderBy($sort, $order)
            ->get();
        } else {
            return response()->json([
                "status" => false,
                "data" => []
            ]);
        }

        return response()->json([
            "status" => true,
            "data" => $data
        ]);
    }
}
