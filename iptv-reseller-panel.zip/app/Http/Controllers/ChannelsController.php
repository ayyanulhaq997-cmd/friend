<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\User;
use App\Models\VideoFile;
use App\Models\Video;
use App\Models\Series;
use App\Models\Season;
use App\Models\Star;
use App\Models\Genre;
use App\Models\Country;
use App\Models\LiveTv;
use App\Models\LiveTvStream;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use DateTime;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Laravel\SerializableClosure\Serializers\Native;

class ChannelsController extends Controller
{
    /**
     * customer list
     */
    public function index(Request $request): Response
    {
        $channels = LiveTv::with('streams')
            ->orderBy('live_tv_id', 'DESC')
            ->paginate(10, ['*'], 'page', 1);
        return Inertia::render('Channels/Index', ['channel_list' => $channels]);
    }

    public function create(Request $request): Response
    {
        return Inertia::render('Channels/Create');
    }

    public function edit(Request $request, $id = null)
    {
        $channel = LiveTv::with('streams')->find($id);

        if ($channel == null) {
            return redirect()->route('channels.index');
        }

        return Inertia::render('Channels/Edit', [
            'channel' => $channel
        ]);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'logo' => 'required|string|max:255',
            'channel_id' => 'required|string|unique:live_tv,channel_id',
            'country' => 'required|string|min:3',
            'category' => 'nullable|string|max:20',
            'source' => 'nullable|string',
            'label' => 'nullable|string',
            'quality' => 'nullable|string',
            'url' => 'required|string|unique:live_tv_url,url',
            'status' => 'bool'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $channel = new LiveTv();
        $channel->tv_name = $request->name;
        $channel->thumbnail = $request->logo;
        $channel->channel_id = $request->channel_id;
        $channel->country = $request->country;
        $channel->categories = $request->catetory;
        $channel->publish = $request->status;
        if ($channel->save()) {
            $stream = new LiveTvStream();
            $stream->source = $request->source;
            $stream->live_tv_id = $channel->live_tv_id;
            $stream->quality = $request->quality;
            $stream->url = $request->url;
            if ($stream->save()) return response()->json([
                'success' => true,
                'message' => 'Channel created successfully.',
                'user' => $channel,
            ]);
        }
        return response()->json([
            'success' => false,
            'errors' => 'Channel Create failed'
        ], 422);
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'logo' => 'required|string|max:255',
            'country' => 'required|string|min:3',
            'category' => 'nullable|string|max:20',
            'source' => 'nullable|string',
            'label' => 'nullable|string',
            'quality' => 'nullable|string',
            'url' => 'required|string',
            'status' => 'bool'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $channel = LiveTv::find($request->id);
        if ($channel == null) return response()->json([
            'success' => false,
            'errors' => 'Channel not found'
        ], 422);
        $channel->tv_name = $request->name;
        $channel->thumbnail = $request->logo;
        $channel->channel_id = $request->channel_id;
        $channel->country = $request->country;
        $channel->categories = $request->catetory;
        $channel->publish = $request->status;
        if ($channel->save()) {
            $stream = LiveTvStream::find($request->live_tv_url_id);
            if ($stream ==  null) if ($channel == null) return response()->json([
                'success' => false,
                'errors' => 'Stream not found'
            ], 422);
            $stream->source = $request->source;           
            $stream->quality = $request->quality;
            $stream->url = $request->url;
            if ($stream->save()) return response()->json([
                'success' => true,
                'message' => 'Channel update successfully.',
                'user' => $channel,
            ]);
        }
        return response()->json([
            'success' => false,
            'errors' => 'Channel update failed'
        ], 422);
    }

    public function delete(Request $request, $id = null)
    {

        try {
            $channel = LiveTv::find($id);
            LiveTvStream::where('live_tv_id', $id)->delete();
            $channel->delete();
            return response()->json([
                'success' => true,
                'message' => 'Channel deleted successfully'
            ]);
            // process $user
        } catch (ModelNotFoundException $e) {
            // handle error
            return redirect()->route('channels.index')
                ->with('error', 'Channel not found.');
        }
    }

    public function search(Request $request)
    {

        $page = $request->page;
        $search = $request->search;
        $channels = LiveTv::with('streams')
            ->where('tv_name', 'LIKE', '%' . $search . '%')
            ->orderBy('live_tv_id', 'DESC')
            ->paginate(10, ['*'], 'page', $page);
        return response()->json(['channel_list' => $channels]);
    }

    public function publish(Request $request)
    {
        $channel_id =  $request->channel_id;
        $channel =  LiveTv::find($channel_id);
        if ($channel)
            $channel->publish = !$channel->publish;

        else return response()->json(['success' => false, 'message' => 'Not Found Channel']);
        if ($channel->save()) return response()->json(['success' => true, 'message' => 'Update successful.']);
        else return response()->json(['success' => false, 'message' => 'Update Error.']);
    }
}
