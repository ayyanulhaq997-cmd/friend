<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\User;
use App\Models\Credits;
use App\Models\Subscription;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Hash;
use Illuminate\Auth\Events\Registered;
use DateTime;
use GuzzleHttp\Promise\Create;
use PhpParser\Node\Stmt\Global_;

class CustomersController extends Controller
{
    /**
     * customer list
     */
    public $user_id;
    public function __construct()
    {
        $user = Auth::user();
        $this->user_id = $user->user_id;
    }
    public function index(Request $request): Response
    {
        $user = Auth::user();   // returns the User model
        $user_id = $user->user_id;
        $type = $request->query('type', 'all');
        $customers = null;
        if ($user->role == 'admin') {
            $customers = User::where('role', 'user');
        } else if ($user->role == 'reseller') {
            $user_ids = User::where('parent_id', $user_id)->get()->pluck('user_id')->toArray();
            $user_ids[] = $user_id;
            $customers = User::whereIn('parent_id', $user_ids)->where('role', 'user');
        } else {
            $customers = User::where('parent_id', $user_id)->where('role', 'user');
        }
        if ($type == 'all') $customers = $customers->where('role', 'user')
            ->get();
        else if ($type == 'test') $customers = $customers->where('role', 'user')
            ->get()
            ->filter(fn($user) => $user->credit == 0);
        else if ($type == 'premium') $customers = $customers->where('role', 'user')
            ->get()
            ->filter(fn($user) => $user->credit > 0);

        return Inertia::render('Customers/Index', ['users' => $customers]);
    }

    public function test(Request $request): Response
    {
        $user = Auth::user();   // returns the User model
        $user_id = $user->user_id;
        $customers = User::where('parent_id', $user_id)
            ->where('role', 'user')
            ->get()
            ->filter(fn($user) => $user->credit == 0);
        return Inertia::render('Customers/Test', ['users' => $customers]);
    }

    public function create(Request $request): Response
    {
        return Inertia::render('Customers/Create');
    }

    public function demo(Request $request): Response
    {
        $user = Auth::user();   // returns the User model
        $user_id = $user->user_id;
        $customers = null;
        if ($user->role == 'admin') {
            $customers = User::where('role', 'user');
        } else if ($user->role == 'reseller') {
            $user_ids = User::where('parent_id', $user_id)->get()->pluck('user_id')->toArray();
            $user_ids[] = $user_id;
            $customers = User::whereIn('parent_id', $user_ids)->where('role', 'user');
        } else {
            $customers = User::where('parent_id', $user_id)->where('role', 'user');
        }

        $customers = $customers->where('role', 'user')
            ->get()
            ->filter(fn($user) => $user->credit == 0);

        return Inertia::render('Customers/Demo', ['users' => $customers]);
    }

    public function store(Request $request)
    {
        // /** @var \App\Models\User $user */
        $user = Auth::user();   // returns the User model
        $user_id = $user->user_id;


        $validator = Validator::make($request->all(), [
            'name' => 'nullable|string|max:255',
            'username' => 'required|string|max:255|unique:user,username',
            'email' => 'nullable|string|lowercase|email|max:255|unique:user,email',
            'password' => 'required|string|min:3',
            'phone' => 'nullable|string|max:20',
            'duration' => 'required|integer',
            'status' => 'bool',
        ], [
            'password.min' => 'Password should be over 8 characters.',
            'username.unique' => 'This username is already taken.'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        if ($user->role != 'admin' &&  $user->credit < $request->duration) {
            return response()->json([
                'success' => false,
                'message' => 'Not enough credits'
            ]);
        }
        if ($user->role != 'admin' &&  $request->duration == 0) {
            $check_demo_create = Credits::where('sender_id', $user_id)
                ->whereDate('date', now())
                ->first();
            if ($check_demo_create)
                return response()->json([
                    'success' => false,
                    'message' => 'You can create only one demo per day.'
                ]);
        }

        $subscriber = new User();
        $subscriber->name = $request->name;
        $subscriber->username = $request->username;
        $subscriber->email = $request->email ?? '';
        $subscriber->slug = "";
        $subscriber->password = $request->password;
        $subscriber->phone = $request->phone;
        $subscriber->parent_id = $user_id;
        $subscriber->role = "user";
        $subscriber->status = intval($request->status);
        $subscriber->save();


        $start_date = new DateTime(); // today
        if ($request->duration == 0) $end_date = (clone $start_date)->modify('+2 days'); // 2 days after start_date
        else $end_date = (clone $start_date)->modify('+' . $request->duration . ' months');
        $subscription = new Subscription();
        $subscription->start_date = $start_date;
        $subscription->end_date = $end_date;
        $subscription->user_id = $subscriber->user_id;
        $subscription->plan_id = $request->duration;
        $subscription->status = 1;
        $subscription->save();

        $credit = new Credits();
        $credit->sender_id = $this->user_id;
        $credit->receiver_id = $subscriber->user_id;
        $credit->amount = $request->duration;
        $credit->subscription_log_id = $subscription->subscription_id;
        $credit->date = date('Y-m-d H:i:s');
        $credit->save();

        return response()->json([
            'success' => true,
            'message' => 'Customer created successfully.',
            'user' => $subscriber,
        ]);
    }

    public function edit(Request $request, $id = null)
    {
        $user = User::where('user_id', $id)->first();
        $subscriptions = Subscription::where('user_id', $id)->orderBy('start_date', 'DESC')->get();

        return Inertia::render('Customers/Edit', ['user' => $user, 'subscriptions' => $subscriptions]);
    }


    public function update(Request $request, $id = null)
    {
        // /** @var \App\Models\User $reseller */
        $reseller = Auth::user();   // returns the User model
        $subscriber = User::where('user_id', $id)->first();
        if ($subscriber == null) return response()->json(['success' => false, 'message' => 'User Not Found']);
        $validator = Validator::make($request->all(), [
            'name' => 'nullable|string|max:255',
            'username' => 'required|string|max:255',
            'password' => 'required|string|max:255',
            'email' => 'nullable|string|lowercase|email|max:255',
            'phone' => 'nullable|string|max:20',
            'status' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        $subscriber->name = $request->name;
        $subscriber->username = $request->username;
        $subscriber->password = $request->password;
        $subscriber->email = $request->email ?? '';
        $subscriber->phone = $request->phone;
        $subscriber->status = intval($request->status);
        $subscriber->save();

        return response()->json([
            'success' => true,
            'message' => 'Customer created successfully.',
            'user' => $subscriber,
        ]);
    }

    public function delete(Request $request, $id = null)
    {

        $user = User::findOrFail($id);
        try {
            $user = User::findOrFail($id);
            $user->delete();
            return response()->json([
                'success' => true,
                'message' => 'User deleted successfully'
            ]);
            // process $user
        } catch (ModelNotFoundException $e) {
            // handle error
            return redirect()->route('customers.index')
                ->with('error', 'Subscriber not found.');
        }
    }

    public function addSubscription(Request $request)
    {

        $user = Auth::user();   // returns the User model

        $validator = Validator::make($request->all(), [
            'start_date' => 'required|string|max:255',
            'end_date' => 'required|string|max:255',
            'user_id' => 'required|integer',
            'duration' => 'required|integer',
            'status' => 'boolean',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }
        if ($user->role != 'admin' &&  $user->credit < $request->duration) {
            return response()->json([
                'success' => false,
                'message' => 'Insufficient credits to create customer with the selected subscription duration.'
            ]);
        }
        $start_date = new DateTime($request->start_date);
        $end_date = new DateTime($request->end_date);

        $subscription = new Subscription();
        $subscription->start_date = $start_date;
        $subscription->end_date = $end_date;
        $subscription->user_id = $request->user_id;
        $subscription->plan_id = $request->duration;
        $subscription->status = $request->status;
        $subscription->save();

        $credit = new Credits();
        $credit->sender_id = $this->user_id;
        $credit->receiver_id = $request->user_id;
        $credit->amount = $request->duration;
        $credit->subscription_log_id = $subscription->subscription_id;
        $credit->date = date('Y-m-d H:i:s');
        $credit->save();

        $subscriber = User::find($request->user_id);

        if ($subscription) return response()->json(['success' => true, 'message' => 'Add subscription successful!', 'subscription' => $subscription, 'user' => $subscriber]);
        else return response()->json(['success' => false, 'message' => 'Add subscription error!']);
    }

    public function stopSubscription(Request $request, $id = null)
    {

        $subscription = Subscription::find($id);
        if ($subscription == null) return response()->json(['success' => false, 'message' => 'Subscription not found!']);

        $subscription->status = 0;
        $subscription->save();
        $user = User::find($subscription->user_id);
        if ($subscription) return response()->json(['success' => true, 'message' => 'Subscription stopped successfully!', 'subscription' => $subscription, 'user' => $user]);
        else return response()->json(['success' => false, 'message' => 'Stop subscription error!']);
    }

    public function resumeSubscription(Request $request, $id = null)
    {

        $subscription = Subscription::find($id);
        if ($subscription == null) return response()->json(['success' => false, 'message' => 'Subscription not found!']);

        $subscription->status = 1;
        $subscription->save();
        $user = User::find($subscription->user_id);
        if ($subscription) return response()->json(['success' => true, 'message' => 'Subscription resumed successfully!', 'subscription' => $subscription, 'user' => $user]);
        else return response()->json(['success' => false, 'message' => 'Resume subscription error!']);
    }

    public function deleteSubscription(Request $request, $id = null)
    {

        $subscription = Subscription::find($id);

        if ($subscription == null) return response()->json(['success' => false, 'message' => 'Subscription not found!']);
        Credits::where('subscription_log_id', $id)->delete();
        $subscription->delete();
        $user = User::find($subscription->user_id);
        if ($subscription) return response()->json(['success' => true, 'message' => 'Subscription deleted successfully!', 'user' => $user]);
        else return response()->json(['success' => false, 'message' => 'Delete subscription error!']);
    }
}
