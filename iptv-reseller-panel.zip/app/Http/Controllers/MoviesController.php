<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\User;
use App\Models\VideoFile;
use App\Models\Video;
use App\Models\Series;
use App\Models\Season;
use App\Models\Star;
use App\Models\Genre;
use App\Models\Country;
use App\Models\Episode;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use DateTime;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Laravel\SerializableClosure\Serializers\Native;

class MoviesController extends Controller
{
    /**
     * customer list
     */
    public function index(Request $request): Response
    {
        $movies = Video::orderBy('release', 'DESC')          
            ->paginate(10, ['*'], 'page', 1);        
        return Inertia::render('Movies/Index', ['movie_list' => $movies]);
    }



    public function search(Request $request)
    {

        $page = $request->page;
        $search = $request->search;
        $movies = Video::where('title', 'LIKE', '%' . $search . '%')
            ->orderBy('release', 'DESC')
            ->paginate(10, ['*'], 'page', $page);
        return response()->json(['movie_list' => $movies]);
    }

    public function detail(Request $request)
    {

        $video_id = $request->id;
        $movie = DB::table('videos')
            ->where('videos_id', $video_id)
            ->first();
        if (!$movie)  return response()->json(['success' => false, 'messege' => 'Not Found Movie']);
        $movie->video_file = DB::table('video_file')->where('videos_id', $video_id)->first();
        $str_director = "";
        if ($movie->director) {
            $directors = explode(',', $movie->director);
            $directors_name = DB::table('star')->select('star_name')->whereIn('star_id', $directors)->get();
            $directors = $directors_name->pluck('star_name')->implode(', ');
            $movie->director = $directors;
        } else $movie->director = '';
        if ($movie->genre) {
            $genres = explode(',', $movie->genre);
            $genres_name = DB::table('genre')->select('name')->whereIn('genre_id', $genres)->get();
            $genres = $genres_name->pluck('name')->implode(', ');
            $movie->genre = $genres;
        } else $movie->genre = '';
        return response()->json(['movie' => $movie]);
    }

    public function delete(Request $request, $id)
    {

        $movie = Video::with('file')->find($id);
        if ($movie->file) {
            VideoFile::where('video_file_id', $movie->file->video_file_id)->delete();
            //TODO Delete server movie files

        }
        if ($movie->delete()) {
            return response()->json([
                'success' => true,
                'message' => 'Movie deleted successfully.',
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Movie delete error.',
            ]);
        }
    }

    public function upload(Request $request)
    {

        $request->validate([
            'file' => 'required|file|max:2097152', // max 10MB
            'movie_id' => 'required|integer',
        ]);

        $extension = $request->file('file')->getClientOriginalExtension();

        // Build new filename
        $fileName = $request->movie_id . '_' . time() . '.' . $extension;

        // Define custom storage path (one level before Laravel root)
        $destinationPath = base_path('../sync/uploads'); // outside root

        // Create folder if not exists
        if (!file_exists($destinationPath)) {
            mkdir($destinationPath, 0777, true);
        }

        // Move the uploaded file
        $request->file('file')->move($destinationPath, $fileName);
        // $newVideoFile =  VideoFile::where('videos_id', $request->movie_id)->first();
        // if (!$newVideoFile) {
        //     $newVideoFile =  new VideoFile();
        //     $newVideoFile->videos_id =  $request->movie_id;
        // }

        // $newVideoFile->file_url = $destinationPath . '/' . $fileName;
        // $newVideoFile->file_source = '';
        // $newVideoFile->save();

        //TODO send storage server

        // Optional: store path in DB or return response
        return response()->json([
            'message' => 'File uploaded successfully',
            'movie_id' => $request->movie_id,
            'success' => true,
            'file_name' => $fileName,
            'path' => $destinationPath . '/' . $fileName,
        ]);
    }



    public function import(Request $request)
    {
        return Inertia::render('Movies/Import');
    }

    public  function tmdbData(Request $request)
    {
        $type = $request->input('type', 'MovieByTitle');
        $search_str = $request->input('search_str', '');
        $search_year = $request->input('search_year', 2020);
        $page = $request->input('page', 1);
        $url = "";
        $key = env('TMDB_API_KEY');
        $tmdb_api = env('TMDB_API_SERVER');
        $media_type = 'movie';
        if ($type == 'MovieByTitle') {
            $url = "$tmdb_api/search/multi?api_key=$key&query=$search_str&page=$page";
        } else if ($type == 'PopularMovies') {
            $url = "$tmdb_api/movie/popular?api_key=$key&page=$page";
        } else if ($type == 'TopRatedMovies') {
            $url = "$tmdb_api/movie/top_rated?api_key=$key&page=$page";
        } else if ($type == 'MovieShowsbyYear') {
            $url = "$tmdb_api/discover/movie?api_key=$key&primary_release_year=$search_year&page=$page";
        } else if ($type == 'UncommingMovies') {
            $url = "$tmdb_api/movie/upcoming?api_key=$key&page=$page";
        } else if ($type == 'TVShowsByTitle') {
            $url = "$tmdb_api/search/tv?api_key=$key&query=$search_str&page=$page";
            $media_type = 'tv';
        } else if ($type == 'PopularTVShows') {
            $url = "$tmdb_api/tv/popular?api_key=$key&page=$page";
            $media_type = 'tv';
        } else if ($type == 'TopRatedTVShows') {
            $url = "$tmdb_api/tv/top_rated?api_key=$key&page=$page";
            $media_type = 'tv';
        } else if ($type == 'TVShowsbyYear') {
            $url = "$tmdb_api/discover/tv?api_key=$key&first_air_date_year=$search_year&page=$page";
            $media_type = 'tv';
        }
        $response = Http::get($url);
        $data = $response->json();
        

        if ($media_type == 'movie') {
            //Get all tmdb_ids from your local DB
            $existingIds = Video::pluck('tmdbid')->toArray();
            //Attach 'exist' field and thumbnail
            foreach ($data['results'] as &$movie) {
                $movie['exist'] = in_array($movie['id'], $existingIds);
                $movie['media_type'] = $media_type;
            }
        } else {
            $existingIds = Series::pluck('tmdb_id')->toArray();
            //Attach 'exist' field and thumbnail            
            foreach ($data['results'] as &$item) {
                $item['exist'] = in_array($item['id'], $existingIds);
                $item['media_type'] = $media_type;
            }
        }

        
        if ($data)
            return response()->json(['data' => $data, 'success' => true]);
        else return response()->json(['success' => false]);
    }

    public  function  importMovie(Request $request)
    {
        $tmdbId = $request->input('id');
        $tmdbType = $request->input('type', 'movie');
        if (!$tmdbId) return response()->json(['success' => false]);
        $data =  importTmdbData($tmdbId, $tmdbType);
        if ($data)  return response()->json(['data' => $data, 'success' => true]);
        else return response()->json(['success' => false]);
    }

    public function  editMovie(Request $request, $id =  null)
    {
        if ($id == null)
            return  response()->json(['success' => false]);
        $data =  Video::find($id);
        if ($data ==  null) return  response()->json(['success' => false]);
        $starts_id = explode(",", $data->stars);
        $stars = "";
        foreach ($starts_id as  $index =>  $item) {
            $star =  Star::find($item);
            if ($index == 0) $stars .= $star->star_name??'';
            else $stars .= ", " . $star->star_name??'';
        }
        $data->stars = $stars;
        $directors_id = explode(",", $data->director);
        $directors = "";
        foreach ($directors_id  as  $index =>  $item) {
            $star =  Star::find($item);
            if ($index == 0) $directors .= $star->star_name??'';
            else $directors .= ", " . $star->star_name??'';
        }
        $data->director = $directors;

        $writers_id = explode(",", $data->writer);
        $writers = "";
        // foreach ($writers_id  as  $index =>  $item) {
        //     $star =  Star::find($item);
        //     if ($index == 0) $writers .= $star->star_name??'';
        //     else $writers .= ", " . $star->star_name ?? '';
        // }
        $data->writer = $writers;

        $country_id = explode(",", $data->country);
        $countries = "";
        foreach ($country_id  as  $index =>  $item) {
            $country =  Country::find($item);
            if ($index == 0) $countries .= $country->name;
            else $countries .= ", " . $country->name;
        }
        $data->country = $countries;


        $genre_id = explode(",", $data->genre);
        $genres = "";
        foreach ($genre_id  as  $index =>  $item) {
            $genre =  Genre::find($item);
            if ($index == 0) $genres .= $genre->name;
            else $genres .= ", " . $genre->name;
        }
        $data->genre = $genres;
        //dd($data);
        return Inertia::render('Movies/Edit', ['data' => $data]);
    }

    public function  updateMovie(Request $request)
    {
        $video = Video::find($request->id);
        $video->title = $request->title;
        $video->is_paid = intval($request->is_paid);
        $video->trailler_youtube_source = $request->trailler_youtube_source;
        $video->enable_download = intval($request->enable_download);
        $video->save();
        //dd($request->thumb_file);
        if ($request->thumb_file != "null") {
            $destinationPath = "uploads/video_thumb";
            $fileName = $request->id . ".jpg";
            $request->file('thumb_file')->move($destinationPath, $fileName);
        }
        if ($request->poster_file != "null") {
            $destinationPath = "uploads/poster_image";
            $fileName = $request->id . ".jpg";
            $request->file('poster_file')->move($destinationPath, $fileName);
        }
        return response()->json(['data' => $video, 'success' => true]);
    }

    public function matchIndex(Request $request)
    {
        $file_paths =  DB::table('processed_files')
            ->whereIn('status', ['sync_faild'])
            ->orderBy('created_at')->get();
        $videos = Video::doesntHave('file')->get();
        foreach ($videos as $index => $item) { {
                $genre = $item->genre ? explode(',', $item->genre) : null;
                if ($genre) {
                    $genre_list = Genre::whereIn('genre_id', $genre)->get();
                    $genre_str = "";
                    foreach ($genre_list as $index1 => $item1) {
                        if ($index1 != 0) $genre_str .= ", ";
                        $genre_str .= $item1->description;
                    }
                    $item->genre = $genre_str;
                } else  $item->genre = "";
            }
        }
        return Inertia::render('Movies/Match', ['file_paths' => $file_paths, 'videos' => $videos]);
    }

    public function matchByManual(Request $request)
    {
        $data = $request->data ?? [];
        foreach ($data as $item) {
            $newVideoFile = new VideoFile();
            $newVideoFile->videos_id =  $item['movie']['videos_id'];
            $newVideoFile->file_source =  'link';
            $newVideoFile->source_type =  'mp4';
            $newVideoFile->file_url =  $item['path']['path'];
            $newVideoFile->label =  $item['movie']['title'];
            if ($newVideoFile->save()) {
                DB::table('processed_files')->where('id', $item['path']['id'])->update(['status' => 'matched']);
            }
        }

        return response()->json(['success' => true]);
    }

    public  function syncByTmdb(Request $request)
    {
        $sync_data =  DB::table('processed_files')
            ->where('status', 'synced')
            ->where('type', 'movie')
            ->orderBy('created_at')
            ->limit(40)
            ->get();

        foreach ($sync_data as $item) {
            $check_video = Video::where('tmdbid', $item->tmdb_id)->first();
            if ($check_video == null) {
                if ($item->type != 'movie') {
                    $check_video = importTmdbData($item->tmdb_id, 'tv');
                } else {
                    $check_video = importTmdbData($item->tmdb_id);
                }
                if ($check_video == null)  continue;
            }

            $new_video_file =  new VideoFile();
            $new_video_file->videos_id = $check_video->videos_id;
            $new_video_file->file_source = 'link';
            $new_video_file->source_type = 'mp4';
            $new_video_file->file_url = $item->path;
            $new_video_file->label = $check_video->title;
            $new_video_file->save();
            DB::table('processed_files')->where('id', $item->id)->update(['status' => 'matched']);
        }
        return response()->json([
            'success' => true,
            'message' => 'Movie Sync successfully.',
        ]);
    }

    

    public  function syncByAI(Request $request)
    {
        $sync_data =  DB::table('processed_files')
            ->where('status', 'sync_faild')
            ->orderBy('created_at')
            ->limit(1)
            ->get();
        $basename = basename("BUNNYG/M/1946/El.Pirata.Hidalgo.1946.720p.DUAL-SE.mp4");
        $video_data = $this->checkInfo($basename);
        dd($video_data);
        foreach ($sync_data as $item) {
            //$basename = basename($item->path);
            $basename = basename("28/My.left.foot .the.story.of.christy.brown.(1989) Eng-se-1.mp4");
            dd($basename);
            DB::table('processed_files')->where('id', $item->id)->update(['status' => 'matched']);
        }
        return response()->json([
            'success' => true,
            'message' => 'Movie Sync successfully.',
        ]);
    }


    private function checkInfo($name)
    {
        $key = env('TMDB_API_KEY');
        $data = find_media_from_filename($name, $key);
        return  $data;
    }

    

    function filter_tv_countries($countries)
    {
        $countries_name = '';
        for ($i = 0; $i < sizeof($countries); $i++) {
            if ($i > 0) {
                $countries_name .= ',';
            }
            $countries_name .= trim($countries[$i] ?? "");
        }
        return $countries_name;
    }
}
