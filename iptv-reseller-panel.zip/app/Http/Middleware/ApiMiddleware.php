<?php

namespace App\Http\Middleware;


use App;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Carbon;
use App\Models\User;
use App\Models\LoginLog;

class ApiMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $username =  $request->input('username');
        $password =  $request->input('password');
        if ($request->is('api/user')) {  // Your login endpoint           
            $response = $next($request);
            // Check if user exists
            $user = User::where('username', $username)->first();
            // Determine if login successful (your controller should return status:true)
            $success = $response->getStatusCode() == 200;
            $loginLog = LoginLog::where('user_id', $user?->user_id ?? null)
                ->where('ip_address', $request->ip())
                ->where('created_at', 'LIKE', date('Y-m-d') . '%')
                ->where('user_agent', $request->userAgent())             
                ->first();
            if ($loginLog == null) {
                $loginLog = new LoginLog();
                $loginLog->username = $username;
                $loginLog->user_id = $user?->user_id ?? null;
                $loginLog->success = $success;
                $loginLog->ip_address = $request->ip();
                $loginLog->user_agent = $request->userAgent();
                $loginLog->save();
            }
            //check expired access
            $credit_end_date = Carbon::parse($user->latest_subscription_end_date);
            $current_date = Carbon::now();
            if (!$credit_end_date->greaterThanOrEqualTo($current_date) || $user->status != 1) {
              return response()->json(['status' => 'error', 'message' => 'Unauthorized access'], 401);  
            } 
        }
        $check_access = checkUserAccess($username, $password);
        if (!$check_access) {
            return response()->json(['status' => 'error', 'message' => 'Unauthorized access'], 401);
        }
        return $next($request);
    }
}
