<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use App\Models\LoginLog;
use App\Models\User;
class LogLoginAttempt
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
         // Run controller and get response
        $response = $next($request);

        if ($request->is('api/login')) {  // Your login endpoint
            $username = $request->username;

            // Check if user exists
            $user = User::where('username', $username)->first();

            // Determine if login successful (your controller should return status:true)
            $success = $response->getStatusCode() == 200;

            $loginLog = new LoginLog();
            $loginLog->username = $username;
            $loginLog->user_id = $user?->user_id ?? null;
            $loginLog->success = $success;
            $loginLog->ip_address = $request->ip();
            $loginLog->user_agent = $request->userAgent();
            $loginLog->save();
            
        }

        return $response;
    }
}
