<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class LiveTvStream extends Authenticatable
{
    use HasFactory;
    protected $table = 'live_tv_url'; // table name  
    protected $primaryKey = 'live_tv_url_id'; // custom primary key

     public function liveTv()
     {
         return $this->belongsTo(LiveTv::class, 'live_tv_id', 'live_tv_id');
     }
      
}
