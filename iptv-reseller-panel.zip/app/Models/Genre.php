<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Genre extends Authenticatable
{
    use HasFactory;
    protected $table = 'genre'; // table name  
    protected $primaryKey = 'genre_id'; // custom primary key

     
      
}
