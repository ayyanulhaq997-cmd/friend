<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Subscription extends Authenticatable
{
    use HasFactory;
    
    protected $table = 'subscription'; // table name

    protected $primaryKey = 'subscription_id';

    
    
}
