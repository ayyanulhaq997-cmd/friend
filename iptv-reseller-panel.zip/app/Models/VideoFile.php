<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class VideoFile extends Authenticatable
{
    use HasFactory;
    protected $table = 'video_file'; // table name  
    protected $primaryKey = 'video_file_id'; // custom primary key

    public $incrementing = true;
    protected $keyType = 'int';
    // Inverse relationship
    public function video()
    {
          return $this->belongsTo(Video::class, 'videos_id', 'videos_id');
    }

    
    
}
