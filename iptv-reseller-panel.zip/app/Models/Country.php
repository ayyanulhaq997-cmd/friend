<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Country extends Authenticatable
{
    use HasFactory;
    protected $table = 'country'; // table name  
    protected $primaryKey = 'country_id'; // custom primary key

     
      
}
