<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Star extends Authenticatable
{
    use HasFactory;
    protected $table = 'star'; // table name  
    protected $primaryKey = 'star_id'; // custom primary key

     
      
}
