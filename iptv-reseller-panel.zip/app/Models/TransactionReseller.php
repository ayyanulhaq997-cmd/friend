<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class TransactionReseller extends Authenticatable
{
    use HasFactory;

    protected $table = 'transaction_reseller'; // table name

    protected $fillable = [
        'sender_id',
        'receiver_id',
        'date',
        'credit_amount',
        'username',
        'description',
    ];
    // 🔗 Relation: a subscriber belongs to a reseller

}
