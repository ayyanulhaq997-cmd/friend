<?php

namespace App\Models;

use AWS\CRT\Log;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Video extends Authenticatable
{
    use HasFactory;
    protected $table = 'videos'; // table name  
    protected $primaryKey = 'videos_id'; // custom primary key


    public $incrementing = true;
    protected $keyType = 'int';

    protected $hidden = ['viewLogs', 'file', 'favorites'];

    public function file()
    {
        return $this->hasOne(VideoFile::class, 'videos_id', 'videos_id');
    }

    public function viewLogs()
    {
        return $this->hasMany(MovieViewLog::class, 'movie_id', 'videos_id');
    }

    public function favorites()
    {
        return $this->hasMany(FavoriteMovie::class, 'movie_id', 'videos_id');
    }

    public function trailler()
    {
        return $this->hasOne(MovieTrailer::class, 'videos_id', 'videos_id');
    }

    public function viewedByUsers()
    {
        return $this->belongsToMany(
            User::class,
            'movie_view_logs',
            'movie_id',   // pivot column referencing videos_id
            'user_id'     // pivot column referencing user_id
        )
            ->withPivot(['last_position', 'views', 'viewed_at']);
    }

    protected static $genreMap = null;

    // Load genre map only once
    protected static function loadGenreMap()
    {
        if (static::$genreMap === null) {
            static::$genreMap = Genre::pluck('name', 'genre_id')->toArray();  // 1 query only
        }
    }

    protected $appends = ['released_year', 'genre_names', 'bg_url', 'card_url', 'last_position', 'viewed', 'favorite', 'video_url', 'type', 'audio_tracks', 'actors','countries'];
    public function getReleasedYearAttribute()
    {
        return substr($this->release, 0, 4);
    }

    public function getGenreNamesAttribute()
    {
        static::loadGenreMap();

        $ids = array_filter(explode(',', $this->genre));

        $names = array_filter(array_map(function ($id) {
            return static::$genreMap[(int)$id] ?? null;
        }, $ids));

        return implode(' - ', $names);     // <-- return as "Action, Comedy, Drama"
    }

    public function getBgUrlAttribute()
    {
        return basename($this->poster) ? config('constants.tmdb_image_original') . basename($this->poster) : null;
    }

    public function getCardUrlAttribute()
    {
        return basename($this->thumbnail) ? config('constants.tmdb_image_w342') . basename($this->thumbnail) : null;
    }

    public function getLastPositionAttribute()
    {
        // get the first log of the loaded relation
        return $this->viewLogs->first()?->last_position;
    }

    public function getViewedAttribute()
    {
        return $this->viewLogs->isNotEmpty();
    }

    public function getFavoriteAttribute()
    {
        return $this->favorites->isNotEmpty();
    }

    public function getVideoUrlAttribute()
    {
        return $this->file ? $this->file->file_url : '';
    }

    public function getTypeAttribute()
    {
        return $this->file ? $this->file->source_type : '';
    }

    public function getAudioTracksAttribute()
    {
        // todo : what is it type? array or string
        return $this->file ? $this->file->audio_tracks : '';
    }
    public function getActorsAttribute()
    {
        $actor_list = explode(",", $this->stars);
        $actors = Star::select('star_id as actor_id', 'star_name as actor_name', 'profile_path')
                    ->whereIn('star_id', $actor_list)
                    ->limit(5)
                    ->get();
        $actors = $actors->map(function ($actor) {
            $actor->profile_path = config('constants.tmdb_image_w342')
                . basename($actor->profile_path);
            return $actor;
        });
        return $actors;
    }

    public function getCountriesAttribute(){
        $country_list = explode(",", $this->country);
        $countries = Country::select('country_id', 'name', 'iso_3166_1')->whereIn('country_id', $country_list)->get();
        return $countries;
    }
}
