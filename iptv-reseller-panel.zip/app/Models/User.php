<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\HasApiTokens;
use Carbon\Carbon;
class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable, HasApiTokens;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */

    protected $table = 'user';
    protected $primaryKey = 'user_id';

    public $timestamps = false;
    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */


    public function subresellers()
    {
        return $this->hasMany(User::class, 'parent_id', 'user_id');
    }
    // Relationship: user has many credit logs where they are receiver
    public function receivedCredits()
    {
        return $this->hasMany(Credits::class, 'receiver_id', 'user_id');
    }
    //Computed attribute for total credit
    protected function credit(): Attribute
    {
        return Attribute::get(fn() => $this->receivedCredits()->sum('amount'));
    }

    //Caculated attribute for max end date
    

    protected function latestSubscriptionEndDate(): Attribute
    {
        return Attribute::get(function () {
            $date = DB::table('subscription')
                ->where('user_id', $this->user_id)
                ->where('status', 1)
                ->max('end_date');

            return $date ? Carbon::parse($date) : null;
        });
    }


    protected function parentMember(): Attribute
    {
        return Attribute::get(function () {
            return $this->belongsTo(User::class, 'parent_id', 'user_id')->first();
        });
    }

    public function movieViewLogs()
    {
        return $this->hasMany(MovieViewLog::class, 'user_id', 'user_id');
    }

    public function favoriteMovies()
    {
        return $this->hasMany(FavoriteMovie::class, 'user_id', 'user_id');
    }

    public function watchedMovies()
    {
        return $this->belongsToMany(
            Video::class,
            'movie_view_logs',   // pivot table
            'user_id',           // user_id in pivot
            'movie_id'           // movie_id in pivot referencing videos_id
        )
            ->withPivot(['last_position', 'views', 'viewed_at']);
    }


    //Make 'credit' automatically appear in JSON / array outputs
    protected $appends = ['credit', 'latest_subscription_end_date', 'parent_member'];
}
