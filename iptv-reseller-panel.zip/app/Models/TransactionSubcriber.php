<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class TransactionSubcriber extends Authenticatable
{
    use HasFactory;

    protected $table = 'transaction_subcriber'; // table name

    protected $fillable = [
        'sender_id',
        'receiver_id',
        'date',
        'credit_amount',
        'username',
        'description',
    ];
    // 🔗 Relation: a subscriber belongs to a reseller

}
