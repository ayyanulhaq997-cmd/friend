<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class Series extends Model
{
    //
    public function seasons()
    {
        return $this->hasMany(Season::class);
    }
    public function episodes()
    {
        return $this->hasMany(Episode::class);
    }

    public function viewLogs()
    {
        return $this->hasMany(TvViewLog::class, 'series_id', 'id');
    }

    public function favorites()
    {
        return $this->hasMany(FavoriteTv::class, 'series_id', 'id');
    }

    protected static $genreMap = null;

    protected $hidden = ['viewLogs','favorites','backdrop','thumbnail','genre','release'];

    // Load genre map only once
    protected static function loadGenreMap()
    {
        if (static::$genreMap === null) {
            static::$genreMap = Genre::pluck('name', 'genre_id')->toArray();  // 1 query only
        }
    }

    protected $appends = ['released_year', 'genre_names','viewed','favorite', 'bg_url','card_url','rating','actors'];
    public function getReleasedYearAttribute()
    {
        return substr($this->release, 0, 4);
    }
    public function getRatingAttribute()
    {
        return substr($this->vote_average, 0, 4);
    }

    public function getGenreNamesAttribute(){
        static::loadGenreMap();

        $ids = array_filter(explode(',', $this->genre));

        $names = array_filter(array_map(function ($id) {
            return static::$genreMap[(int)$id] ?? null;
        }, $ids));

        return implode(', ', $names);     // <-- return as "Action, Comedy, Drama"
    }

    public function getLastPositionAttribute()
    {
        // get the first log of the loaded relation
        return $this->viewLogs->first()?->last_position;
    }

    public function getViewedAttribute()
    {
        return $this->viewLogs->isNotEmpty();
    }

    public function getFavoriteAttribute()
    {
        return $this->favorites->isNotEmpty();
    }
    public function getActorsAttribute()
    {
        $actor_list = explode(",", $this->stars);
        $actors = Star::select('star_id as actor_id', 'star_name as actor_name', 'profile_path')
                        ->whereIn('star_id', $actor_list)
                        ->limit(5)
                        ->get();
        $actors = $actors->map(function ($actor) {
            $actor->profile_path = config('constants.tmdb_image_w342')
                . basename($actor->profile_path);
            return $actor;
        });
        return $actors;
    }
    public function getBgUrlAttribute(){
        return basename($this->backdrop) ? config('constants.tmdb_image_original') . basename($this->backdrop) : null;
    }
    
    public function getCardUrlAttribute(){
        return basename($this->thumbnail) ? config('constants.tmdb_image_w342') . basename($this->thumbnail) : null;
    }
}
