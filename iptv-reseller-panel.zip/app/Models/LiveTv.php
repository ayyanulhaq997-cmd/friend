<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class LiveTv extends Authenticatable
{
    use HasFactory;
    protected $table = 'live_tv'; // table name  
    protected $primaryKey = 'live_tv_id'; // custom primary key
    protected $appends = ['url'];
    public function streams()
    {
        return $this->hasMany(LiveTvStream::class, 'live_tv_id', 'live_tv_id');
    }

    public function getUrlAttribute()
    {
        return $this->streams()->value('url'); // returns first url
    }
    public function stream()
    {
        return $this->hasOne(LiveTvStream::class)
            ->select('live_tv_id', 'url');   // only return url
    }
}
