<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Subscriber extends Authenticatable
{
    use HasFactory;

    protected $table = 'subscribers'; // table name

    protected $fillable = [
        'name',
        'email',
        'password',
        'phone_number',
        'username',
        'active',
        'duration',
        'start_date',
        'expiration_date',
        'package',
        'reseller_id',
    ];
    // 🔗 Relation: a subscriber belongs to a reseller
    public function reseller()
    {
        return $this->belongsTo(User::class, 'reseller_id');
    }
}
