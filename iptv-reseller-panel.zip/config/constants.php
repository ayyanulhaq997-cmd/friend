<?php

return [
    'tmdb_image_w342' => 'https://image.tmdb.org/t/p/w500/',
    'tmdb_image_original' => 'https://image.tmdb.org/t/p/original/',
    'movie_count_on_app_list' => 2,
];