<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('movie_trailers', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('movie_id');     // Foreign key to your movies table
            $table->string('trailer_url')->nullable();              // YouTube, MP4, etc.
            $table->string('poster_path')->nullable();              // 
            $table->string('thumbnail')->nullable();              // 
            $table->string('source')->nullable();       // YouTube, Vimeo, TMDB
            $table->string('quality')->nullable();      // 1080p, 720p, etc.
            $table->string('language')->nullable();     // en, es, ar, etc.
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('movie_trailers');
    }
};
