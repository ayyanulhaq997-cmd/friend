<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('credit_packages', function (Blueprint $table) {
            $table->id();
            $table->string('name');                   // e.g., "100 Credits"
            $table->integer('credits')->default(0);   // number of credits
            $table->decimal('price_usd', 10, 2);      // price in USD
            $table->decimal('credit_value', 5, 2);    // price per credit ($0.10)
            $table->integer('valid_days')->default(30); // validity duration
            $table->text('description')->nullable();  // optional description
            $table->boolean('instant_activation')->default(true); // checkbox
            $table->boolean('all_channels_access')->default(true); // checkbox
            $table->boolean('email_support')->default(true); // checkbox
            $table->string('features')->nullable(); // text summary or small list
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('credit_packages');
    }
};
