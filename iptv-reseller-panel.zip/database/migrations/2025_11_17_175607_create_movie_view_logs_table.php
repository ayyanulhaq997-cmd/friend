<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('movie_view_logs', function (Blueprint $table) {
            $table->id();

            // user who viewed the movie
            $table->unsignedBigInteger('user_id')->nullable()->index();

            // movie
            $table->unsignedBigInteger('movie_id')->index();

            // last viewed second — useful for resume playback
            $table->integer('last_position')->default(0);

            // device type
            $table->string('device')->nullable(); // like android_tv, mobile, web

            // ip address of the viewer
            $table->string('ip_address', 45)->nullable();

            // count how many times played
            $table->integer('views')->default(1);

            // datetime the movie was viewed
            $table->timestamp('viewed_at')->useCurrent();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('movie_view_logs');
    }
};

