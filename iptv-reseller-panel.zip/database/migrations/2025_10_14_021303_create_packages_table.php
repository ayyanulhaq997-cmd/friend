<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('packages', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->enum('type', ['live', 'vod', 'mixed'])->default('live');
            $table->integer('duration_days')->default(30);
            $table->decimal('credit_cost', 8, 2)->default(0);
            $table->decimal('price_usd', 10, 2)->nullable();
            $table->integer('channels_count')->nullable();
            $table->integer('vod_count')->nullable();
            $table->string('logo')->nullable();
            $table->boolean('is_trial')->default(false);
            $table->integer('devices')->nullable(); // new field
            $table->string('gradient')->nullable(); // for background color or gradient
            $table->boolean('popular')->nullable(); // mark as popular
            $table->string('features')->nullable(); // text summary or small list
            $table->integer('created_by')->nullable();
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->foreign('created_by')->references('user_id')   // must match PK in user table
                ->on('user')
                ->onDelete('set null');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('packages');
    }
};
