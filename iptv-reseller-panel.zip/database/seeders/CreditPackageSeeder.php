<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\CreditPackage;

class CreditPackageSeeder extends Seeder
{
    public function run(): void
    {
        $packages = [
            [
                'name' => '100 Credits',
                'credits' => 100,
                'price_usd' => 10.00,
                'credit_value' => 0.10,
                'valid_days' => 30,
                'description' => 'Perfect for testing',
                'instant_activation' => true,
                'all_channels_access' => true,
                'email_support' => true,
                'status' => 'active',
            ],
            [
                'name' => '250 Credits',
                'credits' => 250,
                'price_usd' => 22.50,
                'credit_value' => 0.09,
                'valid_days' => 60,
                'description' => 'Best value for regular users',
                'instant_activation' => true,
                'all_channels_access' => true,
                'email_support' => true,
                'status' => 'active',
            ],
            [
                'name' => '500 Credits',
                'credits' => 500,
                'price_usd' => 40.00,
                'credit_value' => 0.08,
                'valid_days' => 90,
                'description' => 'For heavy users',
                'instant_activation' => true,
                'all_channels_access' => true,
                'email_support' => true,
                'status' => 'active',
            ],
        ];

        foreach ($packages as $data) {
            CreditPackage::updateOrCreate(['name' => $data['name']], $data);
        }

        $this->command->info('✅ Credit packages created successfully.');
    }
}
