<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Package;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        

        // 3️⃣ Create IPTV Packages (Bouquets)
        $packages = [
            [
                'name' => 'USA Live TV',
                'description' => 'All American channels like ABC, CBS, FOX, NBC, HBO, etc.',
                'type' => 'live',
                'duration_days' => 30,
                'credit_cost' => 1.00,
                'price_usd' => 5.00,
                'channels_count' => 450,
                'vod_count' => 0,
                'logo' => 'usa.png',
                'is_trial' => false,
                'status' => 'active',
                'created_by' => 1,
            ],
            [
                'name' => 'UK Live TV',
                'description' => 'Includes BBC, ITV, Sky Sports, and more.',
                'type' => 'live',
                'duration_days' => 30,
                'credit_cost' => 1.00,
                'price_usd' => 5.00,
                'channels_count' => 380,
                'vod_count' => 0,
                'logo' => 'uk.png',
                'is_trial' => false,
                'status' => 'active',
                'created_by' => 1,
            ],
            [
                'name' => 'Sports Only',
                'description' => 'Dedicated sports package with ESPN, beIN Sports, TSN, etc.',
                'type' => 'live',
                'duration_days' => 30,
                'credit_cost' => 0.80,
                'price_usd' => 4.00,
                'channels_count' => 90,
                'vod_count' => 0,
                'logo' => 'sports.png',
                'is_trial' => false,
                'status' => 'active',
                'created_by' => 1,
            ],
            [
                'name' => 'VOD + Live Mix',
                'description' => 'Access to both live channels and VOD content.',
                'type' => 'mixed',
                'duration_days' => 30,
                'credit_cost' => 1.20,
                'price_usd' => 6.00,
                'channels_count' => 300,
                'vod_count' => 800,
                'logo' => 'mixed.png',
                'is_trial' => false,
                'status' => 'active',
                'created_by' => 1,
            ],
            [
                'name' => 'VOD Only',
                'description' => 'Movies and Series on demand only.',
                'type' => 'vod',
                'duration_days' => 30,
                'credit_cost' => 0.70,
                'price_usd' => 3.00,
                'channels_count' => 0,
                'vod_count' => 1000,
                'logo' => 'vod.png',
                'is_trial' => false,
                'status' => 'active',
                'created_by' => 1,
            ],
            [
                'name' => 'Trial Package',
                'description' => '24-hour free trial access to selected channels.',
                'type' => 'mixed',
                'duration_days' => 1,
                'credit_cost' => 0.00,
                'price_usd' => 0.00,
                'channels_count' => 50,
                'vod_count' => 20,
                'logo' => 'trial.png',
                'is_trial' => true,
                'status' => 'active',
                'created_by' => 1,
            ],
        ];

        foreach ($packages as $data) {
            Package::create($data);
        }

        $this->command->info('✅ Database seeding completed successfully!');
    }
}
