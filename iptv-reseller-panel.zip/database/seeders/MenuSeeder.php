<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Menu;
class MenuSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run()
{
    $menus = [
        [
            'uid' => 'home',
            'title' => 'Home',
            'icon' => 'Home',
            'href' => '/dashboard',
        ],

        [
            'uid' => 'reseller',
            'title' => 'Reseller',
            'icon' => 'UserCheck',
            'expanded' => true,
            'children' => [
                [ 'uid' => 'add-resellers', 'title' => 'Add Reseller', 'href' => '/resellers/create' ],
                [ 'uid' => 'all-reseller', 'title' => 'All Reseller', 'href' => '/resellers/index' ],
            ]
        ],

        [
            'uid' => 'subreseller',
            'title' => 'Subreseller',
            'icon' => 'UserPlus',
            'expanded' => true,
            'children' => [
                [ 'uid' => 'all-subreseller', 'title' => 'All Subbeseller', 'href' => '/subresellers/create' ],
                [ 'uid' => 'add-subreseller', 'title' => 'Add Subbeseller', 'href' => '/subresellers/index' ],
            ]
        ],

        [
            'uid' => 'users',
            'title' => 'Users',
            'icon' => 'Users',
            'expanded' => true,
            'children' => [
                [ 'uid' => 'add-user', 'title' => 'Add User', 'href' => '/customers/create' ],
                [ 'uid' => 'all-users', 'title' => 'All Users', 'href' => '/customers/index' ],
                [ 'uid' => 'test-users', 'title' => 'Test Users', 'href' => '/customers/index?type=test' ],
                [ 'uid' => 'premium-users', 'title' => 'Premium Users', 'href' => '/customers/index?type=premium' ],
            ]
        ],

        [
            'uid' => 'channel',
            'title' => 'Channel',
            'icon' => 'TvMinimalPlay',
            'expanded' => true,
            'children' => [
                [ 'uid' => 'all-channel', 'title' => 'All Channels', 'href' => '/channels/index' ],
            ]
        ],

        [
            'uid' => 'transactions',
            'title' => 'Transaction',
            'icon' => 'Coins',
            'href' => '/transactions/index',
        ],

        [
            'uid' => 'import',
            'title' => 'Search and Import',
            'icon' => 'Search',
            'href' => '/movie_vod/import',
        ],

        [
            'uid' => 'movie_vod',
            'title' => 'Movie/VOD',
            'icon' => 'PlayCircle',
            'href' => '/movie_vod/index',
        ],

        [
            'uid' => 'series',
            'title' => 'Series',
            'icon' => 'Tv',
            'href' => '/series/index',
        ],

        [
            'uid' => 'movie_match',
            'title' => 'Movie Match',
            'icon' => 'CheckSquare',
            'href' => '/movie_match/index',
        ],
    ];

    foreach ($menus as $menu) {
        $children = $menu['children'] ?? [];
        unset($menu['children']);

        $parent = Menu::create($menu);

        foreach ($children as $child) {
            $child['parent_id'] = $parent->id;
            Menu::create($child);
        }
    }
}

}
