<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import Header from '@/Layouts/Header.vue';
import { ref, onMounted, computed } from 'vue';
import Chart from 'chart.js/auto';
import { Head, usePage } from '@inertiajs/vue3';
const animateStats = ref(false);
const revenueChart = ref(null);
const subscriptionChart = ref(null);
const homeData = ref(usePage().props.data || []);
console.log(homeData.value);

// Icons as SVG strings
const icons = {
  users: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>',
  creditCard: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg>',
  alertCircle: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>',
  dollarSign: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>',
  checkCircle: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>',
  clock: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>',
  activity: '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>'
};

// Sample data - replace with your Laravel API data
const stats = ref({
  totalUsers: homeData.value.users,  
  activeAccounts: homeData.value.activate_users,
  expiringSoon: homeData.value.expire_soon_count,
  expiredUsers: homeData.value.expired_users,
  trialAccounts: homeData.value.trial_users,
});

const mainStats = computed(() => [
  {
    title: 'Total Users',
    value: stats.value.totalUsers.toLocaleString(),
    color: 'bg-blue-500',
    icon: icons.users
  },  
  {
    title: 'Expiring Soon',
    value: stats.value.expiringSoon,
    color: 'bg-red-500',
    icon: icons.users
  }
]);

const accountStats = ref([
  {
    type: 'active',
    label: 'Active Accounts',
    count: stats.value.activeAccounts,
    percentage: stats.value.totalUsers>0 ? (100*stats.value.activeAccounts/(stats.value.totalUsers)).toFixed(0) : 0,
    icon: icons.checkCircle,
    bgColor: 'bg-green-100',
    iconColor: 'text-green-600',
    barColor: 'bg-green-500'
  },
  {
    type: 'expired',
    label: 'Expired Accounts',
    count: stats.value.expiredUsers,
    percentage: stats.value.totalUsers>0 ? (100*stats.value.expiredUsers/(stats.value.totalUsers)).toFixed(0) : 0,
    icon: icons.clock,
    bgColor: 'bg-yellow-100',
    iconColor: 'text-yellow-600',
    barColor: 'bg-yellow-500'
  },
  {
    type: 'trial',
    label: 'Trial Accounts',
    count: stats.value.trialAccounts,
    percentage: stats.value.totalUsers>0 ? (100*stats.value.trialAccounts/(stats.value.totalUsers)).toFixed(0) : 0,
    icon: icons.activity,
    bgColor: 'bg-purple-100',
    iconColor: 'text-purple-600',
    barColor: 'bg-purple-500'
  }
]);





const initCharts = () => {
  // Revenue Chart  
  // Subscription Chart
  if (subscriptionChart.value) {
    new Chart(subscriptionChart.value, {
      type: 'doughnut',
      data: {
        labels: ['Active', 'Expired', 'Trial'],
        datasets: [{
          data: [stats.value.activeAccounts, stats.value.expiredUsers, stats.value.trialAccounts],
          backgroundColor: ['#10b981', '#f59e0b', '#8b5cf6'],
          borderWidth: 0,
          hoverOffset: 10
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              padding: 20,
              font: {
                size: 12
              }
            }
          },
          tooltip: {
            backgroundColor: 'white',
            titleColor: '#1f2937',
            bodyColor: '#6b7280',
            borderColor: '#e5e7eb',
            borderWidth: 1,
            padding: 12
          }
        }
      }
    });
  }
};

// Fetch data from Laravel API
const fetchDashboardData = async () => {
  try {
    // Uncomment and modify this to use your Laravel API
    // const response = await fetch('/api/dashboard/stats');
    // const data = await response.json();
    // stats.value = data;
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
  }
};

onMounted(() => {
  animateStats.value = true;
  initCharts();
  fetchDashboardData();
});


</script>

<template>

  
  <AuthenticatedLayout title="Dashboard" desc="" >

      

      <!-- Stats Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div v-for="(stat, index) in mainStats" :key="index"
          class="bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 transform"
          :class="animateStats ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'"
          :style="{ transitionDelay: `${index * 100}ms` }">
          <div class="flex items-center justify-between">
            <div>
              <p class="text-sm text-gray-500 font-medium mb-1">{{ stat.title }}</p>
              <p class="text-3xl font-bold text-gray-800">{{ stat.value }}</p>
            </div>
            <div :class="`p-4 rounded-xl ${stat.color}`" v-html="stat.icon"></div>
          </div>
        </div>
      </div>

      <!-- Account Status Cards -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div v-for="account in accountStats" :key="account.type"
          class="bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300">
          <div class="flex items-center mb-4">
            <div :class="`p-3 rounded-lg mr-3 ${account.bgColor}`">
              <div :class="`w-6 h-6 ${account.iconColor}`" v-html="account.icon"></div>
            </div>
            <div>
              <p class="text-sm text-gray-500">{{ account.label }}</p>
              <p class="text-2xl font-bold text-gray-800">{{ account.count }}</p>
            </div>
          </div>
          <div class="w-full bg-gray-200 rounded-full h-2">
            <div :class="`h-2 rounded-full ${account.barColor}`" :style="{ width: account.percentage + '%' }"></div>
          </div>
        </div>
      </div>

      <!-- Charts Section -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <!-- Revenue Trend -->        

        <!-- Subscription Status -->
        <div class="bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300">
          <h2 class="text-xl font-bold text-gray-800 mb-6">Subscription Status</h2>
          <canvas ref="subscriptionChart" class="w-full" style="max-height: 300px;"></canvas>
        </div>
      </div>
    

  </AuthenticatedLayout>
</template>
