<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed } from 'vue';
import { Inertia } from '@inertiajs/inertia'
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions
import { Edit2, PlusCircle,Trash2  } from 'lucide-vue-next'
const { props } = usePage()
const user = props.auth.user
// Get data from backend
const { users } = usePage().props
const searchTerm = ref('');
const hoveredRow = ref(null);
const resellers = ref(users || []); // Assuming users.list is passed from the backend
const showModal = ref(false);
const showAddCreditModal = ref(false);
const selectedResellerId = ref(null);
const selectedReseller = ref(null);

const addCreditData = ref({
    user_id: '',
    credit: 1,
});

const filteredCustomers = computed(() => {
    const term = searchTerm.value.toLowerCase();

    return resellers.value.filter(reseller =>
        reseller.name.toLowerCase().includes(term) ||
        reseller.email.toLowerCase().includes(term) ||
        reseller.username.toLowerCase().includes(term) ||
        reseller.phone.toLowerCase().includes(term)
    );
});

const handleEdit = (id) => {
    if (!user.is_manager) {
        showError('Managers are not allowed to add new customers.') // ❌ show error toast
        return;
    }
    Inertia.visit('/resellers/edit/' + id);
    // Add your edit logic here
};

const handleDelete = (id) => {
    if (!user.is_manager) {
        showError('Managers are not allowed to add new customers.') // ❌ show error toast
        return;
    }
    selectedResellerId.value = id;
    showModal.value = true;

};

const handleAddCredit = (item) => {
    if (!user.is_manager) {
        showError('Managers are not allowed to add new customers.') // ❌ show error toast
        return;
    }
    selectedReseller.value = item;
    addCreditData.user_id = item.user_id;
    showAddCreditModal.value = true;
}

const handleAddNew = () => {
    if (!user.is_manager) {
        showError('Managers are not allowed to add new customers.') // ❌ show error toast
        return;
    }
    Inertia.visit('/resellers/create');
    // Add your add new reseller logic here
};

async function confirmDelete() {
    try {
        const response = await fetch('/resellers/delete/' + selectedResellerId.value, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json();
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            resellers.value = resellers.value.filter(function (row) {
                return row.user_id != selectedResellerId.value;
            })
            showModal.value = false;
        }
        else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        showError(error) // ❌ show error toast
    }
    showModal.value = false
}

async function confirmAddCredit() {

    addCreditData.value.user_id = selectedReseller.value.user_id;
    try {
        const response = await fetch('/resellers/add/credit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: JSON.stringify(addCreditData.value)
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json();
        if (data.success) {
            resellers.value.forEach(row => {
                if (row.user_id === selectedReseller.value.user_id) {
                    row.credit = Number(row.credit) + Number(addCreditData.value.credit);
                }
            });
            showSuccess(data.message) // ✅ show success toast
            showAddCreditModal.value = false;
        }
        else {
            showError(data.message) // ❌ show error toast
        }

    } catch (error) {
        showError(error) // ❌ show error toast
    }
    showModal.value = false
}

</script>

<template>

    <Head title="Reseller" />

    <AuthenticatedLayout title="Reseller" desc="List of resellers" >


            <div class="mx-auto">
                <div class="overflow-hidden bg-white shadow-sm rounded-lg">

                    <div class="min-h-screen bg-gray-50">
                        <div class="mx-auto">
                            <div class="bg-white rounded-lg shadow-sm">
                                <!-- Header -->
                                <div class="flex justify-between items-center p-4">
                                    <div class="relative">
                                        <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5"
                                            fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                        </svg>
                                        <input type="text" placeholder="Search..." v-model="searchTerm"
                                            class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                                    </div>
                                </div>

                                <!-- Table -->
                                <div class="overflow-x-auto px-4">
                                    <table class="w-full">
                                        <thead>
                                            <tr class="border-b border-gray-200">     
                                                <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                                    No</th>                                          
                                                <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                                    User Name</th>
                                                <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                                    Manager</th>

                                                <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                                    Balance</th>                                                
                                                <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                                    Status</th>
                                                <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                                    Role</th>

                                                <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                                    Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-for="(reseller, index) in filteredCustomers" :key="reseller.id"
                                                class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                                @mouseenter="hoveredRow = reseller.id" @mouseleave="hoveredRow = null">
                                                <td class="px-4 py-2 text-sm text-gray-800">{{ index + 1 }}</td>
                                                <td class="px-4 py-2 text-sm text-gray-800">{{ reseller.username }}
                                                </td>
                                                <td class="px-4 py-2 text-sm text-gray-800">{{ reseller.parent_member ?
                                                    reseller.parent_member.username : 'N/A' }}
                                                </td>
                                                <td class="px-4 py-2 text-sm text-gray-800">{{ reseller.credit }}
                                                </td>
                                                <td class="px-4 py-2 text-sm text-gray-800">
                                                    <span
                                                        :class="reseller.status ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full">
                                                        {{ reseller.status ? 'Active' : 'Inactive' }}
                                                    </span>
                                                </td>
                                                <td class="px-4 py-2 text-sm text-gray-800">
                                                    <span
                                                        :class="reseller.is_manager ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full">
                                                        {{ reseller.is_manager ? 'Active' : 'Inactive' }}
                                                    </span>
                                                </td>
                                                <td class="px-4 py-2">
                                                    <div class="flex gap-2">
                                                        <button
                                                            class="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                                                            title="Edit" @click="handleEdit(reseller.user_id)">
                                                            <Edit2 class="w-5 h-5" />
                                                        </button>

                                                        <button
                                                            class="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                                                            title="Add Credit" @click="handleAddCredit(reseller)">
                                                            <PlusCircle class="w-5 h-5" />

                                                        </button>

                                                        <button
                                                            class="p-2 text-gray-400 hover:text-red-500 transition-colors"
                                                            title="Delete" @click="handleDelete(reseller.user_id)">
                                                            <Trash2  class="w-5 h-5" />
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Add New Button -->
                                <div class="flex justify-center p-8">
                                    <button
                                        class="px-8 py-3 border-2 border-orange-400 text-orange-400 rounded-full font-medium hover:bg-orange-50 transition-colors"
                                        @click="handleAddNew">
                                        Add New
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        <!-- Delete Modal Background -->
        <div v-if="showModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <!-- Modal Box -->
            <div class="bg-white rounded-2xl shadow-lg p-6 w-[90%] max-w-md animate-fade-in">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">
                    Confirm Delete
                </h2>
                <p class="text-gray-600 mb-6">
                    Are you sure you want to delete this item? This action cannot be undone.
                </p>

                <div class="flex justify-end space-x-3">
                    <button @click="showModal = false"
                        class="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100">
                        Cancel
                    </button>
                    <button @click="confirmDelete" class="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </div>
        </div>

        <!-- Add Credit Modal Background -->
        <div v-if="showAddCreditModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <!-- Modal Box -->
            <div class="bg-white rounded-2xl shadow-lg p-6 w-[90%] max-w-md animate-fade-in">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">
                    Add Credit to <span class="text-red-600 text-2xl">{{ selectedReseller.username || '' }}</span>
                </h2>
                <p class="text-gray-600 mb-6">
                    <input v-model="addCreditData.credit" type="number"
                        class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                </p>

                <div class="flex justify-end space-x-3">
                    <button @click="showAddCreditModal = false"
                        class="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100">
                        Cancel
                    </button>
                    <button @click="confirmAddCredit"
                        class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
                        Add
                    </button>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>



<style scoped>
/* Add any custom styles here if needed */
</style>
