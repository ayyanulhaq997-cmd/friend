<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed } from 'vue';
import { CornerDownLeft, Save,X } from 'lucide-vue-next'
import { Inertia } from '@inertiajs/inertia'
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions
const flagEdit = ref(false);
const user = ref(usePage().props.user);
const credits = ref(usePage().props.credits);


const formData = ref({
    user_id: user.value.user_id || '',
    name: user.value.name || '',
    username: user.value.username || '',
    email: user.value.email || '',
    phone: user.value.phone || '',
    credit: user.value.credit || '',
    status: user.value.status,
    is_manager: user.value.is_manager,
});

async function handleSubmit() {
    try {
        const response = await fetch('/resellers/update/' + user.value.user_id, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: JSON.stringify(formData.value)
        })

        if (!response.ok) throw new Error('Failed to save user')
        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            flagEdit.value = false;
        } else {
            showError(data.message) // ❌ show error toast
        }

    } catch (error) {
        console.error('❌ Error saving user:', error)
        showError('Error saving user.') // ❌ show error toast
    }
};
const handleEdit = () => {
    flagEdit.value = true;
}

const goToPrev = () =>{
    Inertia.visit('/resellers/index/');
}
</script>

<template>

    <Head title="Reseller" />
    <AuthenticatedLayout title="Reseller" desc="Edit a reseller">


            <div class="mx-auto">
                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                    <div class=" rounded-lg shadow-sm  p-6 items-center">
                        <table class="w-full">
                            <thead>
                                <tr class="border-b border-gray-200">                                                                   
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        User Name</th>                                  
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Balance</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Status</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Role</th>        
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                    @mouseenter="hoveredRow = formData.user_id" @mouseleave="hoveredRow = null">
                                    
                                    <td v-if="!flagEdit" class="px-6 py-4 text-lg text-gray-800">{{ formData.username }}
                                    </td>
                                    <td v-else class="px-6 py-4 text-sm text-gray-800">
                                        <input v-model="formData.username" type="text"
                                            class="w-50 px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                                    </td>                                    
                                    <td  class="px-6 py-4 text-lg text-gray-800">{{ formData.credit }}
                                    </td>
                                    <td v-if="!flagEdit" class="px-6 py-4 text-lg text-gray-800">
                                        <span
                                            :class="formData.status ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full">
                                            {{ formData.status ? 'Active' : 'Inactive' }}
                                        </span>
                                    </td>
                                    <td v-else class="px-6 py-4 text-sm text-gray-800">
                                        <button type="button" @click="formData.status = !formData.status" :class="[
                                            'relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 align-bottom',
                                            formData.status ? 'bg-green-500' : 'bg-gray-300'
                                        ]">
                                            <span :class="[
                                                'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                                                formData.status ? 'translate-x-6' : 'translate-x-1'
                                            ]" />
                                        </button>
                                    </td>

                                    <td v-if="!flagEdit" class="px-6 py-4 text-lg text-gray-800">
                                        <span
                                            :class="formData.is_manager ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full">
                                            {{ formData.is_manager ? 'Active' : 'Inactive' }}
                                        </span>
                                    </td>
                                    <td v-else class="px-6 py-4 text-sm text-gray-800">
                                        <button type="button" @click="formData.is_manager = !formData.is_manager" :class="[
                                            'relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 align-bottom',
                                            formData.is_manager ? 'bg-green-500' : 'bg-gray-300'
                                        ]">
                                            <span :class="[
                                                'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                                                formData.is_manager ? 'translate-x-6' : 'translate-x-1'
                                            ]" />
                                        </button>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="flex gap-2">
                                            <button v-if="!flagEdit"
                                                class="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                                                title="Edit" @click="handleEdit(formData.user_id)">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2"
                                                        d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                                </svg>
                                            </button>
                                            <button v-else
                                                class="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                                                title="Save" @click="handleSubmit">
                                                 <Save class="w-6 h-6 text-green-500 hover:text-green-600 cursor-pointer" />

                                            </button>
                                            <!-- <button v-if="!flagEdit"
                                                class="p-2 text-gray-400 hover:text-red-500 transition-colors"
                                                title="Delete" @click="handleDelete(formData)">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2"
                                                        d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                </svg>
                                            </button> -->
                                            <button v-if="flagEdit"
                                                class="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                                                title="Cancel" @click="flagEdit = false">
                                                  <X class="w-6 h-6 text-red-500 hover:text-red-600 cursor-pointer" />

                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="w-full mt-10">
                           <span
                                :class="formData.credit > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                                class="px-4 py-4 inline-flex  leading-5 font-semibold rounded-full">
                                CREDIT HISTORY
                            </span>
                        </div>
                        <table class="w-full">
                            <thead>
                                <tr class="border-b border-gray-200">
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        No</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Date</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Amount</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Note</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(credit, index) in credits" :key="credit.id"
                                    class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                    @mouseenter="hoveredRow = credit.id" @mouseleave="hoveredRow = null">
                                    <td class="px-6 py-4 text-sm text-gray-800">{{ index + 1 }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-800">{{ new
                                        Date(credit.date).toLocaleString() || '' }}
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-800">{{ credit.amount }}
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-800">
                                    </td>

                                </tr>
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
    </AuthenticatedLayout>
</template>



<style scoped>
/* Add any custom styles here if needed */
</style>
