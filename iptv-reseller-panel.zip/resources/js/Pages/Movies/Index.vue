<template>

    <Head title="Movies" />

    <AuthenticatedLayout title="Movie" desc="MOVIE LIST">
        <div class="mx-auto">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">

                <div class="mx-auto">
                    <div>
                        <!-- Header -->
                        <div class="flex justify-between items-center p-6 ">

                            <div class="relative">
                                <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5"
                                    fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                                <input type="text" placeholder="Search..." v-model="searchTerm"
                                    class="pl-10 pr-4 py-2 border border-gray-300 rounded-l-lg w-64 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                                <!-- Search Button -->
                                <button @click="searchResult('search')"
                                    class="bg-red-500 text-white px-4 py-2 rounded-r-md hover:bg-red-600 transition-colors">
                                    SEARCH
                                </button>
                            </div>

                            <div class="relative">
                                <span class="px-4 py-4 inline-flex  leading-5 font-semibold">
                                    {{ str_search_title }}
                                </span>
                                <span :class="movies ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                                    class="px-6 py-2 inline-flex  leading-5 font-semibold rounded-full">
                                    {{ total_movies }}
                                </span>
                            </div>
                        </div>

                        <!-- Table -->
                        <div class="overflow-x-auto px-6">
                            <table class="w-full">
                                <thead>
                                    <tr class="border-b border-gray-200">
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            No</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Thumbnail</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Name</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Uploaded Date</th>

                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Preview</th>

                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-if="movies.length != 0"
                                        v-for="(movie, index) in movies.filter(m => m.video_url)" :key="movie.videos_id"
                                        class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                        @mouseenter="hoveredRow = movie.id" @mouseleave="hoveredRow = null">
                                        <td class="px-4 py-2 text-sm text-gray-800">{{ index + 1 }}</td>
                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            <img :src="movie.card_url" style="max-width: 64px" :alt="`${movie.title}`"
                                                class="lazy" />
                                        </td>
                                        <td class="px-4 py-2 text-gray-800"><b>{{ movie.title }}</b> <span>{{
                                            movie.released_year ? `(${movie.released_year})` : '' }}</span>
                                            <br>
                                            <br>
                                            <div class="flex" v-if="movie.countries">
                                                <img v-for="(country, i) in movie.countries" :key="i"
                                                    :src="`https://flagsapi.com/${country.iso_3166_1}/flat/64.png`"
                                                    :alt="country.name" :hover="country.name" class="w-6"
                                                    :class="{ 'ml-1': i !== 0 }" :title="country.name">
                                            </div>

                                        </td>
                                        <td class="px-4 py-2 text-sm text-gray-800">{{ new
                                            Date(movie.updated_at).toISOString().split('T')[0] }}</td>

                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            <div v-if="movie.video_url" class="relative group inline-block">
                                                <EyeIcon
                                                    class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                    @click="previewItem(movie)" />
                                                <span
                                                    class="absolute bottom-full mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                                                    Preview Movie
                                                </span>
                                            </div>

                                        </td>

                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            <div class="relative group inline-block">
                                                <PencilIcon
                                                    class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                    @click="editItem(movie)" />
                                                <span
                                                    class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap z-10">
                                                    Edit Movie
                                                </span>
                                            </div>
                                            <div class="relative group inline-block ml-4">
                                                <TrashIcon
                                                    class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                    @click="deleteItem(movie)" />
                                                <span
                                                    class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap z-10">
                                                    Delete Movie
                                                </span>
                                            </div>

                                        </td>


                                    </tr>
                                    <tr v-else>
                                        <td colspan="8" class="text-center my-5">No Movies</td>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- only one file input -->
                            <input type="file" ref="fileInput" @change="changeFileInput" class="hidden"
                                id="upload_file" />
                            <div v-if="uploadProgress > 0" class="mt-4 w-64">
                                <div class="bg-gray-200 rounded-full h-4 overflow-hidden">
                                    <div class="bg-purple-600 h-full transition-all duration-200"
                                        :style="{ width: uploadProgress + '%' }"></div>
                                </div>
                                <p class="text-sm mt-1">Uploading: {{ uploadProgress }}%</p>
                            </div>
                        </div>
                    </div>
                    <div class="flex items-center justify-center space-x-2 my-4">
                        <!-- Previous Button -->
                        <button @click="pagination.current > 1 && pagination.current-- && searchResult('page')"
                            :disabled="pagination.current === 1" :class="[
                                'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                pagination.current === 1
                                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                    : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:-translate-x-1'
                            ]">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 19l-7-7 7-7" />
                            </svg>
                        </button>

                        <!-- Page Numbers -->
                        <a v-for="page in getPageNumbers(pagination.current, pagination.total)" :key="page"
                            @click="typeof page === 'number' && (pagination.current = page) && searchResult('page')"
                            :class="[
                                'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                pagination.current === page
                                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg scale-110'
                                    : typeof page === 'number'
                                        ? 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:scale-105'
                                        : 'bg-white text-gray-400 cursor-default'
                            ]">
                            {{ page }}
                        </a>

                        <!-- Next Button -->
                        <button
                            @click="pagination.current < pagination.total && pagination.current++ && searchResult('page')"
                            :disabled="pagination.current === pagination.total" :class="[
                                'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                pagination.current === pagination.total
                                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                    : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:translate-x-1'
                            ]">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 5l7 7-7 7" />
                            </svg>
                        </button>
                    </div>
                </div>

            </div>
        </div>


        <div v-show="preview" class="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div class="bg-gray-900 rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
                <!-- Close Button -->
                <button @click="closePreview()"
                    class="absolute top-4 right-4 z-10 text-white hover:text-gray-300 bg-black bg-opacity-50 rounded-full p-2 transition-colors">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>

                <div class="max-h-[90vh]">
                    <!-- Video Player Section -->
                    <div class="relative bg-black aspect-video">
                        <video v-if="video_type == 'm3u8'" v-show="isReady" ref="video"
                            class="w-full h-full rounded shadow-lg" controls autoplay muted></video>

                        <video v-if="video_type == 'mp4'" v-show="isReady" :src="mp4_url" ref="video_mp4"
                            class="w-full h-full rounded shadow-lg" controls autoplay muted></video>
                        <transition name="fade">
                            <div v-if="!isReady"
                                class="absolute inset-0 flex flex-col items-center justify-center bg-black/70 text-white">
                                <div class="flex flex-col items-center space-y-4 animate-pulse">
                                    <!-- Spinner -->
                                    <div
                                        class="w-14 h-14 border-4 border-t-transparent border-orange-400 rounded-full animate-spin">
                                    </div>
                                    <p class="text-lg font-medium tracking-wide text-gray-200">
                                        ⏳ Loading your movie magic...
                                    </p>
                                </div>
                            </div>
                        </transition>
                    </div>
                    <!-- Movie Information -->
                    <div class="p-6 bg-gray-900 text-white overflow-y-auto max-h-[30vh]">
                        <!-- Title and Actions -->
                        <div class="flex justify-between items-start mb-4">
                            <div class="flex-1">
                                <h2 class="text-3xl font-bold mb-2">{{ movie_detail.title || '' }}</h2>
                                <div class="flex items-center space-x-4 text-sm text-gray-400">
                                    <span class="text-green-500 font-semibold">{{ movie_detail.rating || 'N/A' }}</span>
                                    <span>{{ movie_detail.year || '' }}</span>
                                    <span>{{ movie_detail.duration || '' }}</span>
                                    <span v-if="movie_detail.quality" class="px-2 py-0.5 bg-gray-700 rounded text-xs">{{
                                        movie_detail.quality
                                        }}</span>
                                </div>
                            </div>

                        </div>

                        <!-- Description -->
                        <p class="text-gray-300 mb-6 leading-relaxed">
                            {{ movie_detail.description || 'No description available.' }}
                        </p>

                        <!-- Movie Details Grid -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">

                            <!-- Director -->
                            <div>
                                <h3 class="text-sm font-semibold text-gray-400 mb-2">Director</h3>
                                <p class="text-white">{{ movie_detail.director || 'N/A' }}</p>
                            </div>

                            <!-- Genre -->
                            <div>
                                <h3 class="text-sm font-semibold text-gray-400 mb-2">Genre</h3>
                                <div class="flex flex-wrap gap-2">
                                    {{ movie_detail.genre || '' }}
                                </div>
                            </div>


                        </div>

                        <!-- Additional Info -->
                        <div class="border-t border-gray-700 pt-6">
                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                                <div>
                                    <p class="text-2xl font-bold text-white">{{ movie_detail.views || 0 }}</p>
                                    <p class="text-xs text-gray-400 mt-1">Views</p>
                                </div>
                                <div>
                                    <p class="text-2xl font-bold text-white">{{ movie_detail.rating || 'N/A' }}</p>
                                    <p class="text-xs text-gray-400 mt-1">Rating</p>
                                </div>
                                <div>
                                    <p class="text-2xl font-bold text-white">{{ movie_detail.year || 'N/A' }}</p>
                                    <p class="text-xs text-gray-400 mt-1">Release Date</p>
                                </div>
                                <div>
                                    <p class="text-2xl font-bold text-white">{{ movie_detail.duration || 'N/A' }}</p>
                                    <p class="text-xs text-gray-400 mt-1">Duration</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- Delete Modal Background -->
        <div v-if="showDeleteModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <!-- Modal Box -->
            <div class="bg-white rounded-2xl shadow-lg p-6 w-[90%] max-w-md animate-fade-in">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">
                    Confirm Delete
                </h2>
                <p class="text-gray-600 mb-6">
                    Are you sure you want to delete this item? This action cannot be undone.
                </p>

                <div class="flex justify-end space-x-3">
                    <button @click="showDeleteModal = false"
                        class="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100">
                        Cancel
                    </button>
                    <button @click="confirmDelete" class="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { Head, usePage } from '@inertiajs/vue3';
import { ref } from 'vue';
import { Inertia } from '@inertiajs/inertia'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { EyeIcon, TrashIcon, ArrowUpTrayIcon, PencilIcon } from '@heroicons/vue/24/outline'
import "flag-icons/css/flag-icons.min.css";
import Hls from 'hls.js'
const isReady = ref(false)
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions
const site_url = 'https://reseller.g-media.digital';
// Get data from backend
const searchTerm = ref('');
const hoveredRow = ref(null);
const movie_list = usePage().props.movie_list.data || [];
const movies = ref(movie_list); // Assuming users.list is passed from the backend
const current_page = usePage().props.movie_list.current_page;
const total_page = usePage().props.movie_list.last_page;
const total_movies = ref(usePage().props.movie_list.total.toLocaleString() || '0');
const str_search_title = ref("Total Movies: ")
const preview = ref(false);
const pagination = ref({ current: current_page, total: total_page });
const video = ref(null)
const video_mp4 = ref(null)   // for mp4
const mp4_url = ref("");
const video_type = ref('m3u8');
let hls = null
const videoSrc = ref('/m3u8-proxy') // Laravel route
const movie_detail = ref({
    title: '',
    rating: '',
    year: '',
    duration: '',
    quality: '',
    description: '',
    cast: '',
    director: '',
    genre: '',
    language: ''
})
const selectedMovie = ref(null);
const showDeleteModal = ref(false);
const file = ref(null)
const fileInput = ref(null)
const uploadProgress = ref(0)
// const router = useRouter()
const getPageNumbers = (current, total, maxVisible = 5) => {
    const pages = [];

    if (total <= maxVisible + 2) {
        // Show all pages if total is small
        for (let i = 1; i <= total; i++) {
            pages.push(i);
        }
    } else {
        // Always show first page
        pages.push(1);

        let start = Math.max(2, current - Math.floor(maxVisible / 2));
        let end = Math.min(total - 1, start + maxVisible - 1);

        // Adjust start if we're near the end
        if (end === total - 1) {
            start = Math.max(2, end - maxVisible + 1);
        }

        // Add ellipsis at start if needed
        if (start > 2) {
            pages.push('...');
        }

        // Add middle pages
        for (let i = start; i <= end; i++) {
            pages.push(i);
        }

        // Add ellipsis at end if needed
        if (end < total - 1) {
            pages.push('...');
        }

        // Always show last page
        pages.push(total);
    }

    return pages;
};
const searchResult = (type = 'search') => {
    if (type != 'search' && searchTerm) {
        fetchMovies('?page=' + pagination.value.current + '&search=' + searchTerm.value, type);
    }
    else if (type == 'search' && searchTerm.value != '') {
        fetchMovies('?page=1&search=' + searchTerm.value, type);
    }
    else if (type != 'search' && !searchTerm) {
        fetchMovies('?page=' + pagination.value.current + '$search=""', type);
    }

}
async function fetchMovies(param, type = 'search') {
    try {
        const response = await fetch('/movie_vod/search' + param, {
            method: 'get',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })
        if (!response.ok) throw new Error('Failed to save user')
        const data = await response.json()
        movies.value = data.movie_list.data; // Assuming users.list is passed from the backend
        pagination.value = { current: data.movie_list.current_page, total: data.movie_list.last_page };
        const params_str = new URLSearchParams(param.substring(1));
        const search = params_str.get('search');   // "" or keyword

        if (type === 'page') {
            if (search === "" || search === null) {
                str_search_title.value = "Total movies: ";
            } else {
                str_search_title.value = "Search result: ";
            }
        } else {
            str_search_title.value = "Search result: ";
        }
        total_movies.value = data.movie_list.total.toLocaleString() ?? '0';



    } catch (error) {
        console.error('❌ Error saving user:', error)

    }
}

async function previewItem(movie) {
    try {
        // Fetch movie details
        const response = await fetch(`/movie_vod/detail?id=${movie.videos_id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        });

        if (!response.ok) throw new Error('Failed to fetch movie details');

        const data = await response.json();

        // Update movie detail reactive state
        const m = data.movie;
        movie_detail.value = {
            title: m.title,
            rating: m.total_rating,
            year: m.release,
            quality: m.video_quality,
            description: m.description,
            duration: m.runtime,
            genre: m.genre,
            director: m.director
        };

        if (!m.video_file) {
            showError("Video file not found.");
            return;
        }

        // HLS (.m3u8) playback
        if (m.video_file.source_type === 'm3u8') {
            const playlistRes = await fetch(
                `/video/playlist?filePath=${encodeURIComponent(m.video_file.file_url)}`
            );

            if (!playlistRes.ok) throw new Error('Failed to fetch playlist');

            videoSrc.value = URL.createObjectURL(await playlistRes.blob());
            video_type.value = 'm3u8';
            if (Hls.isSupported()) {
                hls = new Hls();
                hls.loadSource(videoSrc.value);
                hls.attachMedia(video.value);

                hls.on(Hls.Events.MANIFEST_PARSED, () => {
                    console.log('✅ Manifest parsed, waiting for first segment...');
                });

                hls.on(Hls.Events.FRAG_BUFFERED, () => {
                    if (!isReady.value) {
                        isReady.value = true;
                        video.value.play().catch(err => console.warn('Autoplay blocked:', err));
                    }
                });

                hls.on(Hls.Events.ERROR, (event, errData) => {
                    console.error('❌ HLS error:', errData);
                });

            } else if (video.value.canPlayType('application/vnd.apple.mpegurl')) {
                video.value.src = videoSrc.value;
                video.value.addEventListener('loadeddata', () => {
                    isReady.value = true;
                    video.value.play();
                });
            } else {
                showError('HLS not supported in this browser');
                return;
            }

            preview.value = true;

            // MP4 playback
        } else if (m.video_file.source_type === 'mp4') {
            const mp4Res = await fetch(`/video/getmp4?filePath=${m.video_file.file_url}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document
                        .querySelector('meta[name="csrf-token"]')
                        ?.getAttribute('content')
                }
            });

            if (!mp4Res.ok) throw new Error('Failed to fetch MP4');

            const mp4Data = await mp4Res.json();
            console.log('MP4 data:', mp4Data);

            if (mp4Data.success) {
                mp4_url.value = mp4Data.url;
                video_type.value = 'mp4';
                isReady.value = true;
                // Optionally, you can set video.src for MP4 playback
                // video.value.src = mp4Data.file_url;
                // video.value.play();
            }

            preview.value = true;
        }

    } catch (error) {
        console.error('❌ Error previewing movie:', error);
        showError(error.message || 'An error occurred');
    }
}


const closePreview = () => {
    if (video_type.value === 'm3u8') {
        const current_video = video.value
        if (current_video) {
            current_video.pause()
            current_video.currentTime = 0
            current_video.src = ''
        }
        if (hls) {
            hls.stopLoad()
            hls.destroy()
            hls = null
        }
    }
    else if (video_type.value === 'mp4') {
        const current_video = video_mp4.value
        if (current_video) {
            current_video.pause()
            current_video.currentTime = 0
            current_video.src = ''  // optional, remove video URL
        }
    }

    preview.value = false
    isReady.value = false
}

async function confirmDelete() {
    try {
        const response = await fetch('/movie_vod/delete/' + selectedMovie.value.videos_id, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json();
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            searchResult();
            showDeleteModal.value = false;
        }
        else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        showError(error) // ❌ show error toast
    }
    showDeleteModal.value = false
}

const deleteItem = (item) => {
    selectedMovie.value = item;
    showDeleteModal.value = true;
}
const editItem = (item) => {
    Inertia.visit('/movie_vod/edit/' + item.videos_id);
}
const uploadItem = (movie) => {
    selectedMovie.value = movie
    // ✅ safely click the single hidden input
    fileInput.value.click()
}

const changeFileInput = async (event) => {
    file.value = event.target.files[0];
    const formData = new FormData()
    formData.append('file', file.value)
    formData.append('movie_id', selectedMovie.value.videos_id)
    try {
        const response = await fetch('/movie_vod/upload', {
            method: 'post',
            headers: {
                'Accept': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: formData
        })
        if (!response.ok) throw new Error('Failed to save user')
        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            searchResult();
        }


    } catch (error) {
        console.error('❌ Error saving user:', error)

    }
}



</script>

<style scoped>
/* Remove arrows from number input */
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.6s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>