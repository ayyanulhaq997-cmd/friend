<template>

    <Head title="Movies" />

    <AuthenticatedLayout title="Movie path matcher" desc="">
        <div class="">
            <div class="mx-auto">
                <div class="flex justify-end items-center mb-4">
                    <button @click="syncByTMDB"
                        class="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 flex items-center gap-2"
                        :disabled="sync_loading">
                        <svg v-if="sync_loading" class="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg"
                            fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4">
                            </circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                        </svg>
                        <span>{{ sync_loading ? 'Loading...' : 'Sync By TMDB' }}</span>
                    </button>
                    <button @click="syncByAI" hidden class="px-4 py-2 ml-5 bg-red-500 text-white rounded-lg hover:bg-red-600">
                        Sync By AI
                    </button>
                </div>
                <!-- ONE LINE: Left + Right Lists Side by Side -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
                    <!-- Left: File Paths -->
                    <div class="bg-white rounded-xl shadow-lg p-6 flex flex-col h-96">
                        <h2 class="text-2xl font-semibold mb-4 text-indigo-700">File Paths ({{ filteredLeft.length }})
                        </h2>
                        <input v-model="leftSearch" type="text" placeholder="Search paths..."
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none mb-4" />
                        <div class="flex-1 overflow-y-auto space-y-2">
                            <div v-for="item in filteredLeft" :key="item.id" @click="selectLeft(item)" :class="[
                                'p-3 rounded-lg cursor-pointer transition-all border-2 text-sm',
                                selectedLeft?.id === item.id
                                    ? 'bg-indigo-100 border-indigo-500 shadow-md'
                                    : 'bg-gray-50 border-transparent hover:bg-gray-100'
                            ]">
                                <code class="break-all">{{ item.path }}</code>
                            </div>
                            <p v-if="filteredLeft.length === 0" class="text-center text-gray-500 py-8">
                                No paths found
                            </p>
                        </div>
                    </div>

                    <!-- Right: Movie Info -->
                    <div class="bg-white rounded-xl shadow-lg p-6 flex flex-col h-96">
                        <h2 class="text-2xl font-semibold mb-4 text-purple-700">Movies ({{ filteredRight.length }})</h2>
                        <input v-model="rightSearch" type="text" placeholder="Search movies..."
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none mb-4" />
                        <div class="flex-1 overflow-y-auto space-y-3">
                            <div v-for="item in filteredRight" :key="item.videos_id" @click="selectRight(item)" :class="[
                                'p-4 rounded-lg cursor-pointer transition-all border-2',
                                selectedRight?.videos_id === item.videos_id
                                    ? 'bg-purple-100 border-purple-500 shadow-md'
                                    : 'bg-gray-50 border-transparent hover:bg-gray-100'
                            ]">
                                <div class="flex items-center gap-3">
                                    <!-- Image on the left -->
                                    <!-- <img :src="`/uploads/video_thumb/${item.videos_id}.jpg`"
                                        style="max-width: 64px; height: auto;" class="w-16 h-16 object-cover rounded"
                                        :alt="item.title" /> -->

                                    <!-- Title on the right -->
                                    <div class="font-bold text-lg">
                                        {{ item.title }}
                                    </div>
                                </div>
                                <div class="text-sm text-gray-600">{{ item.year }} • {{ item.genre }}</div>
                                <div class="font-bold" v-html="item.description"></div>

                            </div>
                            <p v-if="filteredRight.length === 0" class="text-center text-gray-500 py-8">
                                No movies found
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Current Selection Hint -->
                <div v-if="selectedLeft || selectedRight"
                    class="text-center mb-6 p-4 bg-blue-50 rounded-xl border-2 border-blue-200">
                    <p class="text-lg font-medium">
                        Selected →
                        <span class="text-indigo-600 font-mono text-sm mx-2">{{ selectedLeft?.path || '—' }}</span>
                        <span class="text-2xl mx-3">⟷</span>
                        <span class="text-purple-600 font-bold">{{ selectedRight?.title || '—' }} ({{
                            selectedRight?.year || ''
                        }})</span>
                    </p>
                </div>

                <!-- Matched Pairs -->
                <div class="bg-white rounded-xl shadow-lg p-6">
                    <div class="flex justify-between items-center mb-4">
                        <h2 class="text-2xl font-semibold text-green-700">
                            Matched Pairs ({{ matches.length }})
                        </h2>
                        <div class="">
                            <button @click="clearAll"
                                class="px-4 py-2  bg-red-500 text-white rounded-lg hover:bg-red-600">
                                Clear All
                            </button>
                            <button v-if="matches.length > 0" @click="matchAll"
                                class="ml-2 px-4 py-2  bg-blue-500 text-white rounded-lg hover:bg-blue-600">
                                Match All
                            </button>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div v-for="(match, idx) in matches" :key="idx"
                            class="p-4 bg-green-50 rounded-lg border border-green-300 flex flex-col relative group">
                            <!-- Close Button (Top-Right) -->
                            <button @click="removeMatch(idx)"
                                class="absolute top-2 right-2 w-7 h-7 bg-red-500 text-white rounded-full flex items-center justify-center text-sm font-bold  group-hover:opacity-100  hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400"
                                aria-label="Remove match">
                                ×
                            </button>

                            <!-- Content -->
                            <code class="text-xs text-gray-600 mb-2 break-all pr-8">{{ match.path.path }}</code>
                            <div class="text-xl text-green-500 font-bold">→</div>
                            <div class="font-bold text-green-800 text-lg">{{ match.movie.title }}</div>
                            <div class="text-sm text-gray-600">{{ match.movie.year }}</div>
                        </div>
                    </div>
                    <p v-if="matches.length === 0" class="text-center text-gray-500 py-12 text-lg">
                        No matches yet. Click one file and one movie to pair them!
                    </p>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted } from 'vue';
import { useRouter } from 'vue-router'
import { Inertia } from '@inertiajs/inertia'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { EyeIcon, TrashIcon, ArrowUpTrayIcon, PencilIcon } from '@heroicons/vue/24/outline'
import Hls from 'hls.js'
const isReady = ref(false)
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions

// Get data from backend

// Sample data (replace with your actual data)
const leftItems = ref(usePage().props.file_paths || [])
console.log(leftItems.value);

const rightItems = ref(usePage().props.videos || [])

// Search filters
const leftSearch = ref('')
const rightSearch = ref('')

// Selection
const selectedLeft = ref(null)
const selectedRight = ref(null)

// Matched pairs
const matches = ref([])

//Loading Sync
const sync_loading = ref(false);

// Filtered lists
const filteredLeft = computed(() => {
    return leftItems.value.filter(item =>
        item.path.toLowerCase().includes(leftSearch.value.toLowerCase())
    )
})

const filteredRight = computed(() => {
    return rightItems.value.filter(item =>
        item.title.toLowerCase().includes(rightSearch.value.toLowerCase())
    )
})

// Select item
const selectLeft = (item) => {
    selectedLeft.value = selectedLeft.value?.id === item.id ? null : item
    if (selectedRight.value) tryMatch()
}

const selectRight = (item) => {
    selectedRight.value = selectedRight.value?.videos_id === item.videos_id ? null : item
    if (selectedLeft.value) tryMatch()
}

// Auto-match when both selected
const tryMatch = () => {
    if (selectedLeft.value && selectedRight.value) {
        matches.value.push({
            path: selectedLeft.value,
            movie: selectedRight.value,
        })

        // Remove from original lists
        leftItems.value = leftItems.value.filter(i => i.id !== selectedLeft.value.id)
        rightItems.value = rightItems.value.filter(i => i.videos_id !== selectedRight.value.videos_id)

        // Reset selection
        selectedLeft.value = null
        selectedRight.value = null
    }
}

// Clear all matches (optional reset)
const clearAll = () => {


    matches.value = []
    // You could restore original data here if needed
}

// Clear all matches (optional reset)
const matchAll = async () => {
    const payload = { data: matches.value };
    try {
        const response = await fetch('/movie_match/manual', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: JSON.stringify(payload)
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json();
        if (data.success) {
            showSuccess('Success!') // ✅ show success toast   
            matches.value = [];        
        }
        else {
            showError("Error!") // ❌ show error toast
        }


    } catch (error) {
        showError(error) // ❌ show error toast
    }
    // You could restore original data here if needed
}

const removeMatch = (index) => {
    matches.value.splice(index, 1);
};

const syncByTMDB = async () => {
    sync_loading.value = true;
    try {
        const response = await fetch('/movie_match/sync_by_tmdb', {
            method: 'get',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json();
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            searchResult();

        }
        else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        showError(error) // ❌ show error toast
    } finally{
        sync_loading.value = false;
    }
}

const syncByAI = async () => {
    sync_loading.value = true;
    try {
        const response = await fetch('/movie_match/sync_by_ai', {
            method: 'get',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json();
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            searchResult();

        }
        else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        showError(error) // ❌ show error toast
    } finally{
        sync_loading.value = false;
    }
}
</script>

<style scoped>
/* Remove arrows from number input */
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.6s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>