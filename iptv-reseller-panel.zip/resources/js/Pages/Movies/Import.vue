<template>

    <Head title="Search and Import" />
    <AuthenticatedLayout title="Search and Import" desc="">


        <div class="mx-auto">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">

                    <div class="mx-auto">

                            <!-- Header -->
                            <div class="flex items-center w-80 mx-auto mt-8">
                                <select v-model="search_type" @click="changeSearchTypeOption"
                                    class="px-4 py-2 border bg-white">
                                    <option value="MovieByTitle" selected>Movie By Title</option>
                                    <option value="PopularMovies">Popular Movies</option>
                                    <option value="TopRatedMovies">Top Rated Movies</option>
                                    <option value="MovieShowsbyYear">Movie Shows by Year</option>
                                    <option value="UncommingMovies">Uncomming Movies</option>
                                    <option value="TVShowsByTitle">TVShows By Title</option>
                                    <option value="PopularTVShows">Popular TVShows</option>
                                    <option value="TopRatedTVShows">Top Rated TVShows</option>
                                    <option value="OnTheAirTVShows">On The Air TVShows</option>
                                    <option value="TVShowsbyYear">TV Shows by Year</option>

                                </select>
                                <!-- Input -->
                                <input type="text"
                                    v-if="search_type == 'MovieByTitle' || search_type == 'TVShowsByTitle'"
                                    placeholder="Search..." v-model="search_str"
                                    class="border-t border-b border-gray-300 px-3 py-2 focus:outline-none  flex-1" />
                                <input type="number"
                                    v-if="search_type == 'MovieByYear' || search_type == 'TVShowsByYear'"
                                    placeholder="From year..." v-model="search_year"
                                    class="border-t border-b border-gray-300 px-3 py-2 focus:outline-none  flex-1" />

                                <!-- Search Button -->
                                <button @click="getMovieDataFromTmdb"
                                    class="bg-red-500 text-white px-4 py-2 rounded-r-md hover:bg-red-600 transition-colors">
                                    SEARCH
                                </button>
                            </div>

                            <!-- Table -->
                            <div class="overflow-x-auto px-6 py-4">
                                <table class="w-full">
                                    <thead>
                                        <tr class="border-b border-gray-200">
                                            <th
                                                class="text-left px-6 py-4 text-sm font-semibold text-gray-700 w-[10%]">
                                                No</th>
                                            <th
                                                class="text-left px-6 py-4 text-sm font-semibold text-gray-700 w-[10%]">
                                                Thumbnail</th>
                                            <th
                                                class="text-left px-6 py-4 text-sm font-semibold text-gray-700 w-[10%]">
                                                Title</th>

                                            <th
                                                class="text-left px-6 py-4 text-sm font-semibold text-gray-700 w-[60%]">
                                                Description</th>

                                            <th
                                                class="text-left px-6 py-4 text-sm font-semibold text-gray-700 w-[10%]">
                                                Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-if="movies.length != 0" v-for="(movie, index) in movies"
                                            :key="movie.videos_id"
                                            class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                            @mouseenter="hoveredRow = movie.id" @mouseleave="hoveredRow = null">
                                            <td class="px-6 py-4 text-sm text-gray-800">{{ index + 1 }}</td>
                                            <td class="px-6 py-4 text-sm text-gray-800">
                                                <img v-if="movie.poster_path"
                                                    :src="`https://image.tmdb.org/t/p/w154${movie.poster_path}`"
                                                    style="max-width: 64px" :alt="`${movie.title}`" />
                                                <img v-else-if="movie.backdrop_path"
                                                    :src="`https://image.tmdb.org/t/p/w154${movie.backdrop_path}`"
                                                    style="max-width: 64px" :alt="`${movie.title}`" />
                                                <img v-else="movie.backdrop_path"
                                                    src="https://play-lh.googleusercontent.com/XXqfqs9irPSjphsMPcC-c6Q4-FY5cd8klw4IdI2lof_Ie-yXaFirqbNDzK2kJ808WXJk=w240-h480-rw"
                                                    style="max-width: 64px" :alt="`${movie.title}`" />

                                            </td>
                                            <td class="px-6 py-4 text-sm text-gray-800">
                                                {{ movie.title ?? movie.name ?? 'Untitled' }}
                                            </td>
                                            <td class="px-6 py-4 text-sm text-gray-800">
                                                {{ movie.overview ?? '' }}
                                            </td>

                                            <td class="px-6 py-4 text-sm text-gray-800">
                                                <div class="mt-auto">
                                                    <button v-if="!movie.exist" @click="importMovie(movie)"
                                                        class="px-3 py-1 text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition">
                                                        Import
                                                    </button>

                                                    <span v-else
                                                        class="inline-block px-3 py-1 text-sm font-medium bg-green-100 text-green-700 rounded-lg">
                                                        Imported
                                                    </span>
                                                </div>
                                            </td>


                                        </tr>
                                        <tr v-else>
                                            <td colspan="8" class="text-center my-5">No Movies</td>
                                        </tr>
                                    </tbody>
                                </table>
                                <!-- only one file input -->
                                <input type="file" ref="fileInput" @change="changeFileInput" class="hidden"
                                    id="upload_file" />
                                <div v-if="uploadProgress > 0" class="mt-4 w-64">
                                    <div class="bg-gray-200 rounded-full h-4 overflow-hidden">
                                        <div class="bg-purple-600 h-full transition-all duration-200"
                                            :style="{ width: uploadProgress + '%' }"></div>
                                    </div>
                                    <p class="text-sm mt-1">Uploading: {{ uploadProgress }}%</p>
                                </div>
                            </div>

                            <div class="flex items-center justify-center space-x-2 mb-4">
                                <!-- Previous Button -->
                                <button
                                    @click="pagination.current > 1 && pagination.current-- && getMovieDataFromTmdb()"
                                    :disabled="pagination.current === 1" :class="[
                                        'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                        pagination.current === 1
                                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                            : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:-translate-x-1'
                                    ]">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M15 19l-7-7 7-7" />
                                    </svg>
                                </button>

                                <!-- Page Numbers -->
                                <a v-for="page in getPageNumbers(pagination.current, pagination.total)" :key="page"
                                    @click="typeof page === 'number' && (pagination.current = page) && getMovieDataFromTmdb()"
                                    :class="[
                                        'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                        pagination.current === page
                                            ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg scale-110'
                                            : typeof page === 'number'
                                                ? 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:scale-105'
                                                : 'bg-white text-gray-400 cursor-default'
                                    ]">
                                    {{ page }}
                                </a>

                                <!-- Next Button -->
                                <button
                                    @click="pagination.current < pagination.total && pagination.current++ && getMovieDataFromTmdb()"
                                    :disabled="pagination.current === pagination.total" :class="[
                                        'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                        pagination.current === pagination.total
                                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                            : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:translate-x-1'
                                    ]">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M9 5l7 7-7 7" />
                                    </svg>
                                </button>
                            </div>


                    </div>

            </div>
        </div>


        <!-- Import Modal Background -->
        <div v-if="showImportModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <!-- Modal Box -->
            <div class="bg-white rounded-2xl shadow-lg p-6 w-[90%] max-w-md animate-fade-in">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">
                    {{ isImporting ? 'Importing...' : 'Confirm Import' }}
                </h2>

                <div class="flex items-center justify-center mb-6">
                    <template v-if="isImporting">
                        <!-- Loading Spinner -->
                        <svg class="animate-spin h-6 w-6 text-red-600 mr-2" xmlns="http://www.w3.org/2000/svg"
                            fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4">
                            </circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                        </svg>
                        <p class="text-gray-600">Importing item, please wait...</p>
                    </template>
                    <template v-else>
                        <p class="text-gray-600">
                            Are you sure you want to import this item? This action cannot be undone.
                        </p>
                    </template>
                </div>

                <div class="flex justify-end space-x-3">
                    <button @click="showImportModal = false" :disabled="isImporting"
                        class="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 disabled:opacity-50">
                        Cancel
                    </button>

                    <button @click="confirmImport" :disabled="isImporting"
                        class="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 disabled:opacity-50">
                        {{ isImporting ? 'Importing...' : 'Import' }}
                    </button>
                </div>
            </div>
        </div>


    </AuthenticatedLayout>
</template>

<script setup>
import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted } from 'vue';
import { Inertia } from '@inertiajs/inertia'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { EyeIcon, TrashIcon, ArrowUpTrayIcon } from '@heroicons/vue/24/outline'
const isReady = ref(false)
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions

// Get data from backend

const hoveredRow = ref(null);
const movies = ref([]); // Assuming users.list is passed from the backend
const search_type = ref("MovieByTitle")
const search_str = ref("");
const search_year = ref("");
const current_page = ref(1);
const total_page = ref(1);
const total_numbers = ref(0);
const pagination = ref({ current: current_page, total: total_page });
const selectedItem = ref(null);
const showImportModal = ref(false);
const isImporting = ref(false);
const getPageNumbers = (current, total, maxVisible = 5) => {
    const pages = [];

    if (total <= maxVisible + 2) {
        // Show all pages if total is small
        for (let i = 1; i <= total; i++) {
            pages.push(i);
        }
    } else {
        // Always show first page
        pages.push(1);

        let start = Math.max(2, current - Math.floor(maxVisible / 2));
        let end = Math.min(total - 1, start + maxVisible - 1);

        // Adjust start if we're near the end
        if (end === total - 1) {
            start = Math.max(2, end - maxVisible + 1);
        }

        // Add ellipsis at start if needed
        if (start > 2) {
            pages.push('...');
        }

        // Add middle pages
        for (let i = start; i <= end; i++) {
            pages.push(i);
        }

        // Add ellipsis at end if needed
        if (end < total - 1) {
            pages.push('...');
        }

        // Always show last page
        pages.push(total);
    }

    return pages;
};
const changeSearchTypeOption = () => {
    current_page.value = 1;
    total_page.value = 1;
}

const getMovieDataFromTmdb = async () => {
    const formData = new FormData();
    if (search_type.value == 'MovieByTitle') {
        if (search_str.value == '') {
            showError('enter search key') // ❌ show error toast
            return;
        }
    }
    formData.append('type', search_type.value);
    formData.append('search_str', search_str.value);
    formData.append('search_year', search_year.value);
    formData.append('page', pagination.value.current);
    try {
        const response = await fetch('/movie_vod/tmdb_data', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: formData  // Use 'body' not 'data'
        });

        if (!response.ok) throw new Error('Failed to fetch data');
        const data = await response.json();
        if (data.success) {
            movies.value = data.data.results;
            current_page.value = data.data.page;
            total_page.value = data.data.total_pages;
            total_numbers.value = data.data.total_results;
        }

    } catch (error) {
        console.error('❌ Error fetching data:', error);
    }
}

const importMovie = (movie) => {
    console.log(movie);

    selectedItem.value = movie;
    showImportModal.value = true;
    
}

const confirmImport = async () => {   
    if (selectedItem.value == null) {
        showError('Select Movie');
        return;
    }
     isImporting.value = true;
    try {
        const formData = new FormData();
        formData.append('id', selectedItem.value.id);
        formData.append('type', selectedItem.value.media_type);


        const response = await fetch('/movie_vod/import_movie', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: formData  // Use 'body' not 'data'
        });

        if (!response.ok) throw new Error('Failed to fetch data');
        const data = await response.json();
        if (data.success) {
            showSuccess('Imported Successfully');
            showImportModal.value = false;            
            getMovieDataFromTmdb();
        }

    } catch (error) {
        console.error('❌ Error importing data:', error);
        showError('Error importing data');
    } 
    isImporting.value = false;

}
</script>

<style scoped>
/* Remove arrows from number input */
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.6s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>