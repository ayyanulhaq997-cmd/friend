<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed } from 'vue';
import { Inertia } from '@inertiajs/inertia'
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions
import { useAuthStore } from '@/Utils/auth'
const auth = useAuthStore()
const data = ref(usePage().props.data);
const thumbFile = ref(null);
const posterFile = ref(null);

const formData = ref({
    imdbid: data.value.imdbid ?? '',
    title: data.value.title ?? '',
    description: data.value.description ?? '',
    stars: data.value.stars ?? '',
    director: data.value.director ?? '',
    writer: data.value.writer ?? '',
    rating: data.value.rating ?? '',
    release: data.value.release ?? '',
    country: data.value.country ?? '',
    genre: data.value.genre ?? '',
    runtime: data.value.runtime ?? '',
    video_quality: data.value.video_quality ?? '',
    is_paid: data.value.is_paid ?? '',
    enable_download: data.value.enable_download ?? '',
    total_rating: data.value.total_rating ?? '',
    today_view: data.value.today_view ?? '',
    weekly_view: data.value.weekly_view ?? '',
    monthly_view: data.value.monthly_view ?? '',
    thumbnail: data.value.thumbnail ?? '',
    bg_url: data.value.thumbnail ?? '',
    card_url: data.value.thumbnail ?? '',       
    trailler_youtube_source: data.value.trailler_youtube_source ?? '',

});

async function handleSubmit() {    
    const editData = new FormData()
    editData.append('id', data.value.videos_id)
    editData.append('thumb_file', thumbFile.value)
    editData.append('poster_file', posterFile.value)
    editData.append('title', formData.value.title)
    editData.append('is_paid', formData.value.is_paid)
    editData.append('trailler_youtube_source', formData.value.trailler_youtube_source)
    editData.append('enable_download', formData.value.enable_download)
    try {
        const response = await fetch('/movie_vod/edit', {
            method: 'post',
            headers: {
                'Accept': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: editData
        })
        if (!response.ok) throw new Error('Failed to save user')
        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            searchResult();
        }


    } catch (error) {
        console.error('❌ Error saving user:', error)

    }
};

const handleThumbUpload = (e) => {
    const file = e.target.files[0];
    if (file) formData.value.card_url = URL.createObjectURL(file);
    thumbFile.value = file;
};

const handlePosterUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
        formData.value.bg_url = URL.createObjectURL(file);
        posterFile.value = file;
    }
};
const previewImage = (src) => {
    window.open(src, '_blank');
};
</script>

<template>

    <Head title="Movie Edit" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                Movie Edit
            </h2>
        </template>
        <div class="sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg px-6 py-8">
                <h1 class="text-2xl font-semibold text-gray-800 mb-8">Movie Edit</h1>

                <form @submit.prevent="handleSubmit" class="space-y-6">

                    <!-- Row 1 -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Title</label>
                            <input v-model="formData.title" disabled type="text"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">IMDB ID</label>
                            <input v-model="formData.imdbid" disabled type="text"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none">
                        </div>
                    </div>

                    <!-- Row 2 -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Genre</label>
                            <input v-model="formData.genre" disabled type="text"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Release</label>
                            <input v-model="formData.release" disabled type="text"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none">
                        </div>
                    </div>

                    <!-- Row 3 -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Director</label>
                            <input v-model="formData.director" disabled type="text"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Writer</label>
                            <input v-model="formData.writer" disabled type="text"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none">
                        </div>
                    </div>

                    <!-- Row 4: Stars (Textarea full width) -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Stars</label>
                        <textarea v-model="formData.stars" disabled rows="3"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"></textarea>
                    </div>

                    <!-- Row 5 -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Country</label>
                            <input v-model="formData.country" disabled type="text"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Video Quality</label>
                            <input v-model="formData.video_quality" disabled type="text"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none">
                        </div>
                    </div>

                    <!-- Row 6 -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Trailer (YouTube)</label>
                            <input v-model="formData.trailler_youtube_source" type="text"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none">
                        </div>

                        <div class="flex items-center space-x-8 mt-6">
                            <div class="flex items-center space-x-3">
                                <label class="block text-sm font-medium text-gray-700">Download</label>
                                <button type="button" @click="formData.enable_download = !formData.enable_download"
                                    :class="[
                                        'relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:ring-2 focus:ring-orange-400 focus:ring-offset-2',
                                        formData.enable_download ? 'bg-green-500' : 'bg-gray-300'
                                    ]">
                                    <span :class="[
                                        'inline-block h-4 w-4 transform bg-white rounded-full transition-transform',
                                        formData.enable_download ? 'translate-x-6' : 'translate-x-1'
                                    ]"></span>
                                </button>
                            </div>

                            <div class="flex items-center space-x-3">
                                <label class="block text-sm font-medium text-gray-700">Paid</label>
                                <button type="button" @click="formData.is_paid = !formData.is_paid" :class="[
                                    'relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:ring-2 focus:ring-orange-400 focus:ring-offset-2',
                                    formData.is_paid ? 'bg-green-500' : 'bg-gray-300'
                                ]">
                                    <span :class="[
                                        'inline-block h-4 w-4 transform bg-white rounded-full transition-transform',
                                        formData.is_paid ? 'translate-x-6' : 'translate-x-1'
                                    ]"></span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Row 7: Description -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                        <textarea v-model="formData.description" rows="4"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"></textarea>
                    </div>

                    <!-- Row: Thumbnail Image & Poster Image -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Row: Thumbnail Image & Poster Image -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Thumbnail -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Thumbnail Image</label>

                                <div class="flex items-center gap-3">
                                    <!-- Upload Button -->
                                    <input type="file" @change="handleThumbUpload" accept="image/*" class="hidden"
                                        ref="thumbInput">

                                    <button type="button" @click="$refs.thumbInput.click()"
                                        class="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-all shadow">
                                        Upload
                                    </button>

                                    <!-- Preview Button -->
                                    <div v-if="formData.card_url" class="relative group inline-block">
                                        <EyeIcon class="w-6 h-6 text-gray-600 hover:text-purple-600 cursor-pointer"
                                            @click="previewImage(formData.card_url)" />
                                        <span
                                            class="absolute bottom-full mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                                            Preview Thumbnail
                                        </span>
                                    </div>
                                </div>

                                <!-- Image Preview -->
                                <div v-if="formData.card_url" class="mt-3">
                                    <img :src="formData.card_url" alt="Thumbnail Preview"
                                        class="h-32 w-auto rounded-md border border-gray-200 shadow-sm object-cover">
                                </div>
                            </div>

                            <!-- Poster -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Poster Image</label>

                                <div class="flex items-center gap-3">
                                    <!-- Upload Button -->
                                    <input type="file" @change="handlePosterUpload" accept="image/*" class="hidden"
                                        ref="posterInput">

                                    <button type="button" @click="$refs.posterInput.click()"
                                        class="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-all shadow">
                                        Upload
                                    </button>

                                    <!-- Preview Button -->
                                    <div v-if="formData.bg_url" class="relative group inline-block">
                                        <EyeIcon class="w-6 h-6 text-gray-600 hover:text-purple-600 cursor-pointer"
                                            @click="previewImage(formData.bg_url)" />
                                        <span
                                            class="absolute bottom-full mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                                            Preview Poster
                                        </span>
                                    </div>
                                </div>

                                <!-- Image Preview -->
                                <div v-if="formData.bg_url" class="mt-3">
                                    <img :src="formData.bg_url" alt="Poster Preview"
                                        class="h-32 w-auto rounded-md border border-gray-200 shadow-sm object-cover">
                                </div>
                            </div>
                        </div>

                    </div>


                    <!-- Save Button -->
                    <div class="flex justify-start">
                        <button type="submit"
                            class="px-12 py-3 bg-orange-500 text-white rounded-full font-medium hover:bg-orange-600 transition shadow-md">
                            Save
                        </button>
                    </div>

                </form>
            </div>
        </div>




    </AuthenticatedLayout>
</template>



<style scoped>
/* Add any custom styles here if needed */
</style>
