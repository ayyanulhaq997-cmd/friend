<template>

    <Head title="Episodes List" />
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                Episodes List
            </h2>
        </template>
        <div class="py-2">
            <div class="mx-auto  sm:px-6 lg:px-8">
                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                    <div class="min-h-screen">
                        <div class="mx-auto">
                            <div>
                                <!-- Header -->
                                <div class="flex justify-between items-center p-6 ">
                                    <h1 class="text-xl font-semibold text-gray-800">EPISODE LIST</h1>
                                    <div class="flex justify-end items-center mb-4">
                                        <!-- TODO  File Input -->
                                        <button @click="uploadItem(movie)"
                                            class="px-4 py-2 ml-5 bg-red-500 text-white rounded-lg hover:bg-red-600">
                                            Add Episode
                                        </button>
                                    </div>
                                </div>
                                <!-- only one file input -->
                                <input type="file" ref="fileInput" @change="changeFileInput" class="hidden"
                                    id="upload_file" />
                                <!-- Table -->
                                <div class="overflow-x-auto px-6 py-4">
                                    <table class="w-full">
                                        <thead>
                                            <tr class="border-b border-gray-200">
                                                <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                                    Number</th>
                                                <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                                    Title</th>
                                                

                                                <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                                    Preview</th>

                                                <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                                    Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-if="episodes.length != 0" v-for="(item, index) in episodes"
                                                :key="item.videos_id"
                                                class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                                @mouseenter="hoveredRow = item.id" @mouseleave="hoveredRow = null">
                                                <td class="px-6 py-4 text-sm text-gray-800">{{ item.episode_number }}
                                                </td>
                                                <td class="px-6 py-4 text-sm text-gray-800">{{ item.title }}
                                                </td>                                               

                                                <td class="px-6 py-4 text-sm text-gray-800">
                                                    <div class="relative group inline-block">
                                                        <EyeIcon
                                                            class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                            @click="previewItem(item)" />
                                                        <span
                                                            class="absolute bottom-full mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                                                            Preview Movie
                                                        </span>
                                                    </div>

                                                </td>

                                                <td class="px-6 py-4 text-sm text-gray-800">
                                                    <div class="relative group inline-block ml-4">
                                                        <TrashIcon
                                                            class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                            @click="deleteItem(item)" />
                                                        <span
                                                            class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap z-10">
                                                            Delete Movie
                                                        </span>
                                                    </div>
                                                    <div class="relative group inline-block ml-4">
                                                        <ArrowUpTrayIcon
                                                            class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                            @click="uploadItem(item)" />


                                                        <span v-if="item.file"
                                                            class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap z-10">
                                                            Update Movie
                                                        </span>
                                                        <span v-if="!item.file"
                                                            class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap z-10">
                                                            Upload Movie
                                                        </span>
                                                    </div>
                                                </td>


                                            </tr>
                                            <tr v-else>
                                                <td colspan="8" class="text-center my-5">No Movies</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <!-- only one file input -->
                                    <input type="file" ref="fileInput" @change="changeFileInput" class="hidden"
                                        id="upload_file" />
                                    <div v-if="uploadProgress > 0" class="mt-4 w-64">
                                        <div class="bg-gray-200 rounded-full h-4 overflow-hidden">
                                            <div class="bg-purple-600 h-full transition-all duration-200"
                                                :style="{ width: uploadProgress + '%' }"></div>
                                        </div>
                                        <p class="text-sm mt-1">Uploading: {{ uploadProgress }}%</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

         <div v-show="preview" class="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
            <div class="bg-gray-900 rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
                <!-- Close Button -->
                <button @click="closePreview()"
                    class="absolute top-4 right-4 z-10 text-white hover:text-gray-300 bg-black bg-opacity-50 rounded-full p-2 transition-colors">
                    <svg class="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
                <div class="max-h-[90vh]">
                    <!-- Video Player Section -->
                    <div class="relative bg-black aspect-video">
                        <video v-if="video_type == 'm3u8'" v-show="isReady" ref="video"
                            class="w-full h-full rounded shadow-lg" controls autoplay muted></video>

                        <video v-if="video_type == 'mp4'" v-show="isReady" :src="mp4_url" ref="video_mp4"
                            class="w-full h-full rounded shadow-lg" controls autoplay muted></video>
                        <transition name="fade">
                            <div v-if="!isReady"
                                class="absolute inset-0 flex flex-col items-center justify-center bg-black/70 text-white">
                                <div class="flex flex-col items-center space-y-4 animate-pulse">
                                    <!-- Spinner -->
                                    <div
                                        class="w-14 h-14 border-4 border-t-transparent border-orange-400 rounded-full animate-spin">
                                    </div>
                                    <p class="text-lg font-medium tracking-wide text-gray-200">
                                        ⏳ Loading your movie magic...
                                    </p>
                                </div>
                            </div>
                        </transition>
                    </div>                    
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted } from 'vue';
import { useRouter } from 'vue-router'
import { Inertia } from '@inertiajs/inertia'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { EyeIcon, TrashIcon, ArrowUpTrayIcon, PencilIcon } from '@heroicons/vue/24/outline'
import Hls from 'hls.js'
const isReady = ref(false)
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions

// Get data from backend
const searchTerm = ref('');
const hoveredRow = ref(null);
const episodes = ref(usePage().props.seasons.episodes || []); // Assuming users.list is passed from the backend
const preview = ref(false);
const video = ref(null)
const video_mp4 = ref(null)   // for mp4
const mp4_url = ref("");
const video_type = ref('m3u8');
let hls = null
const videoSrc = ref('/m3u8-proxy') // Laravel route

const selectedMovie = ref(null);
const showDeleteModal = ref(false);
const file = ref(null)
const fileInput = ref(null)
const uploadProgress = ref(0)
const router = useRouter()



async function previewItem(episod) {
    try {
        // Fetch movie details
        const response = await fetch(`/episod/detail?id=${episod.id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        });

        if (!response.ok) throw new Error('Failed to fetch movie details');

        const data = await response.json();
        // Update movie detail reactive state
        const m = data.data;       
        if (!m.video_url) {
            showError("Episod file not found.");
            return;
        }

        // HLS (.m3u8) playback
        if (m.source_type === 'm3u8') {
            const playlistRes = await fetch(`/video/playlist?filePath=${m.video_url}`);
            if (!playlistRes.ok) throw new Error('Failed to fetch playlist');

            videoSrc.value = URL.createObjectURL(await playlistRes.blob());
            video_type.value = 'm3u8';
            if (Hls.isSupported()) {
                hls = new Hls();
                hls.loadSource(videoSrc.value);
                hls.attachMedia(video.value);

                hls.on(Hls.Events.MANIFEST_PARSED, () => {
                    console.log('✅ Manifest parsed, waiting for first segment...');
                });

                hls.on(Hls.Events.FRAG_BUFFERED, () => {
                    if (!isReady.value) {
                        isReady.value = true;
                        video.value.play().catch(err => console.warn('Autoplay blocked:', err));
                    }
                });

                hls.on(Hls.Events.ERROR, (event, errData) => {
                    console.error('❌ HLS error:', errData);
                });

            } else if (video.value.canPlayType('application/vnd.apple.mpegurl')) {
                video.value.src = videoSrc.value;
                video.value.addEventListener('loadeddata', () => {
                    isReady.value = true;
                    video.value.play();
                });
            } else {
                showError('HLS not supported in this browser');
                return;
            }

            preview.value = true;

            // MP4 playback
        } else if (m.source_type === 'mp4') {
            const mp4Res = await fetch(`/video/getmp4?filePath=${m.video_url}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document
                        .querySelector('meta[name="csrf-token"]')
                        ?.getAttribute('content')
                }
            });

            if (!mp4Res.ok) throw new Error('Failed to fetch MP4');

            const mp4Data = await mp4Res.json();
            console.log('MP4 data:', mp4Data);

            if (mp4Data.success) {
                mp4_url.value = mp4Data.url;
                video_type.value = 'mp4';
                isReady.value = true;
                // Optionally, you can set video.src for MP4 playback
                // video.value.src = mp4Data.file_url;
                // video.value.play();
            }

            preview.value = true;
        }

    } catch (error) {
        console.error('❌ Error previewing movie:', error);
        showError(error.message || 'An error occurred');
    }
}


const closePreview = () => {
    if (video_type.value === 'm3u8') {
        const current_video = video.value
        if (current_video) {
            current_video.pause()
            current_video.currentTime = 0
            current_video.src = ''
        }
        if (hls) {
            hls.stopLoad()
            hls.destroy()
            hls = null
        }
    }
    else if (video_type.value === 'mp4') {
        const current_video = video_mp4.value
        if (current_video) {
            current_video.pause()
            current_video.currentTime = 0
            current_video.src = ''  // optional, remove video URL
        }
    }

    preview.value = false
    isReady.value = false
}

async function confirmDelete() {
    try {
        const response = await fetch('/movie_vod/delete/' + selectedMovie.value.videos_id, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json();
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            searchResult();
            showDeleteModal.value = false;
        }
        else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        showError(error) // ❌ show error toast
    }
    showDeleteModal.value = false
}

const deleteItem = (item) => {
    selectedMovie.value = item;
    showDeleteModal.value = true;
}

const uploadItem = (movie) => {
    selectedMovie.value = movie
    // ✅ safely click the single hidden input
    fileInput.value.click()
}

const changeFileInput = async (event) => {
    file.value = event.target.files[0];
    const formData = new FormData()
    formData.append('file', file.value)
    formData.append('movie_id', selectedMovie.value.videos_id)
    try {
        const response = await fetch('/movie_vod/upload', {
            method: 'post',
            headers: {
                'Accept': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: formData
        })
        if (!response.ok) throw new Error('Failed to save user')
        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            searchResult();
        }


    } catch (error) {
        console.error('❌ Error saving user:', error)

    }
}



</script>

<style scoped>
/* Remove arrows from number input */
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.6s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>