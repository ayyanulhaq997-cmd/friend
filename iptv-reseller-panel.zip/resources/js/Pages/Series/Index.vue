<template>

    <Head title="Series" />

    <AuthenticatedLayout title="Series" desc="SERIES LIST">

        <div class="mx-auto">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">

                <div class="mx-auto">
                    <div>
                        <!-- Header -->
                        <div class="flex justify-between items-center px-6 py-4">
                            <div class="relative">
                                <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5"
                                    fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                                <input type="text" placeholder="Search..." v-model="searchTerm"
                                    class="pl-10 pr-4 py-2 border border-gray-300 rounded-l-lg w-64 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                                <!-- Search Button -->
                                <button @click="searchResult('search')"
                                    class="bg-red-500 text-white px-4 py-2 rounded-r-md hover:bg-red-600 transition-colors">
                                    SEARCH
                                </button>
                            </div>
                            <div class="relative">
                                <span class="px-4 py-4 inline-flex  leading-5 font-semibold">
                                    {{ str_search_title }}
                                </span>
                                <span :class="series ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                                    class="px-6 py-2 inline-flex  leading-5 font-semibold rounded-full">
                                    {{ total_series }}
                                </span>
                            </div>
                        </div>

                        <!-- Table -->
                        <div class="overflow-x-auto px-6">
                            <table class="w-full">
                                <thead>
                                    <tr class="border-b border-gray-200">
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            No</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Thumbnail</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Name</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Uploaded</th>

                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Preview</th>

                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-if="series.length != 0" v-for="(item, index) in series" :key="item.videos_id"
                                        class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                        @mouseenter="hoveredRow = item.id" @mouseleave="hoveredRow = null">
                                        <td class="px-4 py-2 text-sm text-gray-800">{{ index + 1 }}</td>
                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            <img :src="item.cover" style="max-width: 64px" :alt="`${item.title}`" class="lazy"/>
                                        </td>
                                        <td class="px-4 py-2 text-gray-800"><b>{{ item.title }}</b> <span>{{
                                            item.released_year ? `(${item.released_year})` : '' }}</span>
                                            <br>
                                            <div class="flex" v-if="item.country">
                                                <img v-for="(lang, i) in item.country.split(',')" :key="i"
                                                    :src="`/img/${lang}.png`" alt="" class="w-6"
                                                    :class="{ 'ml-1': i !== 0 }">
                                            </div>
                                        </td>
                                        <td class="px-4 py-2 text-sm text-gray-800">{{ new Date(item.updated_at).toISOString().split('T')[0] }}</td>


                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            <div class="relative group inline-block">
                                                <EyeIcon
                                                    class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                    @click="previewItem(item)" />
                                                <span
                                                    class="absolute bottom-full mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                                                    Preview Movie
                                                </span>
                                            </div>
                                        </td>

                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            <div class="relative group inline-block ml-4">
                                                <TrashIcon
                                                    class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                    @click="deleteItem(item)" />
                                                <span
                                                    class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap z-10">
                                                    Delete Movie
                                                </span>
                                            </div>
                                        </td>


                                    </tr>
                                    <tr v-else>
                                        <td colspan="8" class="text-center my-5">No Movies</td>
                                    </tr>
                                </tbody>
                            </table>
                            <!-- only one file input -->
                            <input type="file" ref="fileInput" @change="changeFileInput" class="hidden"
                                id="upload_file" />
                            <div v-if="uploadProgress > 0" class="mt-4 w-64">
                                <div class="bg-gray-200 rounded-full h-4 overflow-hidden">
                                    <div class="bg-purple-600 h-full transition-all duration-200"
                                        :style="{ width: uploadProgress + '%' }"></div>
                                </div>
                                <p class="text-sm mt-1">Uploading: {{ uploadProgress }}%</p>
                            </div>
                        </div>
                    </div>
                    <div class="flex items-center justify-center space-x-2 my-4">
                        <!-- Previous Button -->
                        <button @click="pagination.current > 1 && pagination.current-- && searchResult('page')"
                            :disabled="pagination.current === 1" :class="[
                                'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                pagination.current === 1
                                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                    : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:-translate-x-1'
                            ]">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 19l-7-7 7-7" />
                            </svg>
                        </button>

                        <!-- Page Numbers -->
                        <a v-for="page in getPageNumbers(pagination.current, pagination.total)" :key="page"
                            @click="typeof page === 'number' && (pagination.current = page) && searchResult('page')"
                            :class="[
                                'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                pagination.current === page
                                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg scale-110'
                                    : typeof page === 'number'
                                        ? 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:scale-105'
                                        : 'bg-white text-gray-400 cursor-default'
                            ]">
                            {{ page }}
                        </a>

                        <!-- Next Button -->
                        <button
                            @click="pagination.current < pagination.total && pagination.current++ && searchResult('page')"
                            :disabled="pagination.current === pagination.total" :class="[
                                'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                pagination.current === pagination.total
                                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                    : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:translate-x-1'
                            ]">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 5l7 7-7 7" />
                            </svg>
                        </button>
                    </div>
                </div>

            </div>
        </div>

    </AuthenticatedLayout>
</template>

<script setup>
import { Head, usePage } from '@inertiajs/vue3';
import { ref} from 'vue';
import { Inertia } from '@inertiajs/inertia'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { EyeIcon, TrashIcon} from '@heroicons/vue/24/outline'
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions
// Get data from backend
const searchTerm = ref('');
const hoveredRow = ref(null);
const series = ref(usePage().props.series.data || []); // Assuming users.list is passed from the backend
const current_page = usePage().props.series.current_page;
const total_page = usePage().props.series.last_page;
const pagination = ref({ current: current_page, total: total_page });
const total_series = ref(usePage().props.series.total.toLocaleString() || '0');
const str_search_title = ref("Total Series: ")
const selectedMovie = ref(null);
const showDeleteModal = ref(false);
const getPageNumbers = (current, total, maxVisible = 5) => {
    const pages = [];
    if (total <= maxVisible + 2) {
        // Show all pages if total is small
        for (let i = 1; i <= total; i++) {
            pages.push(i);
        }
    } else {
        // Always show first page
        pages.push(1);

        let start = Math.max(2, current - Math.floor(maxVisible / 2));
        let end = Math.min(total - 1, start + maxVisible - 1);

        // Adjust start if we're near the end
        if (end === total - 1) {
            start = Math.max(2, end - maxVisible + 1);
        }

        // Add ellipsis at start if needed
        if (start > 2) {
            pages.push('...');
        }

        // Add middle pages
        for (let i = start; i <= end; i++) {
            pages.push(i);
        }

        // Add ellipsis at end if needed
        if (end < total - 1) {
            pages.push('...');
        }

        // Always show last page
        pages.push(total);
    }

    return pages;
};
const searchResult = (type = 'search') => {
    if (type != 'search' && searchTerm) {
        fetchMovies('?page=' + pagination.value.current + '&search=' + searchTerm.value, type);
    }
    else if (type == 'search' && searchTerm.value != '') {
        fetchMovies('?page=1&search=' + searchTerm.value, type);
    }
    else if (type != 'search' && !searchTerm) {
        fetchMovies('?page=' + pagination.value.current + '$search=""', type);
    }
}
async function fetchMovies(param, type = 'search') {
    try {
        const response = await fetch('/series/search' + param, {
            method: 'get',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })
        if (!response.ok) throw new Error('Failed to save user')
        const data = await response.json()
        series.value = data.data.data; // Assuming users.list is passed from the backend
        pagination.value = { current: data.data.current_page, total: data.data.last_page };
        const params_str = new URLSearchParams(param.substring(1));
        const search = params_str.get('search');   // "" or keyword
        if (type === 'page') {
            if (search === "" || search === null) {
                str_search_title.value = "Total series: ";
            } else {
                str_search_title.value = "Search result: ";
            }
        } else {
            str_search_title.value = "Search result: ";
        }
        total_series.value = data.data.total.toLocaleString() ?? '0';

    } catch (error) {
        console.error('❌ Error saving user:', error)

    }
}

async function previewItem(item) {
    Inertia.visit(`/series/season/${item.id}`);
}
async function confirmDelete() {
    try {
        const response = await fetch('/series/delete/' + selectedMovie.value.videos_id, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json();
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            searchResult();
            showDeleteModal.value = false;
        }
        else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        showError(error) // ❌ show error toast
    }
    showDeleteModal.value = false
}

const deleteItem = (item) => {
    selectedMovie.value = item;
    showDeleteModal.value = true;
}
</script>

<style scoped>
/* Remove arrows from number input */
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.6s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>