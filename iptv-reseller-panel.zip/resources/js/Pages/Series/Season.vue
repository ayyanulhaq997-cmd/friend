<template>

    <Head title="Series Detail" />
    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">
                Series Detail
            </h2>
        </template>
        <div class="py-2">
            <div class="mx-auto  sm:px-6 lg:px-8">
                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                    <div class="min-h-screen">
                        <div class="mx-auto">
                            <div>
                                <!-- Header -->
                                <div class="flex justify-between items-center p-6 ">
                                    <h1 class="text-xl font-semibold text-gray-800">SEASON LIST</h1>
                                    <div class="relative">
                                        <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5"
                                            fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                        </svg>
                                        <input type="text" placeholder="Search..." v-model="searchTerm"
                                            @keyup.enter="searchResult"
                                            class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />

                                    </div>
                                </div>
                                <!-- Table -->
                                <div class="overflow-x-auto px-6 py-4">
                                    <table class="w-full">
                                        <thead>
                                            <tr class="border-b border-gray-200">
                                                <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                                    Number</th>
                                                <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                                    Thumbnail</th>
                                                <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                                    Release Year</th>

                                                <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                                    Preview</th>

                                                <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                                    Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr v-if="seasons.length != 0" v-for="(item, index) in seasons"
                                                :key="item.videos_id"
                                                class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                                @mouseenter="hoveredRow = item.id" @mouseleave="hoveredRow = null">
                                                <td class="px-6 py-4 text-sm text-gray-800">{{ item.season_number }}
                                                </td>
                                                <td class="px-6 py-4 text-sm text-gray-800">
                                                    <img :src="item.thumbnail ?? series.bg_url" style="max-width: 64px"
                                                        :alt="`${item.season_number}`" />
                                                </td>
                                                <td class="px-6 py-4 text-sm text-gray-800">{{ item.release_year }}
                                                </td>

                                                <td class="px-6 py-4 text-sm text-gray-800">
                                                    <div class="relative group inline-block">
                                                        <EyeIcon
                                                            class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                            @click="previewItem(item)" />
                                                        <span
                                                            class="absolute bottom-full mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                                                            Preview Movie
                                                        </span>
                                                    </div>

                                                </td>

                                                <td class="px-6 py-4 text-sm text-gray-800">                                                    
                                                    <div class="relative group inline-block ml-4">
                                                        <TrashIcon
                                                            class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                            @click="deleteItem(item)" />
                                                        <span
                                                            class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap z-10">
                                                            Delete Movie
                                                        </span>
                                                    </div>                                                    
                                                </td>


                                            </tr>
                                            <tr v-else>
                                                <td colspan="8" class="text-center my-5">No Movies</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <!-- only one file input -->
                                    <input type="file" ref="fileInput" @change="changeFileInput" class="hidden"
                                        id="upload_file" />
                                    <div v-if="uploadProgress > 0" class="mt-4 w-64">
                                        <div class="bg-gray-200 rounded-full h-4 overflow-hidden">
                                            <div class="bg-purple-600 h-full transition-all duration-200"
                                                :style="{ width: uploadProgress + '%' }"></div>
                                        </div>
                                        <p class="text-sm mt-1">Uploading: {{ uploadProgress }}%</p>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { Head, usePage } from '@inertiajs/vue3';
import { ref} from 'vue';

import { Inertia } from '@inertiajs/inertia'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { EyeIcon, TrashIcon, ArrowUpTrayIcon, PencilIcon } from '@heroicons/vue/24/outline'



// Get data from backend
const searchTerm = ref('');
const hoveredRow = ref(null);
const series = ref(usePage().props.series || {})
const seasons = ref(usePage().props.series.seasons || []); // Assuming users.list is passed from the backend
console.log(series.value);

const selectedMovie = ref(null);
const showDeleteModal = ref(false);
const fileInput = ref(null)
const uploadProgress = ref(0)

async function previewItem(item) {
    Inertia.visit(`/series/episod/${item.id}`);
}

const deleteItem = (item) => {
    selectedMovie.value = item;
    showDeleteModal.value = true;
}

</script>

<style scoped>
/* Remove arrows from number input */
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.6s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>