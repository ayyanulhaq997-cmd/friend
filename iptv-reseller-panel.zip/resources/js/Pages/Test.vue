<template>
  <div>
    <video
      v-if="videoSrc"
      width="640"
      height="360"
      controls
      :src="videoSrc"
    ></video>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const videoSrc = ref('https://s3.lax.sharktech.net/data/BUNNYG/M/1940/La.Marca.Del.Zorro.1940.720p.DS.mp4?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=d3e4ff6dd49c9e6d0LZV%2F20251109%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20251109T061055Z&X-Amz-Expires=3600&X-Amz-SignedHeaders=host&X-Amz-Signature=1d171f5ba0e20add9c3745e03639cac9b8b8f1e17ab14eebd651791d3d5f8f33') // or from API: `videoSrc.value = response.url`
</script>
