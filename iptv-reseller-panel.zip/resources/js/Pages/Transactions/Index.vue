<template>

    <Head title="Transactions" />

    <AuthenticatedLayout title="Transactions" :desc="balance_desc">


        <div class="mx-auto">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">

                <div class="mx-auto">
                        <!-- Header -->
                        <div class="flex justify-between items-center p-6 ">
                            <h1 v-if="user.role != 'admin'" class="text-xl font-semibold text-gray-800"></h1>
                            <div class="relative">
                                <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5"
                                    fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                                <input type="text" placeholder="Search..." v-model="searchTerm"
                                    @keyup.enter="searchResult"
                                    class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />

                            </div>
                        </div>

                        <!-- Table -->
                        <div class="overflow-x-auto px-6">

                            <table class="w-full">
                                <thead>
                                    <tr class="border-b border-gray-200">
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            No</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Date</th>
                                        <th v-if="user.role != 'admin'"
                                            class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Receive</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Send</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            To</th>
                                        <th v-if="user.role != 'admin'"
                                            class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Note</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <tr
                                        class="bg-gray-200 border-b border-gray-100 hover:bg-gray-50 transition-colors  font-bold">
                                        <td class="px-4 py-2 text-base text-gray-800"></td>
                                        <td class="px-4 py-2 text-base text-gray-800">{{ new Date().toLocaleString() }}
                                        </td>
                                        <td v-if="user.role != 'admin'" class="px-4 py-2 text-base text-gray-800">{{
                                            received_total }}</td>
                                        <td class="px-4 py-2 text-base text-gray-800">{{ sent_total }}</td>
                                        <td class="px-4 py-2 text-base text-gray-800"></td>
                                        <td v-if="user.role != 'admin'" class="px-4 py-2 text-base text-gray-800">{{
                                            user_balance }}</td>
                                    </tr>
                                    <tr v-if="transactions.length != 0" v-for="(transaction, index) in transactions"
                                        :key="transaction.id"
                                        class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                        @mouseenter="hoveredRow = transaction.id" @mouseleave="hoveredRow = null">
                                        <td class="px-4 py-2 text-sm text-gray-800">{{ index + 1 }}</td>
                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            {{ new Date(transaction.date).toLocaleString() || '' }}
                                        </td>
                                        <td v-if="user.role != 'admin'" class="px-4 py-2 text-sm text-gray-800">
                                            {{ transaction.type == 'received' ? transaction.amount : '' }}
                                        </td>
                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            {{ transaction.type == 'sent' ? transaction.amount : '' }}
                                        </td>
                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            {{ transaction.type == 'sent' ? transaction.user_name : '' }}
                                        </td>
                                        <td v-if="user.role != 'admin'" class="px-4 py-2 text-sm text-gray-800">

                                        </td>
                                    </tr>
                                    <tr v-else>
                                        <td colspan="8" class="text-center my-5">No transactions</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="flex items-center justify-center space-x-2 my-4 ">
                            <!-- Previous Button -->
                            <button @click="pagination.current > 1 && pagination.current-- && searchResult()"
                                :disabled="pagination.current === 1" :class="[
                                    'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                    pagination.current === 1
                                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                        : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:-translate-x-1'
                                ]">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M15 19l-7-7 7-7" />
                                </svg>
                            </button>

                            <!-- Page Numbers -->
                            <a v-for="page in getPageNumbers(pagination.current, pagination.total)" :key="page"
                                @click="typeof page === 'number' && (pagination.current = page) && searchResult()"
                                :class="[
                                    'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                    pagination.current === page
                                        ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg scale-110'
                                        : typeof page === 'number'
                                            ? 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:scale-105'
                                            : 'bg-white text-gray-400 cursor-default'
                                ]">
                                {{ page }}
                            </a>

                            <!-- Next Button -->
                            <button
                                @click="pagination.current < pagination.total && pagination.current++ && searchResult()"
                                :disabled="pagination.current === pagination.total" :class="[
                                    'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                    pagination.current === pagination.total
                                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                        : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:translate-x-1'
                                ]">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M9 5l7 7-7 7" />
                                </svg>
                            </button>
                        </div>
                </div>

            </div>
        </div>




    </AuthenticatedLayout>
</template>

<script setup>
import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted } from 'vue';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
// Get data from backend
const searchTerm = ref('');
const hoveredRow = ref(null);
const transaction_list = usePage().props.transaction_list.data || [];
const received_total = usePage().props.received_total || '';
const sent_total = usePage().props.sent_total || '';
const transactions = ref(transaction_list); // Assuming users.list is passed from the backend
const current_page = usePage().props.transaction_list.current_page;
const total_page = usePage().props.transaction_list.last_page;
const pagination = ref({ current: current_page, total: total_page });
const { props } = usePage();
const user = props.auth.user
const user_balance = usePage().props.balance || '';
const balance_desc = user.role == 'admin' ? "Balance : " + sent_total : "Balance : " + user_balance 


const getPageNumbers = (current, total, maxVisible = 5) => {
    const pages = [];

    if (total <= maxVisible + 2) {
        // Show all pages if total is small
        for (let i = 1; i <= total; i++) {
            pages.push(i);
        }
    } else {
        // Always show first page
        pages.push(1);

        let start = Math.max(2, current - Math.floor(maxVisible / 2));
        let end = Math.min(total - 1, start + maxVisible - 1);

        // Adjust start if we're near the end
        if (end === total - 1) {
            start = Math.max(2, end - maxVisible + 1);
        }

        // Add ellipsis at start if needed
        if (start > 2) {
            pages.push('...');
        }

        // Add middle pages
        for (let i = start; i <= end; i++) {
            pages.push(i);
        }

        // Add ellipsis at end if needed
        if (end < total - 1) {
            pages.push('...');
        }

        // Always show last page
        pages.push(total);
    }

    return pages;
};
const searchResult = () => {
    console.log(pagination.value.current);
    if (pagination.value.current && searchTerm) {
        fetchtransactions('?page=' + pagination.value.current + '&search=' + searchTerm.value);
    }
    else if (!pagination.value.current && searchTerm.value != '') {
        fetchtransactions('?page=1&search=' + searchTerm.value);
    }
    else if (pagination.value.current && !searchTerm) {
        fetchtransactions('?page=' + pagination.value.current + '$search=""');
    }

}
async function fetchtransactions(param) {
    try {
        const response = await fetch('/transactions/search' + param, {
            method: 'get',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })
        if (!response.ok) throw new Error('Failed to save user')
        const data = await response.json()
        transactions.value = data.transaction_list.data; // Assuming users.list is passed from the backend
        pagination.value = { current: data.transaction_list.current_page, total: data.transaction_list.last_page };

    } catch (error) {
        console.error('❌ Error saving user:', error)

    }
}

</script>

<style scoped>
/* Remove arrows from number input */
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.6s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>
