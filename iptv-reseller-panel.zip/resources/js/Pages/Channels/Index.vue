<template>

    <Head title="Channels" />

    <AuthenticatedLayout title="Channel" desc="CHANNEL LIST">
        <div class="mx-auto">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">

                <div class="mx-auto">
                    <div>
                        <!-- Header -->
                        <div class="flex justify-between items-center p-6 ">

                            <div class="relative">
                                <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5"
                                    fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                                <input type="text" placeholder="Search..." v-model="searchTerm"
                                    @keyup.enter="searchResult"
                                    class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />

                            </div>
                        </div>

                        <!-- Table -->
                        <div class="overflow-x-auto px-6">
                            <table class="w-full">
                                <thead>
                                    <tr class="border-b border-gray-200">
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            No</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Logo</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Name</th>
                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Disable/Enable</th>

                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Preview</th>

                                        <th class="text-left px-4 py-2 text-sm font-semibold text-gray-700">
                                            Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-if="channels.length != 0" v-for="(channel, index) in channels"
                                        :key="channel.live_tv_id"
                                        class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                        @mouseenter="hoveredRow = channel.id" @mouseleave="hoveredRow = null">
                                        <td class="px-4 py-2 text-sm text-gray-800">{{ index + 1 }}</td>
                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            <img :src=channel.thumbnail
                                                style="max-width: 64px" :alt="`${channel.tv_name}`" class="lazy" />
                                        </td>
                                        <td class="px-4 py-2 text-gray-800">
                                            {{ channel.tv_name }}
                                        </td>
                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            <button type="button" @click="channel.publish = !channel.publish; changePublishOption(channel.live_tv_id)" :class="[
                                            'relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 align-bottom',
                                            channel.publish ? 'bg-green-500' : 'bg-gray-300'
                                        ]">
                                            <span :class="[
                                                'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                                                channel.publish ? 'translate-x-6' : 'translate-x-1'
                                            ]" />
                                        </button>    
                                        </td>

                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            
                                                <EyeIcon
                                                    class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                    @click="previewItem(channel)" />
                                                <span
                                                    class="absolute bottom-full mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap">
                                                    Preview Movie
                                                </span>
                                           

                                        </td>

                                        <td class="px-4 py-2 text-sm text-gray-800">
                                            <div class="relative group inline-block">
                                                <PencilIcon
                                                    class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                    @click="editItem(channel)" />
                                                <span
                                                    class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap z-10">
                                                    Edit Movie
                                                </span>
                                            </div>
                                            <div class="relative group inline-block ml-4">
                                                <TrashIcon
                                                    class="w-5 h-5 text-gray-600 hover:text-purple-600 cursor-pointer"
                                                    @click="deleteItem(channel)" />
                                                <span
                                                    class="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded py-1 px-2 whitespace-nowrap z-10">
                                                    Delete Movie
                                                </span>
                                            </div>
                                            
                                        </td>


                                    </tr>
                                    <tr v-else>
                                        <td colspan="8" class="text-center my-5">No Movies</td>
                                    </tr>
                                </tbody>
                            </table>
                            
                        </div>
                    </div>
                    <div class="flex items-center justify-center space-x-2 my-4">
                        <!-- Previous Button -->
                        <button @click="pagination.current > 1 && pagination.current-- && searchResult()"
                            :disabled="pagination.current === 1" :class="[
                                'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                pagination.current === 1
                                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                    : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:-translate-x-1'
                            ]">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M15 19l-7-7 7-7" />
                            </svg>
                        </button>

                        <!-- Page Numbers -->
                        <a v-for="page in getPageNumbers(pagination.current, pagination.total)" :key="page"
                            @click="typeof page === 'number' && (pagination.current = page) && searchResult()" :class="[
                                'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                pagination.current === page
                                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg scale-110'
                                    : typeof page === 'number'
                                        ? 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:scale-105'
                                        : 'bg-white text-gray-400 cursor-default'
                            ]">
                            {{ page }}
                        </a>

                        <!-- Next Button -->
                        <button @click="pagination.current < pagination.total && pagination.current++ && searchResult()"
                            :disabled="pagination.current === pagination.total" :class="[
                                'px-4 py-2 rounded-lg font-medium transition-all duration-300',
                                pagination.current === pagination.total
                                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                                    : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-purple-500 hover:text-purple-600 hover:shadow-md transform hover:translate-x-1'
                            ]">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 5l7 7-7 7" />
                            </svg>
                        </button>
                    </div>
                </div>

            </div>
        </div>
    
        <!-- Delete Modal Background -->
        <div v-if="showDeleteModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <!-- Modal Box -->
            <div class="bg-white rounded-2xl shadow-lg p-6 w-[90%] max-w-md animate-fade-in">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">
                    Confirm Delete
                </h2>
                <p class="text-gray-600 mb-6">
                    Are you sure you want to delete this item? This action cannot be undone.
                </p>

                <div class="flex justify-end space-x-3">
                    <button @click="showDeleteModal = false"
                        class="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100">
                        Cancel
                    </button>
                    <button @click="confirmDelete" class="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<script setup>
import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed, onMounted } from 'vue';
import { useRouter } from 'vue-router'
import { Inertia } from '@inertiajs/inertia'
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { EyeIcon, TrashIcon, ArrowUpTrayIcon, PencilIcon } from '@heroicons/vue/24/outline'
import Hls from 'hls.js'
const isReady = ref(false)
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions

// Get data from backend
const searchTerm = ref('');
const hoveredRow = ref(null);
const channel_list = usePage().props.channel_list.data || [];
const channels = ref(channel_list); // Assuming users.list is passed from the backend
const current_page = usePage().props.channel_list.current_page;
const total_page = usePage().props.channel_list.last_page;
const preview = ref(false);
const pagination = ref({ current: current_page, total: total_page });
const video = ref(null)
const video_mp4 = ref(null)   // for mp4
const mp4_url = ref("");
const video_type = ref('m3u8');
let hls = null
const videoSrc = ref('/m3u8-proxy') // Laravel route
const channel_detail = ref({
    title: '',
    rating: '',
    year: '',
    duration: '',
    quality: '',
    description: '',
    cast: '',
    director: '',
    genre: '',
    language: ''
})
const selectedChannel = ref(null);
const showDeleteModal = ref(false);
const file = ref(null)
const fileInput = ref(null)
const uploadProgress = ref(0)
// const router = useRouter()
const getPageNumbers = (current, total, maxVisible = 5) => {
    const pages = [];

    if (total <= maxVisible + 2) {
        // Show all pages if total is small
        for (let i = 1; i <= total; i++) {
            pages.push(i);
        }
    } else {
        // Always show first page
        pages.push(1);

        let start = Math.max(2, current - Math.floor(maxVisible / 2));
        let end = Math.min(total - 1, start + maxVisible - 1);

        // Adjust start if we're near the end
        if (end === total - 1) {
            start = Math.max(2, end - maxVisible + 1);
        }

        // Add ellipsis at start if needed
        if (start > 2) {
            pages.push('...');
        }

        // Add middle pages
        for (let i = start; i <= end; i++) {
            pages.push(i);
        }

        // Add ellipsis at end if needed
        if (end < total - 1) {
            pages.push('...');
        }

        // Always show last page
        pages.push(total);
    }

    return pages;
};
const searchResult = () => {
    if (pagination.value.current && searchTerm) {
        fetchChannels('?page=' + pagination.value.current + '&search=' + searchTerm.value);
    }
    else if (!pagination.value.current && searchTerm.value != '') {
        fetchChannels('?page=1&search=' + searchTerm.value);
    }
    else if (pagination.value.current && !searchTerm) {
        fetchChannels('?page=' + pagination.value.current + '$search=""');
    }

}
async function fetchChannels(param) {
    try {
        const response = await fetch('/channels/search' + param, {
            method: 'get',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })
        if (!response.ok) throw new Error('Failed to save user')
        const data = await response.json()
        channels.value = data.channel_list.data; // Assuming users.list is passed from the backend
        pagination.value = { current: data.channel_list.current_page, total: data.channel_list.last_page };
        console.log(channels.value);


    } catch (error) {
        console.error('❌ Error saving user:', error)

    }
}

async function previewItem(channel) {
    window.open(channel.url, '_blank');
}

async function changePublishOption(id) {
    try {
        const response = await fetch('/channels/publish', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content
            },
            body: JSON.stringify({
                channel_id: id
            })
        });

        const data = await response.json();

        if (data.success) showSuccess(data.message);
        else showError(data.message);

    } catch (error) {
        console.error('❌ Error saving user:', error);
    }
}


const closePreview = () => {
    if (video_type.value === 'm3u8') {
        const current_video = video.value
        if (current_video) {
            current_video.pause()
            current_video.currentTime = 0
            current_video.src = ''
        }
        if (hls) {
            hls.stopLoad()
            hls.destroy()
            hls = null
        }
    }
    else if (video_type.value === 'mp4') {
        const current_video = video_mp4.value
        if (current_video) {
            current_video.pause()
            current_video.currentTime = 0
            current_video.src = ''  // optional, remove video URL
        }
    }

    preview.value = false
    isReady.value = false
}

async function confirmDelete() {
    try {
        const response = await fetch('/channels/delete/' + selectedChannel.value.live_tv_id, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json();
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            searchResult();
            showDeleteModal.value = false;
        }
        else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        showError(error) // ❌ show error toast
    }
    showDeleteModal.value = false
}

const deleteItem = (item) => {
    selectedChannel.value = item;
    showDeleteModal.value = true;
}
const editItem = (item) => {
    Inertia.visit('/channels/edit/' + item.live_tv_id);
}





</script>

<style scoped>
/* Remove arrows from number input */
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

.fade-enter-active,
.fade-leave-active {
    transition: opacity 0.6s ease;
}

.fade-enter-from,
.fade-leave-to {
    opacity: 0;
}
</style>