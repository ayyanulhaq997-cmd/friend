<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';

import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed } from 'vue';
import { Inertia } from '@inertiajs/inertia'
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions

const formData = ref({
    name: '',
    username: '',
    email: '',
    password: '',
    phone: '',
    credit: 0,
    active: true
});

async function handleSubmit() {

    try {
        const response = await fetch('/subresellers/store', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: JSON.stringify(formData.value)
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            Inertia.visit('/subresellers/index');
        } else {
            showError(data.message) // ❌ show error toast
        }

    } catch (error) {
        showError('Error saving user.') // ❌ show error toast
    }
};

</script>

<template>

    <Head title="Subreseller" />

    <AuthenticatedLayout title="Subreseller" desc="Add a subreseller" >

            <div class="mx-auto">
                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg px-6 py-8 ">

                        <form @submit.prevent="handleSubmit">
                            <div class="">
                                <!-- Row 1 -->
                                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            USER NAME <span class="text-red-600">(*)</span>
                                        </label>
                                        <input v-model="formData.username" type="text"
                                            class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                                    </div>

                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            PASSWORD <span class="text-red-600">(*)</span>
                                        </label>
                                        <div class="relative">
                                            <input v-model="formData.password" type="text"
                                                class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />

                                        </div>
                                    </div>
                                </div>                                
                                <!-- Row 4 -->
                                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            CREDIT
                                        </label>
                                        <input v-model="formData.credit" type="number" min="0"
                                            class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                                    </div>

                                </div>
                                <!-- Row 5 -->
                                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">

                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">
                                            ACTIVE
                                        </label>
                                        <button type="button" @click="formData.active = !formData.active" :class="[
                                            'relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 align-bottom',
                                            formData.active ? 'bg-green-500' : 'bg-gray-300'
                                        ]">
                                            <span :class="[
                                                'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                                                formData.active ? 'translate-x-6' : 'translate-x-1'
                                            ]" />
                                        </button>
                                        <span class="ml-3 text-sm font-medium text-gray-700"></span>
                                    </div>
                                </div>
                            </div>
                            <!-- Save Button -->
                            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                                <button type="submit"
                                    class="px-16 py-3 bg-orange-500 text-white rounded-full font-medium hover:bg-orange-600 transition-colors shadow-lg">
                                    Save
                                </button>
                            </div>
                        </form>


                </div>
            </div>

    </AuthenticatedLayout>
</template>



<style scoped>
/* Add any custom styles here if needed */
</style>
