<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import Header from '@/Layouts/Header.vue';
import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed } from 'vue';
import { Inertia } from '@inertiajs/inertia'
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions
import { useAuthStore } from '@/Utils/auth'
const page = usePage()
const queryString = page.url.split('?')[1]  // "type=demo"
const params = new URLSearchParams(queryString)
const page_type =params.get('type') ?? 'user'
const auth = useAuthStore()


const formData = ref({
    name: '',
    username: '',
    email: '',
    password: '',
    duration: page_type == 'user'? 12:0,
    phone: '',
    // start_date : new Date().toISOString().split('T')[0],
    status: true
});

const title_user = page_type == 'user'?'User':'Demo'
const titie_desc = page_type == 'user'?'Add a New User':'Add a New Demo'

async function handleSubmit() {
    // Add your form submission logic here
    try {
        const response = await fetch('/customers/store', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: JSON.stringify(formData.value)
        })

        if (!response.ok) {
            const errorData = await response.json();
            if (errorData.errors.username && errorData.errors.username.length > 0) {
                showError(errorData.errors.username[0]) // ❌ show error toast
                return;
            }
            if (errorData.errors.password && errorData.errors.password.length > 0) {
                showError(errorData.errors.password[0]) // ❌ show error toast
                return;
            }
            throw new Error('Failed to save user')

        }
        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast
            if(page_type == 'user') Inertia.visit('/customers/index?type=premium');
            else Inertia.visit('/customers/demo');
        } else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        showError('Error saving user.') // ❌ show error toast
    }
};

</script>
<template>

    <Head title="Demo" />
    <AuthenticatedLayout :title="title_user" :desc="titie_desc">
        <div class="bg-white shadow-sm sm:rounded-lg px-6 py-8">
            <form @submit.prevent="handleSubmit">
                <div class="">
                    <!-- Row 1 -->
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                USER NAME
                            </label>
                            <input v-model="formData.username" type="text"
                                class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                PASSWORD
                            </label>
                            <div class="relative">
                                <input v-model="formData.password" type="text"
                                    class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                            </div>
                        </div>
                    </div>
                    <!-- Row 2 -->
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6" v-if="page_type == 'user'">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                CREDIT
                            </label>
                            <input v-model="formData.credit" type="number" min="12"   step="12"                             
                                class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                        </div>
                    </div>
                    <!-- Row 5 -->
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                ACTIVE
                            </label>
                            <button type="button" @click="formData.status = !formData.status" :class="[
                                'relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 align-bottom',
                                formData.status ? 'bg-green-500' : 'bg-gray-300'
                            ]">
                                <span :class="[
                                    'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                                    formData.status ? 'translate-x-6' : 'translate-x-1'
                                ]" />
                            </button>
                            <span class="ml-3 text-sm font-medium text-gray-700"></span>
                        </div>
                    </div>
                </div>
                <!-- Save Button -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                    <button type="submit"
                        class="px-16 py-3 bg-orange-500 text-white rounded-full font-medium hover:bg-orange-600 transition-colors shadow-lg">
                        Save
                    </button>
                </div>
            </form>
        </div>


    </AuthenticatedLayout>
</template>



<style scoped>
/* Add any custom styles here if needed */
</style>
