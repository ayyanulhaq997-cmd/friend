<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import Header from '@/Layouts/Header.vue';
import { Head, usePage } from '@inertiajs/vue3';
import { ref, computed } from 'vue';
import { Inertia } from '@inertiajs/inertia'
import { CirclePause ,Play , Save,StopCircleIcon,X,Trash2,PencilOff  } from 'lucide-vue-next'
import { showSuccess, showError } from '@/Utils/message'; // Import toast functions
const user = ref(usePage().props.user || {});
const subscriptions = ref(usePage().props.subscriptions || []);
const showAddSubscriptionModal = ref(false);
const flagEdit = ref(false);
const showDeleteModal = ref(false);
const showSubscriptionDeleteModal = ref(false);
const selectedUser = ref(null);
const selectedSubscription = ref(null);
const endDate = ref('');
const addSubscription = ref({
    start_date: new Date().toISOString().split('T')[0],
    end_date: '',
    duration: 1,
    status: true,
    user_id: user.value.user_id
})

const formData = ref({
    name: user.value.name || '',
    user_id: user.value.user_id || '',
    username: user.value.username || '',
    email: user.value.email || '',
    password: user.value.password || '',
    phone: user.value.phone || '',
    status: user.value.status,
    latest_subscription_end_date: user.value.latest_subscription_end_date || ''
});

// Calculate +1 month end_date
const start = new Date(addSubscription.value.start_date)
start.setMonth(start.getMonth() + 1)
addSubscription.value.end_date = start.toISOString().split('T')[0];



async function handleSubmit() {
    try {
        const response = await fetch('/customers/update/' + user.value.user_id, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: JSON.stringify(formData.value)
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json();
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast  
            flagEdit.value = false;
        }
        else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        console.error('❌ Error saving user:', error)
        showError('Error saving user.') // ❌ show error toast
    }
};

async function confirmAddSubscription() {
    try {
        const response = await fetch('/customers/add/subscription', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            },
            body: JSON.stringify(addSubscription.value)
        })

        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast             
            subscriptions.value = [{
                subscription_id: data.subscription.subscription_id,
                start_date: data.subscription.start_date.date,
                end_date: data.subscription.end_date.date,
                status: data.subscription.status,
                plan_id: data.subscription.plan_id,
                user_id: data.subscription.user_id
            }, ...subscriptions.value];
            showAddSubscriptionModal.value = false;
            user.value = data.user;
            formData.value.latest_subscription_end_date = user.value.latest_subscription_end_date;
            endDate.value = new Date(data.subscription.end_date.date).toISOString().split('T')[0];
        }
        else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        console.error('❌ Error saving user:', error)
        showError('Error saving user.') // ❌ show error toast
    }
}

const changeDurationOption = () => {
    const start = new Date(addSubscription.value.start_date)
    if (addSubscription.value.duration != 0) start.setMonth(start.getMonth() + Number(addSubscription.value.duration))
    else start.setDate(start.getDate() + 2)
    addSubscription.value.end_date = start.toISOString().split('T')[0]
}

const handleEdit = () => {
    flagEdit.value = true;
}

const handleDelete = (item) => {
    showDeleteModal.value = true;
    selectedUser.value = item;
    console.log(selectedUser.value);

}

async function confirmDelete() {
    try {
        const response = await fetch('/customers/delete/' + selectedUser.value.user_id, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        if (!response.ok) throw new Error('Failed to save user')

        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast  

        }
        else {
            showError(data.message) // ❌ show error toast
        }


    } catch (error) {
        showError(error) // ❌ show error toast
    }
    showModal.value = false
}

const handleSubscriptionStop = async (subscription) => {

    try {
        const response = await fetch('/customers/stop/subscription/' + subscription.subscription_id, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast  
            user.value = data.user;
            formData.value.latest_subscription_end_date = user.value.latest_subscription_end_date;
            subscription.status = 0;
        }
        else {
            showError(data.message) // ❌ show error toast
        }
    } catch (error) {
        console.error('❌ Error stopping subscription:', error)
        showError('Error stopping subscription.') // ❌ show error toast
    }
};

const handleSubscriptionResume = async (subscription) => {
    try {
        const response = await fetch('/customers/resume/subscription/' + subscription.subscription_id, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast  
            user.value = data.user;
            formData.value.latest_subscription_end_date = user.value.latest_subscription_end_date;
            subscription.status = 1;
        }
        else {
            showError(data.message) // ❌ show error toast
        }
    } catch (error) {
        console.error('❌ Error resuming subscription:', error)
        showError('Error resuming subscription.') // ❌ show error toast
    }
};

const confirmSubscriptionDelete = async () => {
    try {
        const response = await fetch('/customers/delete/subscription/' + selectedSubscription.value.subscription_id, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document
                    .querySelector('meta[name="csrf-token"]')
                    ?.getAttribute('content')
            }
        })

        const data = await response.json()
        if (data.success) {
            showSuccess(data.message) // ✅ show success toast 
            showSubscriptionDeleteModal.value = false;
            user.value = data.user;
            formData.value.latest_subscription_end_date = user.value.latest_subscription_end_date;
            subscriptions.value = subscriptions.value.filter(sub => sub.subscription_id !== selectedSubscription.value.subscription_id);
        }
        else {
            showError(data.message) // ❌ show error toast
        }
    } catch (error) {
        console.error('❌ Error deleting subscription:', error)
        showError('Error deleting subscription.') // ❌ show error toast
    }
};

const handleSubscriptionDelete = (subscription) => {
    showSubscriptionDeleteModal.value = true;
    selectedSubscription.value = subscription;
    console.log(selectedSubscription.value);
};
</script>

<template>

    <Head title="User" />
    <AuthenticatedLayout title="User" desc="Edit a User">

            <div class="mx-auto">
                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                    <div class="px-6 py-8 my-4 items-center">
                        <table class="w-full">
                            <thead>
                                <tr class="border-b border-gray-200">
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        User Name</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Password</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Status</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        End Date</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                    @mouseenter="hoveredRow = formData.user_id" @mouseleave="hoveredRow = null">
                                    <td v-if="!flagEdit" class="px-6 py-4 text-lg text-gray-800">{{ formData.username }}
                                    </td>
                                    <td v-else class="text-sm text-gray-800">
                                        <input v-model="formData.username" type="text"
                                            class="w-30 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                                    </td>

                                    <td v-if="!flagEdit" class="px-6 py-4 text-lg text-gray-800">{{ formData.password }}
                                    </td>
                                    <td v-else class="text-sm text-gray-800">
                                        <input v-model="formData.password" type="text"
                                            class="w-30 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                                    </td>                                   
                                    <td v-if="!flagEdit" class="px-6 py-4 text-lg text-gray-800">
                                        <span
                                            :class="formData.status ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full">
                                            {{ formData.status ? 'Active' : 'Inactive' }}
                                        </span>
                                    </td>
                                    <td v-else class="text-sm text-gray-800">
                                        <button type="button" @click="formData.status = !formData.status" :class="[
                                            'relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 align-bottom',
                                            formData.status ? 'bg-green-500' : 'bg-gray-300'
                                        ]">
                                            <span :class="[
                                                'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                                                formData.status ? 'translate-x-6' : 'translate-x-1'
                                            ]" />
                                        </button>
                                    </td>
                                    <td class="px-6 py-4 text-lg text-gray-800">
                                        <span v-if="formData.latest_subscription_end_date">
                                            {{ new
                                                Date(formData.latest_subscription_end_date).toISOString().split('T')[0] }}
                                        </span>
                                        <span v-else>
                                            N/A
                                        </span>

                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="flex gap-2">
                                            <button v-if="!flagEdit"
                                                class="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                                                title="Edit" @click="handleEdit(formData.user_id)">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor"
                                                    viewBox="0 0 24 24"> 
                                                     <PencilOff class="w-6 h-6 text-green-500 hover:text-green-600 cursor-pointer" />
                                                </svg>
                                            </button>
                                            <button v-else
                                                class="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                                                title="Save" @click="handleSubmit">
                                                 <Save class="w-6 h-6 text-green-500 hover:text-green-600 cursor-pointer" />
                                            </button>
                                           
                                            <button v-if="flagEdit"
                                                class="p-2 text-gray-400 hover:text-gray-600 transition-colors"
                                                title="Cancel" @click="flagEdit = false">
                                                  <X class="w-6 h-6 text-red-500 hover:text-red-600 cursor-pointer" />

                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="w-full mt-10 font-semibold">
                            <span
                                :class="formData.latest_subscription_end_date? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                                class="px-4 py-4 inline-flex  leading-5 font-semibold rounded-full">
                                SUBSCRIPTIONS
                            </span>
                        </div>


                        <table class="w-full">
                            <thead>
                                <tr class="border-b border-gray-200">
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        No</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Start Date</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        End Date</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Duration</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Status</th>
                                    <th class="text-left px-6 py-4 text-sm font-semibold text-gray-700">
                                        Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(subscription, index) in subscriptions" :key="subscription.id"
                                    class="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                                    @mouseenter="hoveredRow = subscription.id" @mouseleave="hoveredRow = null">
                                    <td class="px-6 py-4 text-sm text-gray-800">{{ index + 1 }}</td>
                                    <td class="px-6 py-4 text-sm text-gray-800">{{ new
                                        Date(subscription.start_date).toISOString().split('T')[0] || '' }}
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-800">{{ new
                                        Date(subscription.end_date).toISOString().split('T')[0] || '' }}
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-800">
                                        <span v-if="subscription.plan_id == 0">
                                            2 Days
                                        </span>
                                        <span v-else>
                                            {{ subscription.plan_id }} Months
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-800">
                                        <span
                                            :class="subscription.status ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'"
                                            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full">
                                            {{ subscription.status ? 'Active' : 'Inactive' }}
                                        </span>
                                    </td>

                                    <td class="px-6 py-4 text-sm text-gray-800">

                                        <button v-if="subscription.status == 1"
                                            class="p-2 text-gray-400 hover:text-red-500 transition-colors" title="Stop"
                                            @click="handleSubscriptionStop(subscription)">
                                            <StopCircleIcon class="w-6 h-6 text-gray-400 hover:text-red-500 cursor-pointer" />


                                        </button>

                                        <button v-if="subscription.status == 1"
                                            class="p-2 text-gray-400 hover:text-red-500 transition-colors"
                                            title="Delete" @click="handleSubscriptionDelete(subscription)">
                                            <Trash2 class="w-6 h-6 text-gray-400 hover:text-red-500 cursor-pointer" />
                                        </button>

                                        <button
                                            v-if="subscription.status == 0 && new Date(subscription.end_date).toISOString().split('T')[0] > new Date().toISOString().split('T')[0]"
                                            class="p-2 text-gray-400 hover:text-red-500 transition-colors"
                                            title="Resume" @click="handleSubscriptionResume(subscription)">
                                            <Play class="w-6 h-6 text-green-500 hover:text-green-600 cursor-pointer" />
                                        </button>


                                    </td>

                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- Add New Button -->
                    <div class="flex justify-center p-8">
                        <button
                            class="px-8 py-3 border-2 border-orange-400 text-orange-400 rounded-full font-medium hover:bg-orange-50 transition-colors"
                            @click="showAddSubscriptionModal = true">
                            Add New
                        </button>
                    </div>

                </div>
            </div>


        <!-- Add Subscription Modal Background -->
        <div v-if="showAddSubscriptionModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <!-- Modal Box -->
            <div class="bg-white rounded-2xl shadow-lg p-6 w-[90%] max-w-md animate-fade-in">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">
                    Add Credit to <span class="text-red-600 text-2xl">{{ formData.username || '' }}</span>
                </h2>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    START DATE
                </label>
                <p class="text-gray-600 mb-6">
                    <input v-model="addSubscription.start_date" type="date"
                        class="w-full px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                </p>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    CREDIT
                </label>
                <p class="text-gray-600 mb-6">
                    <input v-model="addSubscription.duration" type="number" min="0" @change="changeDurationOption"
                        class="w-full  px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                </p>
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    END DATE
                </label>
                <p class="text-gray-600 mb-6 cursor-not-allowed select-none opacity-60">
                    <input v-model="addSubscription.end_date" type="date"
                        class="w-full  px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent" />
                </p>

                <label class="block text-sm font-medium text-gray-700 mb-2">
                    ACTIVE
                </label>
                <button type="button" @click="addSubscription.status = !addSubscription.status" :class="[
                    'relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 align-bottom',
                    addSubscription.status ? 'bg-green-500' : 'bg-gray-300'
                ]">
                    <span :class="[
                        'inline-block h-4 w-4 transform rounded-full bg-white transition-transform',
                        addSubscription.status ? 'translate-x-6' : 'translate-x-1'
                    ]" />
                </button>

                <div class="flex justify-end space-x-3">
                    <button @click="showAddSubscriptionModal = false"
                        class="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100">
                        Cancel
                    </button>
                    <button @click="confirmAddSubscription"
                        class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">
                        Add
                    </button>
                </div>
            </div>
        </div>

        <!-- Delete Modal Background -->
        <div v-if="showDeleteModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <!-- Modal Box -->
            <div class="bg-white rounded-2xl shadow-lg p-6 w-[90%] max-w-md animate-fade-in">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">
                    Confirm Delete
                </h2>
                <p class="text-gray-600 mb-6">
                    Are you sure you want to delete <span class="text-red-900">{{ selectedUser.username }}</span>? This
                    action
                    cannot be undone.
                </p>

                <div class="flex justify-end space-x-3">
                    <button @click="showDeleteModal = false"
                        class="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100">
                        Cancel
                    </button>
                    <button @click="confirmDelete" class="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </div>
        </div>

        <!-- Delete Modal Background -->
        <div v-if="showSubscriptionDeleteModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <!-- Modal Box -->
            <div class="bg-white rounded-2xl shadow-lg p-6 w-[90%] max-w-md animate-fade-in">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">
                    Confirm Delete
                </h2>
                <p class="text-gray-600 mb-6">
                    Are you sure you want to delete? This action cannot be undone.
                </p>

                <div class="flex justify-end space-x-3">
                    <button @click="showSubscriptionDeleteModal = false"
                        class="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100">
                        Cancel
                    </button>
                    <button @click="confirmSubscriptionDelete"
                        class="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700">
                        Delete
                    </button>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>



<style scoped>
/* Add any custom styles here if needed */
</style>
