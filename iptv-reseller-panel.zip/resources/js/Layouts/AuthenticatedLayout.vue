<script setup>
import { ref } from 'vue';
import ApplicationLogo from '@/Components/ApplicationLogo.vue';
import Dropdown from '@/Components/Dropdown.vue';
import Sidebar from '@/Components/Layout/SideBar.vue';
import DropdownLink from '@/Components/DropdownLink.vue';
import NavLink from '@/Components/NavLink.vue';
import ResponsiveNavLink from '@/Components/ResponsiveNavLink.vue';
import { Link } from '@inertiajs/vue3';
import { ChevronDownIcon } from 'lucide-vue-next'

const showingNavigationDropdown = ref(false);

const props = defineProps({
    title: {
        type: String,
        default: ""
    },
    desc: {
        type: String,
        default: ""
    },
});
const title = props.title
const desc = props.desc
</script>
<style>
/* For Chrome, Edge, Safari */
::-webkit-scrollbar {
  width: 10px;                 /* scrollbar width */
}

::-webkit-scrollbar-track {
  background: #e5e5e5;         /* light gray background */
  border-radius: 10px;
}

::-webkit-scrollbar-thumb {
  background: #9a9a9a;         /* darker gray thumb */
  border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
  background: #7a7a7a;         /* hover color */
}

/* Firefox */
* {
  scrollbar-width: thin;
  scrollbar-color: #9a9a9a #e5e5e5;   /* thumb | track */
}
</style>
<template>

    <div class="bg-gray-100">
      
      
      <nav class="sticky top-0 z-40 w-full bg-white">
        <!-- Primary Navigation Menu -->
        <div class="mx-auto px-4 sm:px-6 lg:px-8 bg-slate-900">
          <div class="flex h-16 justify-between">
            <div class="flex">
              <!-- Logo -->
              <div class="flex items-center">
                <Link :href="route('dashboard')">
                  <ApplicationLogo class="h-20 w-auto mt-10 px-12" />
                </Link>
              </div>
              <!-- Navigation Title -->
              <div class="hidden sm:flex items-center sm:ms-10">
              </div>
            </div>
            <div class="hidden sm:ms-6 sm:flex sm:items-center">
              <!-- Settings Dropdown -->
              <div class="relative ms-3">
                <Dropdown align="right" width="48">
                  <template #trigger>
                    <span class="inline-flex rounded-md">
                      <button type="button"
                        class="inline-flex items-center rounded-md border border-transparent px-3 py-2 text-sm font-medium bg-slate-600 text-zinc-100 leading-4 transition duration-150 ease-in-out hover:text-gray-700 focus:outline-none">
                        {{ $page.props.auth.user.username }}
                        <ChevronDownIcon class="w-3 h-3 ml-2 text-black" />
                      </button>
                    </span>
                  </template>

                  <template #content>
                    <DropdownLink :href="route('profile.edit')">
                      Profile
                    </DropdownLink>
                    <DropdownLink :href="route('logout')" method="post" as="button">
                      Log Out
                    </DropdownLink>
                  </template>
                </Dropdown>
              </div>
            </div>
          </div>
        </div>

        <!-- Responsive Navigation Menu -->
        <div class="hidden">
          <div class="space-y-1 pb-3 pt-2">
            <ResponsiveNavLink :href="route('dashboard')" :active="route().current('dashboard')">
              Dashboard
            </ResponsiveNavLink>
          </div>

          <!-- Responsive Settings Options -->
          <div class="border-t border-gray-200 pb-1 pt-4 bg-orange-700">
            <div class="px-4">
              <div class="text-base font-medium text-gray-800">
                {{ $page.props.auth.user.name }}
              </div>
              <div class="text-sm font-medium text-gray-500">
                {{ $page.props.auth.user.email }}
              </div>
            </div>

            <div class="mt-3 space-y-1">
              <ResponsiveNavLink :href="route('profile.edit')">
                Profile
              </ResponsiveNavLink>
              <ResponsiveNavLink :href="route('logout')" method="post" as="button">
                Log Out
              </ResponsiveNavLink>
            </div>
          </div>
        </div>
      </nav>
      <div class="bg-slate-900">
        <!-- Sidebar -->
        <Sidebar />

        <!-- Page Content -->
        <main class="rounded-tl-[24px] bg-gray-100 ml-72 min-h-[calc(100vh-64px)]">
          <div class="p-6 ">
            <!-- Page Heading -->
            <div class="mb-4">
                <h1 class="text-4xl font-bold text-gray-800 mb-2" >{{ title }}</h1>
                <p class="text-gray-500">{{ desc }}</p>
            </div>
            <slot />
          </div>
        </main>
      </div>
    </div>

</template>
