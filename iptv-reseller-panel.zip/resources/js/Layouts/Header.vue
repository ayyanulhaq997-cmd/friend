<script setup>
import { ref, onMounted, computed } from 'vue';
const props = defineProps({
    title: {
        type: String,
    },
    desc: {
        type: String,
    },
});
const title = props.title
const desc = props.desc

</script>
<template>
    <div class="mb-4">
        <h1 class="text-4xl font-bold text-gray-800 mb-2" >{{ title }}</h1>
        <p class="text-gray-500">{{ desc }}</p>
    </div>
</template>
