<script setup>
import ApplicationLogo from '@/Components/ApplicationLogo.vue';
import { Link } from '@inertiajs/vue3';
</script>
<template>
    <div
        class="flex min-h-screen flex-col items-center bg-gradient-to-b from-slate-600 to-slate-900 sm:justify-center "
    >  
        <div>
            <Link href="/">
                <ApplicationLogo class="w-40" />
            </Link>
        </div>
        <div
            class="mt-4 w-full overflow-hidden bg-white  px-6 py-4 shadow-md sm:max-w-md sm:rounded-lg"
        >
            <slot />
        </div>
    </div>
</template>
