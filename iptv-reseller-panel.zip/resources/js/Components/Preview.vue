<script setup>
import { createFFmpeg, fetchFile } from '@ffmpeg/ffmpeg'
import { ref } from 'vue'

const ffmpeg = createFFmpeg({ log: true })
const isReady = ref(false)
const outputUrl = ref('')

async function loadFFmpeg() {
  if (!ffmpeg.isLoaded()) {
    await ffmpeg.load()
  }
  isReady.value = true
}

async function convert(file) {
  await loadFFmpeg()

  ffmpeg.FS('writeFile', 'input.ts', await fetchFile(file))
  await ffmpeg.run('-i', 'input.ts', '-c', 'copy', 'output.mp4')

  const data = ffmpeg.FS('readFile', 'output.mp4')
  const blob = new Blob([data.buffer], { type: 'video/mp4' })
  outputUrl.value = URL.createObjectURL(blob)
}
</script>

<template>
  <div class="p-4">
    <input type="file" accept=".ts" @change="e => convert(e.target.files[0])" />
    <video v-if="outputUrl" :src="outputUrl" controls class="mt-4 w-full max-w-lg"></video>
  </div>
</template>
