<template>
  <aside class="fixed w-72  overflow-y-auto bg-slate-800 text-white shadow-md h-screen">
    <!-- Logo / Title -->
    <div class="bg-slate-900 p-6 font-bold text-lg">
      <!-- <Link href="/dashboard" class="flex items-center gap-3">
      <img src="/img/avartar.png" alt="Application Logo" class="h-10 w-10" />
      <div>{{ user.username }}
        <span class="block text-sm font-normal capitalize">{{ user.role }}</span>
      </div>
      </Link> -->
    </div>

    <!-- Navigation -->
    <nav class="w-full">
      <ul>
        <li v-for="section in menuData" :key="section.id">

          <!-- Parent WITH submenu -->
          <template v-if="section.items.length > 0">

            <div class="flex items-center justify-between p-4 cursor-pointer
                 hover:bg-slate-600 transition"
              :class="section.active || !expandedSections[section.id] ? 'bg-slate-700' : 'bg-slate-800'"
              @click="toggleSection(section.id)">
              <div class="flex items-center gap-3">
                <component :is="icons[section.icon]" class="w-5 h-5 text-white" />
                <span class="text-white font-medium">
                  {{ section.title }}
                </span>
              </div>

              <component :is="!expandedSections[section.id] ? ChevronUpIcon : ChevronDownIcon"
                class="w-5 h-5 text-white transition" />
            </div>

            <transition name="fade">
              <ul v-if="!expandedSections[section.id]" class="ml-2 pl-2">
                <li v-for="item in section.items" :key="item.id">
                  <Link :href="item.href"
                    class="flex items-center gap-2 px-3 py-2 rounded-l-full transition hover:bg-slate-600"
                    :class="isActive(item.href) ? 'bg-slate-600 text-white' : 'text-slate-200'"
                    @click="handleMenuItemClick(section.id, item.id)">
                  <ChevronsRight class="w-3 h-3 text-slate-200" />
                  <span>{{ item.title }}</span>
                  </Link>
                </li>
              </ul>
            </transition>

          </template>

          <!-- Parent WITHOUT submenu -->
          <template v-else>
            <Link :href="section.href" class="flex items-center justify-between px-4 py-3 transition
                hover:bg-slate-600 no-underline" :class="isActive(section.href) ? 'bg-slate-600' : 'bg-slate-800'">
            <div class="flex items-center gap-3">
              <component :is="icons[section.icon]" class="w-5 h-5 text-white" />
              <span class="text-white font-medium">{{ section.title }}</span>
            </div>
            </Link>
          </template>

        </li>
      </ul>
    </nav>



    <!-- Close button on mobile -->
    <button class="absolute top-2 right-2 md:hidden p-1" @click="isOpen = false">
      <X class="w-6 h-6 text-white" />
    </button>
  </aside>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { Link, usePage } from '@inertiajs/vue3'  // ✅ correct import for Laravel 12
import { Home, UserCheck, UserPlus, Users, Coins, Search, Clapperboard, Tv, TvMinimalPlay, PlayCircle, CheckSquare, X, ChevronDownIcon, ChevronUpIcon, ChevronsRight } from 'lucide-vue-next'
const { props } = usePage();
const page = usePage();// currentUrl.replace(/edit\/\d+$/, 'index');
const currentUrl = ref(page.url.replace(/edit\/\d+$/, 'index'));

console.log(currentUrl);

const user = props.auth.user
const icons = {
  Home,
  UserCheck,
  UserPlus,
  Users,
  Coins,
  Search,
  Tv,
  TvMinimalPlay,
  PlayCircle,
  CheckSquare,
  ChevronsRight
}

// Menu data (static)
const menuData = ref([])

// Sidebar open state
const isOpen = ref(false)
// Reactive expanded sections
const expandedSections = ref()
const isActive = (href) => currentUrl.value === href;
console.log(isActive);

// Toggle expand/collapse
function toggleSection(sectionId) {
  expandedSections.value[sectionId] = !expandedSections.value[sectionId]
}
async function fetchMenus() {
  try {
    const response = await fetch('/home/menu', {
      method: 'get',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': document
          .querySelector('meta[name="csrf-token"]')
          ?.getAttribute('content')
      }
    })
    if (!response.ok) throw new Error('Failed to save user')
    const data = await response.json()
    if (data.success) {
      menuData.value = data.data
      expandedSections.value = menuData.value.reduce((acc, section) => {
        acc[section.id] = !isSectionActive(section);
        return acc;
      }, {});

      console.log(expandedSections.value);
    }



  } catch (error) {
    console.error('❌ Error saving user:', error)

  }
}
const isSectionActive = (section) => {
  if (section.href && isActive(section.href)) return true;
  return section.items.some(item => isActive(item.href));
};

onMounted(() => {
  isOpen.value = true; // Open sidebar on mount (for demo purposes)
  console.log(currentUrl.value);
  
  if(currentUrl.value == '/customers/create?type=demo') currentUrl.value = '/customers/demo'
  fetchMenus(); 
  const foundSection = menuData.value.find(section => {
    if (section.href && section.href === currentUrl.value) {
      return true;
    }
    return section.items.some(item => item.href === currentUrl.value);
  });
  if (foundSection) {
    expandedSections.value[foundSection.id] = false;
  }

  menuData.value.forEach(section => {
    if (section.href && section.href === currentUrl.value) {
      section.active = true;
    } else {
      section.items.forEach(item => {
        if (item.href === currentUrl.value) {
          item.active = true;
          section.active = false;
        }
      });
    }
  });


})

</script>

<style scoped>
/* optional custom scrollbar or styling here */
</style>
