import toastr from 'toastr'
import 'toastr/build/toastr.min.css'

export const showSuccess = (message) => {
  toastr.success(message)
}

export const showError = (message) => {
  toastr.error(message)
}