import { defineStore } from 'pinia'
import axios from 'axios'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    user: null,
    loading: false,
  }),
  actions: {
    async fetchUser() {
      this.loading = true
      try {
        const response = await axios.get('/user')
        this.user = response.data
      } catch (error) {
        this.user = null
      } finally {
        this.loading = false
      }
    },

    logout() {
      this.user = null
      axios.post('/logout')
    },
  },

  getters: {
    isAuthenticated: (state) => !!state.user,
  },
})
